const { REST, Routes, SlashCommandBuilder } = require('discord.js');
require('dotenv').config?.();

const commands = [
  new SlashCommandBuilder()
    .setName('grant')
    .setDescription('Grant a license key to a user')
    .addUserOption(o => o.setName('user').setDescription('The user to grant a license to').setRequired(true)),
  new SlashCommandBuilder()
    .setName('revoke')
    .setDescription('Revoke a license key from a user')
    .addUserOption(o => o.setName('user').setDescription('The user to revoke').setRequired(true)),
  new SlashCommandBuilder()
    .setName('license')
    .setDescription('Check your license key'),
  new SlashCommandBuilder()
    .setName('support')
    .setDescription('Post the support ticket panel in this channel'),
  new SlashCommandBuilder()
    .setName('purch')
    .setDescription('Post the purchase ticket panel in this channel'),
].map(c => c.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.BOT_TOKEN);

(async () => {
  console.log('Deploying slash commands...');
  await rest.put(
    Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
    { body: commands }
  );
  console.log('Done.');
})();
