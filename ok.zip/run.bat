@echo off
echo Installing dependencies...
pip install -r requirements.txt

echo.
echo Starting Discord Username Checker...
python username_checker.py

pause
