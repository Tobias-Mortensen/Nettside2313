#!/usr/bin/env python3
"""
Per-user Steam idling worker.

Spawned by manager.py as:
    python3 steam_client.py --user-id <id>

Communication with the web server happens entirely through the SQLite database:
  - pending_auth table  : signals that 2FA is required / code is ready
  - users.status        : current state machine state
  - users.idling_enabled: stop signal from the user
"""

import os
import sys
import time
import hashlib
import logging
import argparse
import signal
from pathlib import Path

from dotenv import load_dotenv
load_dotenv()

from cryptography.fernet import Fernet
from steam.client import SteamClient
from steam.enums import EResult, EPersonaState
from steam.core.msg import MsgProto
from steam.enums.emsg import EMsg

import database as db

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [worker-%(user_id)s] %(levelname)s %(message)s",
)

SESSIONS_DIR = Path(os.getenv("SESSIONS_DIR", "sessions"))
SESSIONS_DIR.mkdir(exist_ok=True)

ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY", "").encode()

PERSONA_STATE_MAP = {
    "Online":         EPersonaState.Online,
    "Away":           EPersonaState.Away,
    "Busy":           EPersonaState.Busy,
    "Invisible":      EPersonaState.Invisible,
    "LookingToTrade": EPersonaState.LookingToTrade,
    "LookingToPlay":  EPersonaState.LookingToPlay,
    "Snooze":         EPersonaState.Snooze,
}

# Maximum time to wait for user to enter 2FA code (seconds)
TWO_FA_TIMEOUT = 300
# DB poll interval while waiting for 2FA code
TWO_FA_POLL_SEC = 2
# How often to flush hour counters and check for stop signal
HEARTBEAT_SEC = 60


def decrypt_password(enc: str) -> str:
    fernet = Fernet(ENCRYPTION_KEY)
    return fernet.decrypt(enc.encode()).decode()


def _sentry_path(steam_username: str) -> Path:
    return SESSIONS_DIR / f"{steam_username}.sentry"


def _games_played_msg(app_ids: list[int], custom_title: str | None = None):
    """Build a ClientGamesPlayed protobuf message."""
    msg = MsgProto(EMsg.ClientGamesPlayed)
    for app_id in app_ids:
        game = msg.body.games_played.add()
        game.game_id = app_id
    if custom_title:
        game = msg.body.games_played.add()
        game.game_id = 0
        game.game_extra_info = custom_title
    return msg


class SteamIdler:
    def __init__(self, user_id: int):
        self.user_id = user_id
        self.log = logging.getLogger(f"worker.{user_id}")
        self._running = True
        self._session_start = None
        self._hours_at_start = 0.0

        # Handle SIGTERM from manager
        signal.signal(signal.SIGTERM, self._on_sigterm)

        self.client = SteamClient()
        self._wire_events()

    def _on_sigterm(self, *_):
        self.log.info("SIGTERM received – stopping gracefully")
        self._running = False
        self.client.logout()

    def _wire_events(self):
        client = self.client

        @client.on("update_machine_auth")
        def _on_sentry(sentry_data):
            path = _sentry_path(self._steam_username)
            path.write_bytes(sentry_data["bytes"])
            self.log.info("Sentry saved to %s", path)
            return {"sha_file": hashlib.sha1(sentry_data["bytes"]).digest()}

        @client.on("login_key")
        def _on_login_key(key):
            db.set_login_key(self.user_id, key)
            self.log.info("Persistent login key saved")

        @client.on("disconnected")
        def _on_disconnect():
            if self._running:
                self.log.warning("Disconnected – will reconnect")
                db.set_user_status(self.user_id, "error")

    # ------------------------------------------------------------------
    # Login
    # ------------------------------------------------------------------

    def _silent_login(self, username: str, login_key: str | None) -> EResult | None:
        """
        Attempt a non-interactive login that will NEVER trigger a 2FA prompt.

        Two paths qualify as "silent":
          1. We have a persistent login_key from a previous successful login.
          2. We have a sentry file on disk – the matching sentry_hash tells
             Steam this machine is already trusted, bypassing Steam Guard.

        Returns the EResult on success/failure, or None if no silent
        credentials are available (caller must fall back to password+2FA).
        """
        if login_key:
            self.log.info("Silent login via stored login_key")
            return self.client.login(username=username, login_key=login_key)

        sentry = _sentry_path(username)
        if sentry.exists():
            self.log.info("Silent login via sentry file %s", sentry)
            sentry_hash = hashlib.sha1(sentry.read_bytes()).digest()
            return self.client.login(
                username=username,
                password=self._password,
                sentry_hash=sentry_hash,
            )

        return None  # No silent path available – caller must do interactive login

    def _attempt_login(self, username: str, password: str | None, login_key: str | None) -> EResult:
        # 1. Try silent first – this is the normal path on every reboot/restart.
        silent_result = self._silent_login(username, login_key)
        if silent_result == EResult.OK:
            return silent_result
        if silent_result is not None and silent_result not in (
            EResult.InvalidPassword,
            EResult.AccountLogonDenied,
            EResult.AccountLoginDeniedNeedTwoFactor,
        ):
            # Fatal silent-login error – return as-is.
            return silent_result

        # 2. Fall back to plain password – this WILL trigger a 2FA prompt
        #    the first time, but only the first time.
        self.log.info("Falling back to password login (2FA may be required)")
        return self.client.login(username=username, password=password)

    def _handle_two_factor(self, username: str, password: str, result: EResult) -> EResult:
        if result == EResult.AccountLogonDenied:
            auth_type = "email"
        elif result == EResult.AccountLoginDeniedNeedTwoFactor:
            auth_type = "mobile"
        else:
            return result  # Not a 2FA issue

        self.log.info("2FA required (%s)", auth_type)
        db.set_pending_auth(self.user_id, auth_type)
        db.set_user_status(self.user_id, f"awaiting_2fa_{auth_type}")

        code = self._wait_for_2fa_code()
        db.clear_pending_auth(self.user_id)

        if not code:
            self.log.error("2FA timed out")
            db.set_user_status(self.user_id, "error")
            return EResult.Timeout

        login_kwargs = {"username": username, "password": password}
        if auth_type == "email":
            login_kwargs["auth_code"] = code
        else:
            login_kwargs["two_factor_code"] = code

        return self.client.login(**login_kwargs)

    def _wait_for_2fa_code(self) -> str | None:
        elapsed = 0
        while elapsed < TWO_FA_TIMEOUT:
            time.sleep(TWO_FA_POLL_SEC)
            elapsed += TWO_FA_POLL_SEC
            record = db.get_pending_auth(self.user_id)
            if record and record.get("code"):
                return record["code"]
        return None

    # ------------------------------------------------------------------
    # Idling
    # ------------------------------------------------------------------

    def _start_idling(self, user: dict):
        app_ids = db.get_user_games(self.user_id)
        if not app_ids:
            self.log.info("No games configured – staying online without idling")
        else:
            self.log.info("Idling %d games: %s", len(app_ids), app_ids)

        custom_title = user.get("custom_game_title")
        self.client.send(_games_played_msg(app_ids, custom_title))

        state_name = user.get("persona_state", "Online")
        state = PERSONA_STATE_MAP.get(state_name, EPersonaState.Online)
        self.client.change_status(persona_state=state)

        db.set_user_status(self.user_id, "idling" if app_ids else "online")

    def _stop_idling(self):
        self.client.send(_games_played_msg([]))
        db.set_user_status(self.user_id, "offline")
        self.log.info("Stopped idling")

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    def _heartbeat(self, user: dict) -> bool:
        """Return False if the worker should stop."""
        user_fresh = db.get_user(self.user_id)
        if not user_fresh:
            self.log.warning("User no longer exists in DB")
            return False

        if not user_fresh["idling_enabled"]:
            self.log.info("Idling disabled by user")
            return False

        max_hours = user.get("max_hours", -1)
        if max_hours != -1 and user_fresh["hours_idled"] >= max_hours:
            self.log.info("Hour limit reached (%.1f / %d)", user_fresh["hours_idled"], max_hours)
            return False

        elapsed = (time.time() - self._session_start) / 3600
        db.increment_hours(self.user_id, elapsed)
        self._session_start = time.time()
        return True

    def run(self):
        user = db.get_user(self.user_id)
        if not user:
            self.log.error("User %d not found in database", self.user_id)
            return

        self._steam_username = user["steam_username"]
        password = decrypt_password(user["steam_password_enc"]) if user.get("steam_password_enc") else None
        login_key = user.get("steam_login_key")
        self._password = password  # cached for sentry-based silent retry

        db.set_user_status(self.user_id, "connecting")
        result = self._attempt_login(self._steam_username, password, login_key)

        if result in (EResult.AccountLogonDenied, EResult.AccountLoginDeniedNeedTwoFactor):
            result = self._handle_two_factor(self._steam_username, password, result)

        if result != EResult.OK:
            self.log.error("Login failed: %s", result)
            db.set_user_status(self.user_id, "error")
            return

        self.log.info("Logged in as %s", self._steam_username)
        db.set_user_status(self.user_id, "online")

        self._start_idling(user)
        self._session_start = time.time()

        # Keep alive loop
        while self._running:
            time.sleep(HEARTBEAT_SEC)
            if not self._heartbeat(user):
                break

            # Re-read games/settings in case they changed
            user_fresh = db.get_user(self.user_id)
            if user_fresh:
                self._start_idling(user_fresh)
                user = user_fresh

        self._stop_idling()
        self.client.logout()
        self.log.info("Worker exiting cleanly")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Steam idling worker")
    parser.add_argument("--user-id", type=int, required=True)
    args = parser.parse_args()

    # Inject user_id into log records
    logging.getLogger().handlers[0].setFormatter(
        logging.Formatter(f"%(asctime)s [worker-{args.user_id}] %(levelname)s %(message)s")
    )

    db.init_db()
    SteamIdler(args.user_id).run()


if __name__ == "__main__":
    main()
