#!/usr/bin/env python3
"""
Flask web server for the Steam Hour Idler panel.

Run with PM2:
    pm2 start app.py --interpreter python3

Or directly:
    python3 app.py
"""

import os
import json
import logging
from functools import wraps

import bcrypt
from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session,
    jsonify,
    flash,
    abort,
)
from cryptography.fernet import Fernet
from dotenv import load_dotenv

load_dotenv()
import database as db

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------
app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "change-me-insecure-default")

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("app")

ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY", "").encode()

POPULAR_GAMES = [
    (730,   "Counter-Strike 2"),
    (440,   "Team Fortress 2"),
    (570,   "Dota 2"),
    (578080,"PUBG: Battlegrounds"),
    (1172470,"Apex Legends"),
    (252490,"Rust"),
    (304930,"Unturned"),
    (4000,  "Garry's Mod"),
    (72850, "The Elder Scrolls V: Skyrim"),
    (271590,"Grand Theft Auto V"),
    (236390,"War Thunder"),
    (374320,"Dark Souls III"),
    (230410,"Warframe"),
    (238960,"Path of Exile"),
    (553850,"Helldivers 2"),
]


def _fernet():
    return Fernet(ENCRYPTION_KEY)


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def check_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode(), hashed.encode())


def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login_page"))
        return f(*args, **kwargs)
    return wrapper


def current_user():
    uid = session.get("user_id")
    return db.get_user(uid) if uid else None


# ---------------------------------------------------------------------------
# Pages
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    plans = db.get_all_plans()
    for p in plans:
        p["features"] = json.loads(p["features"])
    return render_template("index.html", plans=plans)


@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    plan = db.get_plan(user["plan_id"])
    plan["features"] = json.loads(plan["features"])
    games = db.get_user_games(user["id"])
    return render_template(
        "dashboard.html",
        user=user,
        plan=plan,
        games=games,
        popular_games=POPULAR_GAMES,
    )


@app.route("/login", methods=["GET"])
def login_page():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return render_template("index.html", show_login=True, plans=_plans_with_features())


@app.route("/register", methods=["GET"])
def register_page():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return render_template("index.html", show_register=True, plans=_plans_with_features())


def _plans_with_features():
    plans = db.get_all_plans()
    for p in plans:
        p["features"] = json.loads(p["features"])
    return plans


# ---------------------------------------------------------------------------
# Auth API
# ---------------------------------------------------------------------------

@app.route("/api/register", methods=["POST"])
def api_register():
    data = request.get_json(force=True)
    username = (data.get("username") or "").strip()
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    if not username or not email or not password:
        return jsonify({"error": "All fields are required"}), 400
    if len(password) < 8:
        return jsonify({"error": "Password must be at least 8 characters"}), 400
    if db.get_user_by_username(username):
        return jsonify({"error": "Username already taken"}), 409
    if db.get_user_by_email(email):
        return jsonify({"error": "Email already registered"}), 409

    uid = db.create_user(username, email, hash_password(password))
    session["user_id"] = uid
    return jsonify({"ok": True, "redirect": url_for("dashboard")})


@app.route("/api/login", methods=["POST"])
def api_login():
    data = request.get_json(force=True)
    identifier = (data.get("username") or "").strip()
    password = data.get("password") or ""

    user = db.get_user_by_username(identifier) or db.get_user_by_email(identifier)
    if not user or not check_password(password, user["password_hash"]):
        return jsonify({"error": "Invalid credentials"}), 401

    session["user_id"] = user["id"]
    return jsonify({"ok": True, "redirect": url_for("dashboard")})


@app.route("/api/logout", methods=["POST"])
def api_logout():
    session.clear()
    return jsonify({"ok": True, "redirect": url_for("index")})


# ---------------------------------------------------------------------------
# Steam account API
# ---------------------------------------------------------------------------

@app.route("/api/connect-steam", methods=["POST"])
@login_required
def api_connect_steam():
    data = request.get_json(force=True)
    steam_username = (data.get("steam_username") or "").strip()
    steam_password = data.get("steam_password") or ""

    if not steam_username or not steam_password:
        return jsonify({"error": "Steam username and password are required"}), 400

    enc_password = _fernet().encrypt(steam_password.encode()).decode()
    db.set_user_steam_credentials(session["user_id"], steam_username, enc_password)

    # Clear any stale login key so manager re-authenticates
    db.set_login_key(session["user_id"], None)
    db.clear_pending_auth(session["user_id"])

    return jsonify({"ok": True, "message": "Steam credentials saved. Start idling to connect."})


@app.route("/api/submit-2fa", methods=["POST"])
@login_required
def api_submit_2fa():
    data = request.get_json(force=True)
    code = (data.get("code") or "").strip()
    if not code:
        return jsonify({"error": "Code is required"}), 400

    pending = db.get_pending_auth(session["user_id"])
    if not pending:
        return jsonify({"error": "No 2FA challenge pending"}), 400

    db.submit_2fa_code(session["user_id"], code)
    return jsonify({"ok": True, "message": "Code submitted"})


# ---------------------------------------------------------------------------
# Idling control API
# ---------------------------------------------------------------------------

@app.route("/api/start-idling", methods=["POST"])
@login_required
def api_start_idling():
    user = current_user()
    if not user["steam_username"]:
        return jsonify({"error": "No Steam account connected"}), 400

    db.set_idling_enabled(user["id"], True)
    return jsonify({"ok": True, "message": "Idling enabled – manager will connect shortly"})


@app.route("/api/stop-idling", methods=["POST"])
@login_required
def api_stop_idling():
    uid = session["user_id"]
    db.set_idling_enabled(uid, False)
    db.set_user_status(uid, "offline")
    return jsonify({"ok": True, "message": "Idling stopped"})


@app.route("/api/status", methods=["GET"])
@login_required
def api_status():
    user = db.get_user(session["user_id"])
    pending = db.get_pending_auth(user["id"])
    return jsonify({
        "status":         user["status"],
        "hours_idled":    round(user["hours_idled"], 2),
        "idling_enabled": bool(user["idling_enabled"]),
        "pending_auth":   {"auth_type": pending["auth_type"]} if pending else None,
    })


# ---------------------------------------------------------------------------
# Settings API
# ---------------------------------------------------------------------------

@app.route("/api/update-games", methods=["POST"])
@login_required
def api_update_games():
    user = current_user()
    plan = db.get_plan(user["plan_id"])
    data = request.get_json(force=True)
    raw_ids = data.get("app_ids") or []

    try:
        app_ids = [int(x) for x in raw_ids if str(x).strip()]
    except (ValueError, TypeError):
        return jsonify({"error": "Invalid app IDs"}), 400

    app_ids = list(dict.fromkeys(app_ids))  # deduplicate preserving order
    if len(app_ids) > plan["max_games"]:
        return jsonify({"error": f"Your plan allows max {plan['max_games']} games"}), 400

    db.set_user_games(user["id"], app_ids)
    return jsonify({"ok": True, "games": app_ids})


@app.route("/api/update-settings", methods=["POST"])
@login_required
def api_update_settings():
    user = current_user()
    plan = db.get_plan(user["plan_id"])
    features = json.loads(plan["features"])
    data = request.get_json(force=True)

    persona_state = data.get("persona_state")
    custom_status = data.get("custom_status")
    custom_game_title = data.get("custom_game_title")

    if persona_state and persona_state == "Invisible" and "Hide Activity" not in features:
        return jsonify({"error": "Invisible mode requires Basic plan or higher"}), 403
    if custom_status and "Custom Status" not in features:
        return jsonify({"error": "Custom status requires Basic plan or higher"}), 403
    if custom_game_title and "Custom In-Game Title" not in features:
        return jsonify({"error": "Custom In-Game Title requires Plus plan or higher"}), 403

    db.update_settings(user["id"], persona_state, custom_status, custom_game_title)
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    db.init_db()
    port = int(os.getenv("PORT", "5000"))
    debug = os.getenv("FLASK_DEBUG", "0") == "1"
    log.info("Starting Flask on port %d (debug=%s)", port, debug)
    app.run(host="0.0.0.0", port=port, debug=debug)
