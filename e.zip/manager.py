#!/usr/bin/env python3
"""
Steam Idler Manager – run with PM2:
    pm2 start manager.py --interpreter python3

Monitors the database and maintains one steam_client.py subprocess per active user.
Uses a randomised login delay (0.5–5.0 s) between each new process to avoid
IP rate-limiting on the VPS.
"""

import os
import sys
import time
import random
import logging
import signal
import subprocess
from pathlib import Path

from dotenv import load_dotenv
load_dotenv()

import database as db

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
POLL_INTERVAL = int(os.getenv("MANAGER_POLL_INTERVAL", "30"))   # seconds
MIN_LOGIN_DELAY = 0.5
MAX_LOGIN_DELAY = 5.0
WORKER_SCRIPT = str(Path(__file__).parent / "steam_client.py")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [manager] %(levelname)s %(message)s",
)
log = logging.getLogger("manager")

# user_id -> subprocess.Popen
_processes: dict[int, subprocess.Popen] = {}

_shutdown = False


def _on_sigterm(*_):
    global _shutdown
    log.info("SIGTERM received – shutting down all workers")
    _shutdown = True
    for uid, proc in list(_processes.items()):
        _terminate(uid, proc)


signal.signal(signal.SIGTERM, _on_sigterm)
signal.signal(signal.SIGINT, _on_sigterm)


# ---------------------------------------------------------------------------
# Process helpers
# ---------------------------------------------------------------------------

def _terminate(user_id: int, proc: subprocess.Popen):
    if proc.poll() is None:
        log.info("Stopping worker for user %d (pid %d)", user_id, proc.pid)
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
    _processes.pop(user_id, None)


def _start_worker(user_id: int):
    log.info("Starting worker for user %d", user_id)
    proc = subprocess.Popen(
        [sys.executable, WORKER_SCRIPT, "--user-id", str(user_id)],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    _processes[user_id] = proc

    # Forward worker stdout to manager log (non-blocking via daemon thread)
    import threading

    def _relay(p, uid):
        for line in iter(p.stdout.readline, b""):
            log.info("[worker-%d] %s", uid, line.decode().rstrip())

    t = threading.Thread(target=_relay, args=(proc, user_id), daemon=True)
    t.start()


def _staggered_start(user_id: int):
    """Start a worker then sleep a random delay to stagger logins."""
    _start_worker(user_id)
    delay = random.uniform(MIN_LOGIN_DELAY, MAX_LOGIN_DELAY)
    log.debug("Login delay %.2fs after user %d", delay, user_id)
    time.sleep(delay)


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------

def _reconcile():
    """Bring running processes in line with the desired state in the DB."""
    wanted_users = {u["id"]: u for u in db.get_users_to_idle()}
    wanted_ids = set(wanted_users)
    running_ids = set(_processes)

    # --- Stop processes no longer wanted ---
    for uid in running_ids - wanted_ids:
        _terminate(uid, _processes[uid])

    # --- Start / restart processes ---
    for uid, user in wanted_users.items():
        proc = _processes.get(uid)
        if proc is None or proc.poll() is not None:
            # Process missing or crashed
            if proc is not None:
                exit_code = proc.poll()
                log.warning("Worker for user %d crashed (exit %d) – restarting", uid, exit_code)
                db.set_user_status(uid, "error")
                _processes.pop(uid)
            _staggered_start(uid)

    if _processes:
        log.info("Active workers: %s", list(_processes))


def main():
    log.info("Steam Idler Manager starting (poll every %ds)", POLL_INTERVAL)
    db.init_db()

    while not _shutdown:
        try:
            _reconcile()
        except Exception as exc:
            log.exception("Reconcile error: %s", exc)
        time.sleep(POLL_INTERVAL)

    log.info("Manager exited")


if __name__ == "__main__":
    main()
