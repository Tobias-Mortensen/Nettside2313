"""SQLite database schema and helper functions."""

import sqlite3
import os
import json
from datetime import datetime
from pathlib import Path

DATABASE_PATH = os.getenv("DATABASE_PATH", "steam_idler.db")


def get_conn():
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    conn = get_conn()
    c = conn.cursor()

    c.executescript("""
        CREATE TABLE IF NOT EXISTS plans (
            id          INTEGER PRIMARY KEY,
            name        TEXT    NOT NULL UNIQUE,
            price       REAL    NOT NULL,
            max_hours   INTEGER NOT NULL,   -- -1 = unlimited
            max_games   INTEGER NOT NULL,
            features    TEXT    NOT NULL DEFAULT '[]'  -- JSON array of feature strings
        );

        CREATE TABLE IF NOT EXISTS users (
            id                      INTEGER PRIMARY KEY AUTOINCREMENT,
            username                TEXT    NOT NULL UNIQUE,
            email                   TEXT    NOT NULL UNIQUE,
            password_hash           TEXT    NOT NULL,
            steam_username          TEXT,
            steam_password_enc      TEXT,   -- Fernet-encrypted; NULL after login_key obtained
            steam_login_key         TEXT,   -- Persistent re-auth token from Steam
            plan_id                 INTEGER NOT NULL DEFAULT 1 REFERENCES plans(id),
            hours_idled             REAL    NOT NULL DEFAULT 0,
            idling_enabled          INTEGER NOT NULL DEFAULT 0,  -- 1 = user wants idling
            status                  TEXT    NOT NULL DEFAULT 'offline',
                                            -- offline | connecting | awaiting_2fa_email
                                            -- | awaiting_2fa_mobile | online | idling | error
            persona_state           TEXT    NOT NULL DEFAULT 'Online',
            custom_status           TEXT,
            custom_game_title       TEXT,
            created_at              TEXT    NOT NULL DEFAULT (datetime('now')),
            last_seen               TEXT
        );

        CREATE TABLE IF NOT EXISTS user_games (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            app_id      INTEGER NOT NULL,
            sort_order  INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS pending_auth (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
            auth_type   TEXT    NOT NULL,   -- 'email' | 'mobile'
            code        TEXT,               -- filled in by web frontend
            created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS idling_sessions (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            started_at      TEXT    NOT NULL DEFAULT (datetime('now')),
            ended_at        TEXT,
            hours_earned    REAL    NOT NULL DEFAULT 0
        );
    """)

    _seed_plans(c)
    conn.commit()
    conn.close()


def _seed_plans(c):
    plans = [
        (1, "Free",     0.00,  500,    3,  json.dumps(["Auto-Restarter"])),
        (2, "Basic",    0.50,  2000,  10,  json.dumps(["Auto-Restarter", "Custom Status", "Hide Activity"])),
        (3, "Plus",     1.00,  5000,  20,  json.dumps(["Auto-Restarter", "Custom Status", "Hide Activity",
                                                         "Away Message", "Custom In-Game Title"])),
        (4, "Ultimate", 5.00,  15000, 32,  json.dumps(["Auto-Restarter", "Custom Status", "Hide Activity",
                                                         "Away Message", "Custom In-Game Title", "Priority Idling"])),
        (5, "Lifetime", 15.00, -1,    32,  json.dumps(["Auto-Restarter", "Custom Status", "Hide Activity",
                                                         "Away Message", "Custom In-Game Title", "Priority Idling",
                                                         "Lifetime Access"])),
    ]
    c.executemany(
        "INSERT OR IGNORE INTO plans (id, name, price, max_hours, max_games, features) VALUES (?,?,?,?,?,?)",
        plans,
    )


# ---------------------------------------------------------------------------
# User helpers
# ---------------------------------------------------------------------------

def get_user(user_id):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        return dict(row) if row else None


def get_user_by_username(username):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        return dict(row) if row else None


def get_user_by_email(email):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        return dict(row) if row else None


def create_user(username, email, password_hash, plan_id=1):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO users (username, email, password_hash, plan_id) VALUES (?,?,?,?)",
            (username, email, password_hash, plan_id),
        )
        conn.commit()
        return conn.execute("SELECT last_insert_rowid()").fetchone()[0]


def set_user_steam_credentials(user_id, steam_username, encrypted_password):
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET steam_username=?, steam_password_enc=?, status='connecting' WHERE id=?",
            (steam_username, encrypted_password, user_id),
        )
        conn.commit()


def set_login_key(user_id, login_key):
    """Store the persistent Steam login key and clear the encrypted password."""
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET steam_login_key=?, steam_password_enc=NULL WHERE id=?",
            (login_key, user_id),
        )
        conn.commit()


def set_user_status(user_id, status):
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET status=?, last_seen=datetime('now') WHERE id=?",
            (status, user_id),
        )
        conn.commit()


def set_idling_enabled(user_id, enabled):
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET idling_enabled=? WHERE id=?",
            (1 if enabled else 0, user_id),
        )
        conn.commit()


def increment_hours(user_id, delta_hours):
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET hours_idled = hours_idled + ? WHERE id=?",
            (delta_hours, user_id),
        )
        conn.commit()


def update_settings(user_id, persona_state=None, custom_status=None, custom_game_title=None):
    fields, vals = [], []
    if persona_state is not None:
        fields.append("persona_state=?")
        vals.append(persona_state)
    if custom_status is not None:
        fields.append("custom_status=?")
        vals.append(custom_status or None)
    if custom_game_title is not None:
        fields.append("custom_game_title=?")
        vals.append(custom_game_title or None)
    if not fields:
        return
    vals.append(user_id)
    with get_conn() as conn:
        conn.execute(f"UPDATE users SET {', '.join(fields)} WHERE id=?", vals)
        conn.commit()


# ---------------------------------------------------------------------------
# Game helpers
# ---------------------------------------------------------------------------

def get_user_games(user_id):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT app_id FROM user_games WHERE user_id=? ORDER BY sort_order",
            (user_id,),
        ).fetchall()
        return [r["app_id"] for r in rows]


def set_user_games(user_id, app_ids):
    with get_conn() as conn:
        conn.execute("DELETE FROM user_games WHERE user_id=?", (user_id,))
        conn.executemany(
            "INSERT INTO user_games (user_id, app_id, sort_order) VALUES (?,?,?)",
            [(user_id, aid, i) for i, aid in enumerate(app_ids)],
        )
        conn.commit()


# ---------------------------------------------------------------------------
# 2FA helpers
# ---------------------------------------------------------------------------

def set_pending_auth(user_id, auth_type):
    with get_conn() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO pending_auth (user_id, auth_type, code, created_at) VALUES (?,?,NULL,datetime('now'))",
            (user_id, auth_type),
        )
        conn.commit()


def get_pending_auth(user_id):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM pending_auth WHERE user_id=?", (user_id,)
        ).fetchone()
        return dict(row) if row else None


def submit_2fa_code(user_id, code):
    with get_conn() as conn:
        conn.execute(
            "UPDATE pending_auth SET code=? WHERE user_id=?",
            (code, user_id),
        )
        conn.commit()


def clear_pending_auth(user_id):
    with get_conn() as conn:
        conn.execute("DELETE FROM pending_auth WHERE user_id=?", (user_id,))
        conn.commit()


# ---------------------------------------------------------------------------
# Plan helpers
# ---------------------------------------------------------------------------

def get_plan(plan_id):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM plans WHERE id=?", (plan_id,)).fetchone()
        return dict(row) if row else None


def get_all_plans():
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM plans ORDER BY price").fetchall()
        return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Manager helpers
# ---------------------------------------------------------------------------

def get_users_to_idle():
    """Return all users who want idling and have Steam credentials."""
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT u.id, u.steam_username, u.steam_password_enc, u.steam_login_key,
                   u.persona_state, u.custom_status, u.custom_game_title,
                   u.hours_idled, u.status,
                   p.max_hours, p.max_games
            FROM users u
            JOIN plans p ON u.plan_id = p.id
            WHERE u.idling_enabled = 1
              AND u.steam_username IS NOT NULL
              AND (u.steam_password_enc IS NOT NULL OR u.steam_login_key IS NOT NULL)
        """).fetchall()
        return [dict(r) for r in rows]


if __name__ == "__main__":
    init_db()
    print("Database initialised at", DATABASE_PATH)
