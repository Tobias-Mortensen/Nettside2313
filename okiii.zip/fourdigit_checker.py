import aiohttp
import asyncio
import json
import string
import time
import random
import ssl
import os
from colorama import Fore, init
from datetime import datetime

init(autoreset=True)


class Discord4DigitChecker:
    def __init__(self, webhook_url, concurrency=50, use_proxies=False):
        self.webhook_url = webhook_url
        self.concurrency = concurrency
        self.use_proxies = use_proxies

        self.proxies = []
        self.checked = 0
        self.available = 0
        self.unavailable = 0
        self.errors = 0
        self.rate_limits = 0
        self.start_time = time.time()
        
        # Error warning tracking
        self.error_warning_sent = False
        self.error_threshold = 13.0  # 13% error threshold

        # Per-proxy rate limiting
        self.proxy_times = {}
        self.no_proxy_lock = asyncio.Lock() if not use_proxies else None
        self.no_proxy_last = 0.0

        # Webhook queue for non-blocking sends
        self.webhook_queue = asyncio.Queue()

        # Resume functionality
        self.checked_file = 'checked_4digit.txt'
        self.available_file = 'available_4digit.txt'
        self.progress_file = 'progress_4digit.json'
        
        self.checked_set = self._load_checked()
        self._save_progress_periodically = True

        # Build all 4-digit combos (numbers only: 0000-9999)
        print(f"{Fore.CYAN}[*] Generating 4-digit combinations...")
        self.remaining = []
        for num in range(10000):  # 0 to 9999
            username = f"{num:04d}"  # Format as 4 digits with leading zeros
            if username not in self.checked_set:
                self.remaining.append(username)
        
        # Shuffle for random checking
        random.shuffle(self.remaining)
        
        print(f"{Fore.GREEN}[+] Generated {len(self.remaining):,} usernames to check")

        self.api_url = "https://discord.com/api/v9/unique-username/username-attempt-unauthed"
        
        # SSL context for proxies
        self.ssl_ctx = ssl.create_default_context()
        self.ssl_ctx.check_hostname = False
        self.ssl_ctx.verify_mode = ssl.CERT_NONE

        if self.use_proxies:
            self.load_proxies()

    def _load_checked(self):
        """Load previously checked usernames to avoid duplicates"""
        try:
            with open(self.checked_file, 'r') as f:
                loaded = set(line.strip() for line in f if line.strip())
            print(f"{Fore.GREEN}[+] Loaded {len(loaded):,} already-checked usernames")
            return loaded
        except FileNotFoundError:
            print(f"{Fore.CYAN}[*] No previous progress found, starting fresh")
            return set()

    def _save_checked(self, username):
        """Save checked username to file immediately"""
        self.checked_set.add(username)
        with open(self.checked_file, 'a', buffering=1) as f:  # Line buffered
            f.write(f"{username}\n")

    def _save_progress(self):
        """Save progress stats to JSON"""
        try:
            progress = {
                "checked": self.checked,
                "available": self.available,
                "unavailable": self.unavailable,
                "errors": self.errors,
                "rate_limits": self.rate_limits,
                "remaining": len(self.remaining),
                "last_updated": datetime.utcnow().isoformat()
            }
            with open(self.progress_file, 'w') as f:
                json.dump(progress, f, indent=2)
        except Exception as e:
            print(f"{Fore.RED}[!] Failed to save progress: {e}")

    def load_proxies(self):
        """Load proxies from proxies.txt"""
        try:
            with open('proxies.txt', 'r', encoding='utf-8') as f:
                self.proxies = [line.strip() for line in f if line.strip() and not line.startswith('#')]
            
            if self.proxies:
                print(f"{Fore.GREEN}[+] Loaded {len(self.proxies):,} proxies")
                # Initialize rate limit tracking for each proxy
                for i in range(len(self.proxies)):
                    self.proxy_times[i] = 0.0
            else:
                print(f"{Fore.YELLOW}[!] proxies.txt is empty, running proxyless")
                self.use_proxies = False
        except FileNotFoundError:
            print(f"{Fore.YELLOW}[!] proxies.txt not found, running proxyless")
            self.use_proxies = False

    def format_proxy(self, proxy_line):
        """Format proxy string to URL"""
        # Strip http:// or https:// prefix if present
        if proxy_line.startswith('http://'):
            proxy_line = proxy_line[7:]  # Remove 'http://'
        elif proxy_line.startswith('https://'):
            proxy_line = proxy_line[8:]  # Remove 'https://'
        
        parts = proxy_line.split(':')
        if len(parts) == 4:
            # Format: host:port:username:password
            # OR: IP:PORT:USERNAME__cr.countries:PASSWORD
            host, port, username, password = parts
            return f'http://{username}:{password}@{host}:{port}'
        elif len(parts) > 4:
            # Handle passwords/usernames with colons
            host = parts[0]
            port = parts[1]
            username = parts[2]
            password = ':'.join(parts[3:])  # Join remaining parts as password
            return f'http://{username}:{password}@{host}:{port}'
        elif len(parts) == 2:
            return f'http://{parts[0]}:{parts[1]}'
        return None

    async def check_username(self, session, username, proxy_idx=None):
        """Check if a username is available"""
        # Per-proxy rate limiting (0.3s between requests per proxy)
        if self.use_proxies and proxy_idx is not None:
            now = time.monotonic()
            last = self.proxy_times.get(proxy_idx, 0.0)
            wait = 0.2 - (now - last)  # FASTER
            if wait > 0:
                await asyncio.sleep(wait)
            self.proxy_times[proxy_idx] = time.monotonic()
        
        # Global rate limiting when not using proxies
        elif not self.use_proxies:
            async with self.no_proxy_lock:
                now = time.monotonic()
                wait = 0.4 - (now - self.no_proxy_last)  # FASTER
                if wait > 0:
                    await asyncio.sleep(wait)
                self.no_proxy_last = time.monotonic()

        headers = {
            'Content-Type': 'application/json',
            
        }
        payload = {'username': username}

        proxy_url = None
        if self.use_proxies and proxy_idx is not None:
            proxy_url = self.format_proxy(self.proxies[proxy_idx])

        try:
            async with session.post(
                self.api_url,
                json=payload,
                headers=headers,
                proxy=proxy_url,
                timeout=aiohttp.ClientTimeout(total=5)  # FASTER,
                ssl=self.ssl_ctx,
                compress=True  # Save bandwidth
            ) as resp:
                self.checked += 1

                if resp.status == 200:
                    data = await resp.json()
                    self._save_checked(username)
                    
                    if not data.get('taken', True):
                        return True  # Available!
                    return False  # Taken
                
                elif resp.status == 429:
                    self.rate_limits += 1
                    if self.rate_limits % 100 == 0:
                        print(f"{Fore.YELLOW}[!] Rate limiting ({self.rate_limits:,} total)")
                    await asyncio.sleep(random.uniform(2, 3))  # FASTER
                    return None
                
                elif resp.status in [403, 401]:
                    self.errors += 1
                    if self.errors <= 5:
                        print(f"{Fore.RED}[!] Blocked by Discord ({resp.status})")
                    return None
                
                else:
                    self.errors += 1
                    return False

        except (aiohttp.ClientProxyConnectionError, aiohttp.ClientHttpProxyError):
            self.errors += 1
            return None
        except asyncio.TimeoutError:
            self.errors += 1
            return None
        except Exception as e:
            self.errors += 1
            if self.errors <= 5:
                print(f"{Fore.RED}[!] Error: {type(e).__name__}")
            return None

    async def queue_webhook(self, username):
        """Queue webhook notification for available username"""
        embed = {
            "title": "🎯 4-Digit Username Available!",
            "description": f"**Username:** `{username}`",
            "color": 0xffd700,
            "timestamp": datetime.utcnow().isoformat(),
            "footer": {"text": f"Checked: {self.checked:,} | Available: {self.available}"}
        }
        payload = {"embeds": [embed], "username": "4-Digit Checker"}
        await self.webhook_queue.put((self.webhook_url, payload))

    async def send_error_warning(self):
        """Send one-time warning if error rate exceeds threshold"""
        if self.error_warning_sent:
            return
        
        error_rate = (self.errors / self.checked * 100) if self.checked > 0 else 0
        
        if error_rate > self.error_threshold and self.checked > 100:
            self.error_warning_sent = True
            
            embed = {
                "title": "⚠️ High Error Rate Warning",
                "description": f"Error rate has exceeded {self.error_threshold}%!",
                "color": 0xff0000,
                "fields": [
                    {"name": "Current Error Rate", "value": f"{error_rate:.1f}%", "inline": True},
                    {"name": "Total Errors", "value": f"{self.errors:,}", "inline": True},
                    {"name": "Checked", "value": f"{self.checked:,}", "inline": True},
                    {"name": "Recommendation", "value": "Check your proxies or reduce concurrency", "inline": False}
                ],
                "timestamp": datetime.utcnow().isoformat()
            }
            payload = {"embeds": [embed], "username": "4-Digit Checker - Alert"}
            await self.webhook_queue.put((self.webhook_url, payload))

    async def webhook_sender(self, session):
        """Background task to send webhooks without blocking"""
        while True:
            url, payload = await self.webhook_queue.get()
            
            # Retry up to 3 times
            for attempt in range(3):
                try:
                    async with session.post(url, json=payload, timeout=aiohttp.ClientTimeout(total=5)  # FASTER) as resp:
                        if resp.status == 429:
                            # Webhook rate limited
                            data = await resp.json()
                            retry_after = data.get('retry_after', 2)
                            await asyncio.sleep(retry_after)
                            continue
                        if resp.status in (200, 204):
                            break
                except Exception:
                    await asyncio.sleep(1)
            
            # Small delay between webhooks
            await asyncio.sleep(2.5)
            self.webhook_queue.task_done()

    def save_available(self, username):
        """Save available username to file"""
        with open(self.available_file, 'a', buffering=1) as f:
            f.write(f"{username}\n")

    async def worker(self, session, sem, username, proxy_idx):
        """Worker coroutine to check a single username"""
        async with sem:
            result = await self.check_username(session, username, proxy_idx)

            if result is True:
                self.available += 1
                print(f"{Fore.YELLOW}[★★★] AVAILABLE: {username}")
                await self.queue_webhook(username)
                self.save_available(username)
            elif result is False:
                self.unavailable += 1
                if self.unavailable % 1000 == 0:  # Print every 1000th taken
                    print(f"{Fore.RED}[-] Taken: {username}")

    def get_stats(self):
        """Get current statistics string"""
        elapsed = time.time() - self.start_time
        rps = self.checked / elapsed if elapsed > 0 else 0
        remaining = len(self.remaining)
        total = 10000  # 10,000 total 4-digit combos
        done = total - remaining
        pct = done / total * 100
        
        error_rate = (self.errors / self.checked * 100) if self.checked > 0 else 0
        rl_rate = (self.rate_limits / self.checked * 100) if self.checked > 0 else 0
        
        return (
            f"{Fore.CYAN}[Stats] "
            f"Checked: {self.checked:,} | "
            f"Available: {Fore.YELLOW}{self.available}{Fore.CYAN} | "
            f"Taken: {self.unavailable:,} | "
            f"Errors: {Fore.RED}{self.errors:,} ({error_rate:.1f}%){Fore.CYAN} | "
            f"RateLimits: {self.rate_limits:,} ({rl_rate:.1f}%) | "
            f"RPS: {rps:.2f} | "
            f"Remaining: {remaining:,}/{total:,} ({pct:.1f}% done)"
        )

    async def stats_printer(self):
        """Background task to print stats periodically"""
        while self._save_progress_periodically:
            await asyncio.sleep(5)
            print(self.get_stats())
            # Save progress every 5 seconds
            self._save_progress()
            # Check and send error warning if needed
            await self.send_error_warning()

    async def start(self):
        """Start checking usernames"""
        print(f"\n{Fore.MAGENTA}{'='*80}")
        print(f"{Fore.MAGENTA}Discord 4-Digit Username Checker (0000-9999)")
        print(f"{Fore.MAGENTA}{'='*80}\n")

        total = 10000
        already_checked = total - len(self.remaining)
        
        print(f"{Fore.CYAN}[*] Total 4-digit combos: {total:,}")
        print(f"{Fore.GREEN}[*] Already checked: {already_checked:,}")
        print(f"{Fore.YELLOW}[*] Remaining to check: {len(self.remaining):,}\n")

        if not self.remaining:
            print(f"{Fore.GREEN}[+] All 4-digit usernames have been checked!")
            return

        # Calculate optimal concurrency
        num_proxies = len(self.proxies) if self.use_proxies else 1
        effective_concurrency = min(self.concurrency, num_proxies * 3) if self.use_proxies else 5

        sem = asyncio.Semaphore(effective_concurrency)
        connector = aiohttp.TCPConnector(
            limit=effective_concurrency * 4,
            limit_per_host=100,
            ttl_dns_cache=600,
            ssl=self.ssl_ctx
        )

        if not self.use_proxies:
            self.no_proxy_lock = asyncio.Lock()

        print(f"{Fore.GREEN}[+] Concurrency: {effective_concurrency}")
        print(f"{Fore.GREEN}[+] Proxies: {num_proxies:,} {'(rotating)' if self.use_proxies else ''}")
        print(f"{Fore.CYAN}[*] Progress auto-saved every 5 seconds")
        print(f"{Fore.CYAN}[*] Press Ctrl+C to stop (progress will be saved)\n")

        # Start background tasks
        stats_task = asyncio.create_task(self.stats_printer())

        try:
            async with aiohttp.ClientSession(connector=connector) as session:
                # Start webhook senders
                wh_tasks = [asyncio.create_task(self.webhook_sender(session)) for _ in range(2)]

                # Process usernames in batches
                while self.remaining:
                    batch_size = min(effective_concurrency * 5, len(self.remaining))
                    batch = [self.remaining.pop() for _ in range(batch_size)]
                    
                    tasks = []
                    for i, username in enumerate(batch):
                        proxy_idx = i % num_proxies if self.use_proxies else None
                        tasks.append(self.worker(session, sem, username, proxy_idx))
                    
                    await asyncio.gather(*tasks, return_exceptions=True)

                print(f"\n{Fore.GREEN}[✓] All 4-digit usernames checked!")

        except (KeyboardInterrupt, asyncio.CancelledError):
            print(f"\n{Fore.YELLOW}[!] Stopping gracefully...")
            print(f"{Fore.YELLOW}[*] Remaining: {len(self.remaining):,} usernames")
            
            # Wait for queued webhooks to send
            if not self.webhook_queue.empty():
                print(f"{Fore.YELLOW}[*] Sending {self.webhook_queue.qsize()} queued webhooks...")
                await self.webhook_queue.join()
            
            # Save final progress
            self._save_progress()
            print(f"{Fore.GREEN}[✓] Progress saved!")
            
        finally:
            self._save_progress_periodically = False
            stats_task.cancel()
            for t in wh_tasks:
                t.cancel()

        # Final stats
        print(f"\n{Fore.MAGENTA}{'='*80}")
        print(self.get_stats())
        print(f"{Fore.MAGENTA}{'='*80}")
        
        if self.available > 0:
            print(f"{Fore.YELLOW}[★] Found {self.available} available 4-digit usernames!")
            print(f"{Fore.GREEN}[✓] Saved to: {self.available_file}")


# Configuration management
CONFIG_FILE = 'config_4digit.json'

DEFAULT_CONFIG = {
    "webhook": "PASTE_YOUR_DISCORD_WEBHOOK_URL_HERE",
    "use_proxies": True,
    "concurrency": 300
}


def load_config():
    """Load configuration from JSON file"""
    try:
        with open(CONFIG_FILE, 'r') as f:
            cfg = json.load(f)
        print(f"{Fore.GREEN}[+] Loaded settings from {CONFIG_FILE}")
        return {**DEFAULT_CONFIG, **cfg}
    except FileNotFoundError:
        return None
    except json.JSONDecodeError:
        print(f"{Fore.RED}[!] {CONFIG_FILE} is invalid JSON, ignoring")
        return None


def save_config(cfg):
    """Save configuration to JSON file"""
    with open(CONFIG_FILE, 'w') as f:
        json.dump(cfg, f, indent=2)


if __name__ == "__main__":
    print(f"{Fore.CYAN}{'='*60}")
    print(f"{Fore.CYAN}  Discord 4-Digit Username Checker")
    print(f"{Fore.CYAN}  Checks: 0000-9999 (10,000 total combinations)")
    print(f"{Fore.CYAN}{'='*60}\n")

    # Check if config exists, create if not
    if not os.path.exists(CONFIG_FILE):
        print(f"{Fore.YELLOW}[!] Config file not found!")
        print(f"{Fore.CYAN}[*] Creating default config: {CONFIG_FILE}")
        save_config(DEFAULT_CONFIG)
        print(f"\n{Fore.GREEN}[+] Config file created!")
        print(f"{Fore.YELLOW}[!] Please edit {CONFIG_FILE} and fill in your settings:")
        print(f"{Fore.CYAN}    1. Add your Discord webhook URL")
        print(f"{Fore.CYAN}    2. Set use_proxies: true/false")
        print(f"{Fore.CYAN}    3. Set concurrency (recommended: proxies × 3)")
        print(f"\n{Fore.WHITE}Example config:")
        print(f'{Fore.CYAN}{{')
        print(f'  "webhook": "https://discord.com/api/webhooks/...",')
        print(f'  "use_proxies": true,')
        print(f'  "concurrency": 300')
        print(f'}}')
        exit(0)

    # Load config
    cfg = load_config()
    
    # Validate config
    if not cfg or not cfg.get("webhook") or cfg["webhook"] == "PASTE_YOUR_DISCORD_WEBHOOK_URL_HERE":
        print(f"{Fore.RED}[!] Error: webhook not configured in {CONFIG_FILE}")
        print(f"{Fore.YELLOW}[!] Please edit {CONFIG_FILE} and add your webhook URL")
        print(f"{Fore.CYAN}[*] Replace 'PASTE_YOUR_DISCORD_WEBHOOK_URL_HERE' with your actual webhook")
        exit(1)

    # Show loaded config
    print(f"{Fore.GREEN}[✓] Configuration loaded:")
    print(f"{Fore.CYAN}  Webhook:     {cfg['webhook'][:50]}...")
    print(f"{Fore.CYAN}  Proxies:     {'Enabled' if cfg['use_proxies'] else 'Disabled'}")
    print(f"{Fore.CYAN}  Concurrency: {cfg['concurrency']}\n")

    # Create and run checker
    checker = Discord4DigitChecker(
        webhook_url=cfg['webhook'],
        concurrency=cfg['concurrency'],
        use_proxies=cfg['use_proxies']
    )

    try:
        asyncio.run(checker.start())
    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}[!] Stopped by user.")
