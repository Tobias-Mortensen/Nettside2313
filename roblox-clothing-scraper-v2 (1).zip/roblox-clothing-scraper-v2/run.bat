@echo off
setlocal
cd /d %~dp0

if not exist venv (
    echo [setup] Creating virtual environment...
    python -m venv venv || goto :fail
)

call venv\Scripts\activate.bat
pip install -q --disable-pip-version-check -r requirements.txt || goto :fail

python -m src.main
goto :eof

:fail
echo.
echo [error] Setup failed. Make sure Python 3.10+ is installed and on PATH.
pause
exit /b 1
