# Roblox Clothing Scraper v2

An async rewrite of the original
[roblox-clothing-scraper](https://github.com/AstreusCoding/roblox-clothing-scraper)
with **multi-group support**, concurrent downloads, progress bars, and a
cleaner codebase.

> ⚠️ **For educational use only.** Downloading other creators' clothing
> templates to re-upload or reuse violates the
> [Roblox Terms of Use](https://en.help.roblox.com/hc/en-us/articles/115004647846)
> and the creators' copyright. Use it on groups you own or have permission
> to archive.

## Features

- 🧺 **Pick multiple groups at once** — paste a list of IDs or URLs and
  the scraper walks through every group in turn.
- 🎯 **Filter by clothing type** — shirts, pants, t-shirts, or all.
- ⚡ **Async + concurrent** — configurable parallelism (default 8) with
  retry/backoff and Roblox CSRF handling.
- 🗂 **Tidy output** — `downloads/<groupId>_<groupName>/<type>/<assetId>_<name>.png`.
- 📊 **Live progress** — per-group progress bars and a summary table.
- 🧹 **Idempotent** — skips files already on disk unless `--overwrite`
  is confirmed.

## Quick start

### Windows

```bat
run.bat
```

### macOS / Linux

```bash
chmod +x run.sh
./run.sh
```

### Manual

```bash
python -m venv venv
# Windows:  venv\Scripts\activate
source venv/bin/activate
pip install -r requirements.txt
python -m src.main
```

## Example session

```
Groups: 1234567, https://www.roblox.com/communities/9876543/Foo
Select types (comma-separated numbers, blank = all): 1,2
Output folder [downloads]:
Parallel downloads (1-32) [8]: 12
Overwrite existing files? [y/n] (n):

== Cool Clothing Group (ID 1234567, 12,480 members) ==
Downloading Cool Clothing Group ━━━━━━━━━━━━━━━ 342/342 • 340 ok / 2 fail
Finished Cool Clothing Group: 340 downloaded, 0 skipped, 2 failed
  → downloads/1234567_Cool Clothing Group
```

## Project layout

```
.
├── src/
│   ├── __init__.py
│   ├── cli.py            # Interactive prompts
│   ├── constants.py      # Endpoints, asset type IDs, tunables
│   ├── downloader.py     # Orchestrates multi-group scrape
│   ├── logger.py         # Rich-backed logger
│   ├── main.py           # Entry point
│   ├── models.py         # @dataclass GroupInfo / ClothingItem
│   ├── roblox_api.py     # Async API client (catalog + assetdelivery)
│   └── utils.py          # ID parsing, filename sanitizing, XML parsing
├── requirements.txt
├── run.bat
├── run.sh
└── README.md
```

## How it works

1. **Group resolution** — `groups.roblox.com/v1/groups/{id}` confirms the
   group exists and gives us the real name for the output folder.
2. **Catalog pagination** — `catalog.roblox.com/v1/search/items` is
   walked with `Category=Clothing`, `CreatorType=Group`,
   `CreatorTargetId=<id>`, collecting every asset ID via `nextPageCursor`.
3. **Item details** — IDs are batched (100 per call) through
   `catalog.roblox.com/v1/catalog/items/details` to pull names, asset
   types and prices. CSRF tokens are handled automatically.
4. **Template download** — for each asset we hit
   `assetdelivery.roblox.com/v1/asset/?id={id}`.
   - T-Shirts return the PNG directly.
   - Shirts and Pants return a small XML wrapper whose
     `<Content><url>...</url></Content>` holds the real template asset
     ID. The scraper parses it and fetches the inner PNG.
5. **Concurrent writes** — an `asyncio.Semaphore` throttles parallel
   HTTP calls; files are written as soon as they finish.

## Requirements

- Python 3.10+
- `aiohttp`, `rich` (installed via `requirements.txt`)

## Troubleshooting

- **HTTP 429s during scraping** — lower `Parallel downloads` from 8 to 4.
- **`Group XXX not found`** — the ID is wrong, the group is hidden,
  or Roblox blocked the request; try opening the group in a browser.
- **Empty result for a public group** — Roblox occasionally changes the
  catalog search API; if that happens the `iter_group_clothing_ids`
  query params in `src/roblox_api.py` are the place to adjust.

## License

MIT, same as the original.
