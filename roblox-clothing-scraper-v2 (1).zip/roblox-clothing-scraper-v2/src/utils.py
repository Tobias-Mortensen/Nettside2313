"""Small helpers: ID parsing, filename sanitization, XML template parsing."""
from __future__ import annotations

import re
from typing import Optional
from xml.etree import ElementTree as ET

# Accepts raw numeric IDs and URLs like:
#   https://www.roblox.com/groups/1234567/My-Group
#   https://www.roblox.com/communities/1234567/My-Group
#   https://www.roblox.com/catalog/9876543/Cool-Shirt
_ID_PATTERN = re.compile(r"(?:/(?:groups|communities|catalog)/)?(\d{3,})")


def extract_id(raw: str) -> Optional[int]:
    """Pull a numeric Roblox ID out of a URL or plain string. Returns None if missing."""
    raw = raw.strip()
    if not raw:
        return None
    if raw.isdigit():
        return int(raw)
    match = _ID_PATTERN.search(raw)
    return int(match.group(1)) if match else None


def parse_group_ids(text: str) -> list[int]:
    """Split a free-form string on commas/whitespace and return a de-duped ID list."""
    tokens = re.split(r"[\s,]+", text.strip())
    ids: list[int] = []
    for tok in tokens:
        gid = extract_id(tok)
        if gid is not None and gid not in ids:
            ids.append(gid)
    return ids


# Characters that are illegal on Windows plus control chars
_INVALID_FS_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def sanitize_filename(name: str, max_length: int = 80) -> str:
    """Return a version of `name` that is safe to use as a filename on any OS."""
    cleaned = _INVALID_FS_CHARS.sub("_", name).strip().rstrip(".")
    if not cleaned:
        cleaned = "untitled"
    return cleaned[:max_length]


def extract_template_id_from_xml(xml_bytes: bytes) -> Optional[int]:
    """
    Shirt/Pants assets on Roblox are tiny XML files that point at a PNG template.
    Parse the XML and return the inner template asset ID, or None if not found.
    """
    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError:
        return None
    for content in root.iter("Content"):
        url_el = content.find("url")
        if url_el is None or not url_el.text:
            continue
        # url text looks like "http://www.roblox.com/asset/?id=123" or "rbxassetid://123"
        match = re.search(r"(\d{3,})", url_el.text)
        if match:
            return int(match.group(1))
    return None


_IMAGE_MAGIC_NUMBERS = (
    b"\x89PNG\r\n\x1a\n",    # PNG
    b"\xff\xd8\xff",          # JPEG
    b"GIF87a",
    b"GIF89a",
)


def looks_like_image(data: bytes) -> bool:
    """True if `data` starts with a known image file signature."""
    return any(data.startswith(sig) for sig in _IMAGE_MAGIC_NUMBERS)
