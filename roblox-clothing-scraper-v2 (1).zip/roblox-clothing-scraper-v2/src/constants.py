"""URLs, asset-type metadata and tunables for the Roblox Clothing Scraper."""

# API endpoints
CATALOG_SEARCH_URL = "https://catalog.roblox.com/v1/search/items"
CATALOG_ITEM_DETAILS_URL = "https://catalog.roblox.com/v1/catalog/items/details"
GROUP_INFO_URL = "https://groups.roblox.com/v1/groups/{group_id}"
ASSET_DELIVERY_URL = "https://assetdelivery.roblox.com/v1/asset/"

# Roblox asset type IDs for classic clothing
ASSET_TYPE_TSHIRT = 2
ASSET_TYPE_SHIRT = 11
ASSET_TYPE_PANTS = 12

CLOTHING_ASSET_TYPES: dict[int, str] = {
    ASSET_TYPE_TSHIRT: "T-Shirt",
    ASSET_TYPE_SHIRT: "Shirt",
    ASSET_TYPE_PANTS: "Pants",
}

# HTTP defaults
DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0 Safari/537.36"
    ),
    "Accept": "application/json, */*",
}
REQUEST_TIMEOUT = 30         # seconds (per request)
MAX_RETRIES = 3
RETRY_BACKOFF = 1.5          # seconds, multiplied by attempt number

# Concurrency and pagination
DEFAULT_CONCURRENCY = 8
CATALOG_PAGE_SIZE = 30       # Roblox hard cap
DETAILS_BATCH_SIZE = 100     # items per /catalog/items/details call

# Output
DEFAULT_OUTPUT_DIR = "downloads"
