"""Interactive CLI prompts for the scraper."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.prompt import Confirm, Prompt
from rich.table import Table

from .constants import (
    ASSET_TYPE_PANTS,
    ASSET_TYPE_SHIRT,
    ASSET_TYPE_TSHIRT,
    DEFAULT_CONCURRENCY,
    DEFAULT_OUTPUT_DIR,
)
from .utils import parse_group_ids

console = Console()

BANNER = r"""
[bold magenta]  _____     _     _               ____                                  [/]
[bold magenta] |  __ \   | |   | |             / ___|  ___ _ __ __ _ _ __   ___ _ __  [/]
[bold magenta] | |__) |__| |__ | | _____  __  \___ \ / __| '__/ _` | '_ \ / _ \ '__| [/]
[bold magenta] |  _  // _ \ '_ \| |/ _ \ \/ /   ___) | (__| | | (_| | |_) |  __/ |    [/]
[bold magenta] |_| \_\___/ |_.__/|_|\___/\__/  |____/ \___|_|  \__,_| .__/ \___|_|    [/]
[bold magenta]                                                      |_|                [/]
[dim]Batch-download classic clothing templates from one or more groups.[/]
"""


def show_banner() -> None:
    console.print(BANNER)


def prompt_group_ids() -> list[int]:
    console.print(
        "\n[bold]Enter Roblox group IDs or URLs[/] "
        "(separate multiple with commas, spaces, or new lines)."
    )
    console.print(
        "[dim]e.g. 1234567, https://www.roblox.com/communities/9876543/Foo[/]"
    )
    while True:
        raw = Prompt.ask("Groups")
        ids = parse_group_ids(raw)
        if ids:
            return ids
        console.print("[red]Could not parse any group IDs. Try again.[/]")


def prompt_asset_types() -> Optional[set[int]]:
    table = Table(title="Clothing types", show_header=True, header_style="bold cyan")
    table.add_column("#", justify="right")
    table.add_column("Type")
    table.add_row("1", "Shirts")
    table.add_row("2", "Pants")
    table.add_row("3", "T-Shirts")
    table.add_row("4", "All (default)")
    console.print(table)

    choice = Prompt.ask(
        "Select types (comma-separated numbers, blank = all)", default="4"
    ).strip()

    mapping = {
        "1": ASSET_TYPE_SHIRT,
        "2": ASSET_TYPE_PANTS,
        "3": ASSET_TYPE_TSHIRT,
    }
    picks = [c.strip() for c in choice.split(",") if c.strip()]
    if not picks or "4" in picks:
        return None
    selected = {mapping[p] for p in picks if p in mapping}
    return selected or None


def prompt_output_dir() -> Path:
    raw = Prompt.ask("Output folder", default=DEFAULT_OUTPUT_DIR)
    return Path(raw).expanduser()


def prompt_concurrency() -> int:
    while True:
        raw = Prompt.ask(
            "Parallel downloads (1-32)",
            default=str(DEFAULT_CONCURRENCY),
        )
        try:
            n = int(raw)
            if 1 <= n <= 32:
                return n
        except ValueError:
            pass
        console.print("[red]Enter an integer between 1 and 32.[/]")


def prompt_overwrite() -> bool:
    return Confirm.ask("Overwrite existing files?", default=False)


def prompt_proxy() -> Optional[str]:
    console.print(
        "\n[bold]Proxy[/] (optional). "
        "Format: [cyan]http://user:pass@host:port[/] or [cyan]http://host:port[/]. "
        "Blank = no proxy."
    )
    raw = Prompt.ask("Proxy URL", default="").strip()
    return raw or None


def print_summary(results) -> None:
    table = Table(title="Summary", show_header=True, header_style="bold green")
    table.add_column("Group")
    table.add_column("Found", justify="right")
    table.add_column("Downloaded", justify="right")
    table.add_column("Skipped", justify="right")
    table.add_column("Failed", justify="right")
    for r in results:
        table.add_row(
            f"{r.group.name} ({r.group.id})",
            str(r.total_found),
            str(r.downloaded),
            str(r.skipped),
            str(r.failed),
        )
    console.print(table)
