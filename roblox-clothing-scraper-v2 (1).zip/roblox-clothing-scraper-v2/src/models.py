"""Typed data classes for group and clothing metadata."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .constants import CLOTHING_ASSET_TYPES


@dataclass
class GroupInfo:
    id: int
    name: str
    member_count: int
    description: str = ""


@dataclass
class ClothingItem:
    asset_id: int
    name: str
    asset_type_id: int          # one of 2 (T-Shirt), 11 (Shirt), 12 (Pants)
    price: Optional[int] = None

    @property
    def asset_type_name(self) -> str:
        return CLOTHING_ASSET_TYPES.get(self.asset_type_id, "Unknown")
