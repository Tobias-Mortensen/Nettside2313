# Crypto2Cash Discord Bot

A support + utility bot for the Crypto2Cash Discord server. Runs on your PC, talks to your Vercel backend.

---

## What It Does

**For users:**
- `/price btc` — Live price for any supported coin
- `/rates` — All 6 coin prices at once
- `/calc 0.01 btc` — Exact PayPal payout estimate (with fees calculated)
- `/fees` — Full fee breakdown
- `/ticket "my payment hasn't arrived"` — Opens a private support thread
- `/help` — Overview of the service and all commands

**For you (admin):**
- `/txns` — View recent transactions pulled from your Vercel backend (admin-only)
- **Auto-alerts** — New transactions posted to your admin channel in real time
- **Auto-tickets** — When a user completes a purchase on the site, a private thread is created automatically with their order details, deposit instructions, and a direct line to support
- **Welcome messages** — New members get a branded greeting with quick-start commands
- **Live status** — Bot displays current BTC price in its status bar

---

## Architecture

```
┌─────────────────┐         ┌──────────────────────┐
│   Your PC       │  HTTPS  │   Vercel             │
│   (Discord Bot) │ ──────► │   (crypto2cash.wtf)  │
│                 │         │                      │
│  polls /api/    │         │  /api/transactions   │
│  transactions   │         │  /api/paypal-checkout│
│  every 30s      │         │  /api/auth/join      │
└────────┬────────┘         └──────────────────────┘
         │
         │ WebSocket
         ▼
┌─────────────────┐
│   Discord API   │
│   (gateway)     │
└─────────────────┘
```

The bot runs on your local machine (or any always-on PC/VPS). It connects to Discord via WebSocket and fetches transaction data from your live Vercel site via regular HTTPS requests. No special networking needed — if your PC can reach `crypto2cash.wtf` and `discord.com`, it works.

---

## Setup (15 minutes)

### 1. Discord Developer Portal

If you already have a bot application (you do — it's used for `DISCORD_BOT_TOKEN` in your Vercel env), skip to step 1c.

**a)** Go to https://discord.com/developers/applications

**b)** Click on your existing application (or create a new one)

**c)** Go to **General Information** and copy the **Application ID** — this is your `DISCORD_CLIENT_ID`

**d)** Go to **Bot** tab:
- Copy the bot **Token** — this is your `DISCORD_BOT_TOKEN`
- Enable these **Privileged Gateway Intents**:
  - ✅ Server Members Intent
  - ✅ Message Content Intent

**e)** Go to **OAuth2 → URL Generator**:
- Scopes: `bot`, `applications.commands`
- Bot Permissions: `Send Messages`, `Embed Links`, `Create Private Threads`, `Manage Threads`, `Read Message History`, `Add Reactions`
- Copy the generated URL and open it to re-invite the bot (if you need to update permissions)

### 2. Get Channel & Role IDs

In Discord, go to **User Settings → Advanced → Enable Developer Mode**.

Then right-click channels/roles to copy their IDs:

| What | Where to find it | .env variable |
|------|-----------------|---------------|
| Admin transaction alerts channel | Create a private channel like `#transactions` | `CHANNEL_TRANSACTIONS` |
| Support ticket channel | Create a channel like `#support` | `CHANNEL_SUPPORT` |
| Welcome channel | Your `#welcome` or `#general` | `CHANNEL_WELCOME` |
| Admin role | The role your staff/admins have | `ROLE_ADMIN` |
| Customer role (optional) | Create a role like `@Customer` | `ROLE_CUSTOMER` |

### 3. Configure the Bot

```bash
cd crypto2cash-bot
cp .env.example .env
```

Edit `.env` and fill in all the values. The critical ones:

```env
DISCORD_BOT_TOKEN=your_bot_token
DISCORD_CLIENT_ID=your_application_id
DISCORD_GUILD_ID=1261697946033635388

CHANNEL_TRANSACTIONS=paste_channel_id
CHANNEL_SUPPORT=paste_channel_id
CHANNEL_WELCOME=paste_channel_id

ROLE_ADMIN=paste_role_id

SITE_URL=https://crypto2cash.wtf
API_SECRET=some_random_secret_string
```

### 4. Secure the Transactions API

Your Vercel backend currently lets anyone call `GET /api/transactions`. Let's lock it down.

**a)** Copy the file from `api-route-update/route.ts` into your website project at `app/api/transactions/route.ts` (replacing the existing one).

**b)** Add `API_SECRET` to your Vercel environment variables:
- Go to https://vercel.com → your project → Settings → Environment Variables
- Add: `API_SECRET` = the same random string you put in the bot's `.env`

**c)** Redeploy your Vercel project (push a commit, or click "Redeploy" in Vercel dashboard).

Now only requests with the correct `x-api-secret` header can read transactions.

### 5. Install & Run

```bash
# Install dependencies
npm install

# Register slash commands with Discord (run once)
npm run deploy-commands

# Start the bot
npm start
```

You should see:

```
┌──────────────────────────────────────┐
│  Crypto2Cash Bot                     │
│  Logged in as Crypto2Cash#1234      │
│  7 commands loaded                   │
└──────────────────────────────────────┘

[Poller] Watching for new transactions...
[Poller] Loaded 0 existing transactions.
```

### 6. Keep It Running

To keep the bot running when you close the terminal:

**Windows:**
- Use [PM2](https://pm2.keymetrics.io/): `npm install -g pm2 && pm2 start src/index.js --name crypto2cash-bot`
- Or run it as a Windows service with [node-windows](https://github.com/coreybutler/node-windows)

**Mac/Linux:**
- PM2: `pm2 start src/index.js --name crypto2cash-bot`
- Or: `nohup node src/index.js &`
- Or create a systemd service

**Auto-restart on crash:**
```bash
pm2 start src/index.js --name crypto2cash-bot --restart-delay=5000
pm2 save
pm2 startup  # generates a command to run — follow its instructions
```

---

## Bot Commands Reference

| Command | Who | What it does |
|---------|-----|-------------|
| `/price <coin>` | Everyone | Live price + 24h change for one coin |
| `/rates` | Everyone | All 6 coin prices at once |
| `/calc <amount> <coin>` | Everyone | Calculates exact PayPal payout after fees |
| `/fees` | Everyone | Shows fee structure ($4 flat / 9%) |
| `/ticket <issue>` | Everyone | Creates a private support thread |
| `/help` | Everyone | Service overview + command list |
| `/txns [count]` | Admin | Shows recent transactions from Vercel |

---

## How Transaction Alerts + Auto-Tickets Work

1. The bot polls `GET /api/transactions` every 30 seconds
2. On first boot, it loads all existing transaction IDs into memory (no alerts)
3. Any new transaction ID triggers two things:
   - **Admin alert** → embed posted in your `CHANNEL_TRANSACTIONS`
   - **Auto-ticket** → private thread created in your `CHANNEL_SUPPORT`
4. The ticket thread automatically:
   - Adds the user who made the purchase (using their Discord ID from login)
   - Adds all members with your `ROLE_ADMIN` role
   - Posts their full order details (amount, payout, deposit address)
   - Sends step-by-step instructions for what to do next

This means: user submits exchange on the website → within 30 seconds, they have a private support thread with their order info, and you have an admin alert.

**Note:** Auto-tickets only work for users who are logged in with Discord on the site (which they must be, since Discord is the only login method).

---

## Troubleshooting

**"Failed to fetch transactions"**
- Check `SITE_URL` in `.env` — should be `https://crypto2cash.wtf` (no trailing slash)
- Check `API_SECRET` matches in both bot `.env` and Vercel env vars
- Make sure you deployed the updated `route.ts` to Vercel

**Commands not showing up**
- Run `npm run deploy-commands` again
- Make sure `DISCORD_CLIENT_ID` and `DISCORD_GUILD_ID` are correct
- Commands register to the specific server (guild), not globally

**Bot goes offline**
- Use PM2 to auto-restart: `pm2 start src/index.js --name crypto2cash-bot`
- Check your PC's sleep settings — disable sleep if running 24/7

**"Missing Access" errors**
- Re-invite the bot with the correct permissions (see step 1e)
- Make sure the bot's role is above the customer role in server settings

---

## File Structure

```
crypto2cash-bot/
├── .env.example          ← Copy to .env and fill in
├── package.json
├── api-route-update/
│   └── route.ts          ← Drop this into your Vercel project
└── src/
    ├── index.js           ← Main entry point
    ├── deploy-commands.js ← Run once to register slash commands
    ├── commands/
    │   ├── price.js       ← /price
    │   ├── rates.js       ← /rates
    │   ├── calc.js        ← /calc
    │   ├── fees.js        ← /fees
    │   ├── ticket.js      ← /ticket
    │   ├── txns.js        ← /txns (admin)
    │   └── help.js        ← /help
    ├── events/
    │   └── guildMemberAdd.js  ← Welcome message
    └── lib/
        ├── api.js         ← Vercel backend client
        ├── fees.js        ← Fee calculator (mirrors website)
        └── prices.js      ← CoinGecko price fetcher
```
