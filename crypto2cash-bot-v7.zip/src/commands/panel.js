const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require("discord.js");

const SITE_URL = process.env.SITE_URL || "https://crypto2cash.wtf";

module.exports = {
  data: new SlashCommandBuilder()
    .setName("panel")
    .setDescription("[Admin] Send the ticket panel embed with an Open Ticket button")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x4A6CF7)
      .setAuthor({ name: "Crypto2Cash Support" })
      .setDescription(
        `Need help with an order or have a question?\n\n` +
        `Click the button below to open a private support ticket. A team member will be with you shortly.\n\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
        `**Before opening a ticket:**\n` +
        `> Have your order ID ready (starts with \`TXN-\`)\n` +
        `> Include the PayPal email you used\n` +
        `> Describe your issue clearly\n\n` +
        `You may only have one open ticket at a time.`
      )
      .setFooter({ text: "Crypto2Cash" });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("open_ticket")
        .setLabel("Open Ticket")
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setLabel("Visit Website")
        .setStyle(ButtonStyle.Link)
        .setURL(SITE_URL)
    );

    // Send as a regular message (not ephemeral) so it stays in the channel
    await interaction.channel.send({ embeds: [embed], components: [row] });
    await interaction.reply({ content: "Ticket panel sent.", ephemeral: true });
  },
};
