const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("close")
    .setDescription("[Admin] Close this ticket channel")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const categoryId = process.env.CHANNEL_TICKET_CATEGORY;
    if (!categoryId || interaction.channel.parentId !== categoryId) {
      return interaction.reply({ content: "This command can only be used inside a ticket channel.", ephemeral: true });
    }

    const adminRoleId = process.env.ROLE_ADMIN;
    const isAdmin = adminRoleId && interaction.member.roles.cache.has(adminRoleId);
    const hasManage = interaction.member.permissions.has(PermissionFlagsBits.ManageChannels);

    if (!isAdmin && !hasManage) {
      return interaction.reply({ content: "Only admins can close tickets.", ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(0xEF4444)
      .setAuthor({ name: "Ticket Closing" })
      .setDescription(
        `Closed by <@${interaction.user.id}>\n\n` +
        `This channel will be deleted in 5 seconds.\n\n` +
        `━━━━━━━━━━━━━━━━━━━━━━`
      )
      .setTimestamp();
    await interaction.reply({ embeds: [embed] });
    setTimeout(async () => {
      await interaction.channel.delete("Ticket closed").catch(console.error);
    }, 5000);
  },
};
