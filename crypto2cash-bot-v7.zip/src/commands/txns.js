const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const { fetchTransactions } = require("../lib/api");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("txns")
    .setDescription("[Admin] View recent transactions from the site")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addIntegerOption((opt) =>
      opt.setName("count").setDescription("How many to show (default: 5)").setMinValue(1).setMaxValue(25)
    ),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    try {
      const count = interaction.options.getInteger("count") || 5;
      const transactions = await fetchTransactions();
      if (!transactions.length) {
        return interaction.editReply("No transactions found.");
      }
      const recent = transactions.slice(-count).reverse();
      const lines = recent.map((tx) => {
        const timeAgo = getTimeAgo(new Date(tx.createdAt));
        const status = { pending: "Pending", completed: "Completed", failed: "Failed" }[tx.status] || tx.status;
        return (
          `\`${tx.id}\`\n` +
          `> **${tx.cryptoAmount} ${tx.cryptoType}** > **$${tx.usdAmount}** PayPal\n` +
          `> ${maskEmail(tx.paypalEmail)}  |  ${status}  |  ${timeAgo}` +
          (tx.discordUserId ? `  |  <@${tx.discordUserId}>` : "")
        );
      });
      const embed = new EmbedBuilder()
        .setColor(0x4A6CF7)
        .setAuthor({ name: `Recent Transactions (${recent.length})` })
        .setDescription(lines.join("\n\n") + `\n\n━━━━━━━━━━━━━━━━━━━━━━`)
        .setFooter({ text: `Total: ${transactions.length} transactions` })
        .setTimestamp();
      await interaction.editReply({ embeds: [embed] });
    } catch (err) {
      console.error("[/txns]", err);
      await interaction.editReply("Failed to fetch transactions. Check SITE_URL and API_SECRET.");
    }
  },
};

function maskEmail(email) {
  if (!email) return "unknown";
  const [user, domain] = email.split("@");
  if (!domain) return "***";
  return `${user.slice(0, 2)}***@${domain}`;
}
function getTimeAgo(date) {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  if (seconds < 60) return "just now";
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}
