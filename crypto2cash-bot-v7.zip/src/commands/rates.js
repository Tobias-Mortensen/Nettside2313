const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { fetchPrices } = require("../lib/prices");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("rates")
    .setDescription("Show live prices for all supported cryptocurrencies"),

  async execute(interaction) {
    await interaction.deferReply();
    try {
      const prices = await fetchPrices();
      const lines = [];
      for (const [, coin] of Object.entries(prices)) {
        const priceStr = coin.price.toLocaleString("en-US", {
          style: "currency",
          currency: "USD",
          minimumFractionDigits: coin.price < 1 ? 4 : 2,
        });
        const changeSign = coin.change24h >= 0 ? "+" : "";
        lines.push(`**${coin.symbol}** — ${priceStr}  |  ${changeSign}${coin.change24h.toFixed(2)}%`);
      }
      const embed = new EmbedBuilder()
        .setColor(0x4A6CF7)
        .setAuthor({ name: "Live Crypto Rates" })
        .setDescription(
          lines.join("\n") +
          `\n\n━━━━━━━━━━━━━━━━━━━━━━\n` +
          `Use \`/calc <amount> <coin>\` to estimate your PayPal payout`
        )
        .setFooter({ text: "Live data via CoinGecko" })
        .setTimestamp();
      await interaction.editReply({ embeds: [embed] });
    } catch (err) {
      console.error("[/rates]", err);
      await interaction.editReply("Failed to fetch prices. Try again in a moment.");
    }
  },
};
