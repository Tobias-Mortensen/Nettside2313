const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("faq")
    .setDescription("Frequently asked questions about Crypto2Cash"),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x4A6CF7)
      .setAuthor({ name: "Frequently Asked Questions" })
      .setDescription("━━━━━━━━━━━━━━━━━━━━━━")
      .addFields(
        {
          name: "How long does it take?",
          value: "> Most orders complete within 30 minutes after blockchain confirmation.\n> During high volume it can occasionally take a few hours.",
        },
        {
          name: "What are the fees?",
          value: "> $4 flat on orders up to $25. 9% on orders above $25.\n> No hidden charges. Use `/calc` to check.",
        },
        {
          name: "Do I need to verify my identity?",
          value: "> No. No ID uploads, selfies, or documents.\n> We only need your PayPal email address.",
        },
        {
          name: "What if my payment doesn't arrive?",
          value: "> Open a `/ticket` with your order ID.\n> Most issues are resolved within a few hours.",
        },
        {
          name: "What are the limits?",
          value: "> Minimum: $10 per transaction.\n> Maximum: $5,000 per transaction.\n> For larger amounts, open a `/ticket`.",
        },
        {
          name: "Why Discord login?",
          value: "> Fast sign-in without personal documents, plus direct support access.\n> We only read your username and avatar.",
        },
      )
      .setFooter({ text: "Still have questions? Use /ticket to reach our team" });
    await interaction.reply({ embeds: [embed] });
  },
};
