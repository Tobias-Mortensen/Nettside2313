const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("fees")
    .setDescription("See the full fee structure for Crypto2Cash"),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x4A6CF7)
      .setAuthor({ name: "Fee Structure" })
      .setDescription(
        `No hidden charges. What you see is what you get.\n\n` +
        `━━━━━━━━━━━━━━━━━━━━━━`
      )
      .addFields(
        {
          name: "Orders up to $25",
          value: "> **$4.00 flat fee**\n> \n> `Example: Sell $20 BTC > receive $16.00`",
          inline: false,
        },
        {
          name: "Orders above $25",
          value: "> **9% of the total**\n> \n> `Example: Sell $100 ETH > fee $9 > receive $91.00`",
          inline: false,
        },
        { name: " ", value: "━━━━━━━━━━━━━━━━━━━━━━", inline: false },
        {
          name: "Limits",
          value: "> Minimum: **$10** per transaction  |  Maximum: **$5,000** per transaction\n> For larger amounts, open a `/ticket`",
          inline: false,
        },
        {
          name: "What's included",
          value: "> Blockchain network fees, PayPal processing, and instant settlement.\n> The site calculator shows your exact payout before you confirm.",
          inline: false,
        },
      )
      .setFooter({ text: "Use /calc to estimate your payout for a specific amount" });
    await interaction.reply({ embeds: [embed] });
  },
};
