require("dotenv").config();

const { Client, GatewayIntentBits, Collection, EmbedBuilder, ActivityType, ChannelType } = require("discord.js");
const fs = require("fs");
const path = require("path");
const { fetchTransactions } = require("./lib/api");
const { fetchPrices } = require("./lib/prices");

// ─── Create client ──────────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
  ],
});

// ─── Load slash commands ────────────────────────────────────
client.commands = new Collection();
const commandsPath = path.join(__dirname, "commands");
const commandFiles = fs.readdirSync(commandsPath).filter((f) => f.endsWith(".js"));

for (const file of commandFiles) {
  const command = require(path.join(commandsPath, file));
  if (command.data && command.execute) {
    client.commands.set(command.data.name, command);
  }
}

// ─── Load event handlers ───────────────────────────────────
const eventsPath = path.join(__dirname, "events");
if (fs.existsSync(eventsPath)) {
  const eventFiles = fs.readdirSync(eventsPath).filter((f) => f.endsWith(".js"));
  for (const file of eventFiles) {
    const event = require(path.join(eventsPath, file));
    if (event.once) {
      client.once(event.name, (...args) => event.execute(...args));
    } else {
      client.on(event.name, (...args) => event.execute(...args));
    }
  }
}

// ─── Handle slash command interactions ─────────────────────
client.on("interactionCreate", async (interaction) => {
  // Handle button clicks
  if (interaction.isButton()) {
    if (interaction.customId === "open_ticket") {
      await handleTicketButton(interaction);
    }
    return;
  }

  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction);
  } catch (err) {
    console.error(`[Command /${interaction.commandName}]`, err);
    const reply = {
      content: "Something went wrong running that command.",
      ephemeral: true,
    };
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(reply).catch(() => {});
    } else {
      await interaction.reply(reply).catch(() => {});
    }
  }
});

// ─── Handle ticket button click ────────────────────────────
async function handleTicketButton(interaction) {
  const { ChannelType, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require("discord.js");

  const categoryId = process.env.CHANNEL_TICKET_CATEGORY;
  if (!categoryId) {
    return interaction.reply({ content: "Tickets are not configured yet.", ephemeral: true });
  }

  const guild = interaction.guild;

  // Check if user already has an open ticket
  const existing = guild.channels.cache.find(
    (ch) => ch.parentId === categoryId && ch.permissionOverwrites.cache.has(interaction.user.id)
  );
  if (existing) {
    return interaction.reply({
      content: `You already have an open ticket: <#${existing.id}>`,
      ephemeral: true,
    });
  }

  // Show a modal asking for their issue
  const modal = new ModalBuilder()
    .setCustomId("ticket_modal")
    .setTitle("Open a Support Ticket");

  const issueInput = new TextInputBuilder()
    .setCustomId("ticket_issue")
    .setLabel("Describe your issue")
    .setPlaceholder("e.g. Payment not received for order TXN-...")
    .setStyle(TextInputStyle.Paragraph)
    .setMaxLength(500)
    .setRequired(true);

  modal.addComponents(new ActionRowBuilder().addComponents(issueInput));
  await interaction.showModal(modal);
}

// ─── Handle ticket modal submit ────────────────────────────
client.on("interactionCreate", async (interaction) => {
  if (!interaction.isModalSubmit()) return;
  if (interaction.customId !== "ticket_modal") return;

  const { ChannelType, PermissionFlagsBits, EmbedBuilder } = require("discord.js");

  await interaction.deferReply({ ephemeral: true });

  try {
    const issue = interaction.fields.getTextInputValue("ticket_issue");
    const categoryId = process.env.CHANNEL_TICKET_CATEGORY;
    const guild = interaction.guild;

    const channelName = `ticket-${interaction.user.username}-${Date.now().toString(36).slice(-4)}`;
    const permissionOverwrites = [
      { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
      { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
      { id: interaction.client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels] },
    ];
    const adminRoleId = process.env.ROLE_ADMIN;
    if (adminRoleId) {
      permissionOverwrites.push({ id: adminRoleId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] });
    }

    const ticketChannel = await guild.channels.create({
      name: channelName,
      type: ChannelType.GuildText,
      parent: categoryId,
      permissionOverwrites,
      reason: `Support ticket from ${interaction.user.tag}`,
    });

    const ticketEmbed = new EmbedBuilder()
      .setColor(0x4A6CF7)
      .setAuthor({ name: "Support Ticket Opened" })
      .setDescription(`**Issue:**\n> ${issue}\n\n━━━━━━━━━━━━━━━━━━━━━━`)
      .addFields(
        { name: "Opened by", value: `> <@${interaction.user.id}>`, inline: true },
        { name: "Status", value: "> Open", inline: true },
      )
      .setTimestamp()
      .setFooter({ text: "An admin will use /close to close this ticket" });

    await ticketChannel.send({ embeds: [ticketEmbed] });

    const infoEmbed = new EmbedBuilder()
      .setColor(0x2B2D31)
      .setDescription(
        `<@${interaction.user.id}> — Welcome to your ticket.\n\n` +
        `**Tips for faster support:**\n` +
        `> Include your order ID (starts with \`TXN-\`)\n` +
        `> Include the PayPal email you used\n` +
        `> Describe what happened and when\n\n` +
        `A team member will be with you shortly.`
      );
    await ticketChannel.send({ embeds: [infoEmbed] });

    if (adminRoleId) {
      await ticketChannel.send(`<@&${adminRoleId}>`);
    }

    await interaction.editReply(`Your ticket has been created: <#${ticketChannel.id}>`);
  } catch (err) {
    console.error("[TicketButton]", err);
    await interaction.editReply("Something went wrong creating the ticket. Please try again.");
  }
});

// ─── Bot ready ─────────────────────────────────────────────
client.once("ready", async () => {
  console.log(`\n┌──────────────────────────────────────┐`);
  console.log(`│  Crypto2Cash Bot                     │`);
  console.log(`│  Logged in as ${client.user.tag.padEnd(22)}│`);
  console.log(`│  ${client.commands.size} commands loaded${" ".repeat(19 - String(client.commands.size).length)}│`);
  console.log(`└──────────────────────────────────────┘\n`);

  updateStatus();
  setInterval(updateStatus, 45_000);
  startTransactionPoller();
});

// ─── Bot status — cycles through coin prices ───────────────
let statusIndex = 0;
const statusCoins = ["ltc", "btc", "eth", "sol"];

async function updateStatus() {
  try {
    const prices = await fetchPrices();
    const coinId = statusCoins[statusIndex % statusCoins.length];
    const coin = prices[coinId];
    statusIndex++;

    if (coin && coin.price) {
      const changeSign = coin.change24h >= 0 ? "↑" : "↓";
      const priceStr = coin.price.toLocaleString("en-US", { maximumFractionDigits: coin.price < 10 ? 2 : 0 });
      client.user.setActivity(
        `${coin.symbol} $${priceStr} ${changeSign}${Math.abs(coin.change24h).toFixed(1)}%`,
        { type: ActivityType.Watching }
      );
    }
  } catch {
    client.user.setActivity("crypto2cash.wtf", { type: ActivityType.Watching });
  }
}

// ─── Transaction poller ─────────────────────────────────────
const POLL_INTERVAL = 30_000;
let knownTxnIds = new Set();

async function startTransactionPoller() {
  const txnChannelId = process.env.CHANNEL_TRANSACTIONS;

  if (!txnChannelId) {
    console.log("[Poller] CHANNEL_TRANSACTIONS not set — skipping transaction alerts.");
    return;
  }

  console.log("[Poller] Watching for new transactions...");

  try {
    const existing = await fetchTransactions();
    for (const tx of existing) {
      knownTxnIds.add(tx.id);
    }
    console.log(`[Poller] Loaded ${knownTxnIds.size} existing transactions.`);
  } catch (err) {
    console.error("[Poller] Initial load failed:", err.message);
  }

  setInterval(async () => {
    try {
      const transactions = await fetchTransactions();

      for (const tx of transactions) {
        if (knownTxnIds.has(tx.id)) continue;
        knownTxnIds.add(tx.id);

        console.log(`[Poller] New transaction: ${tx.id}`);

        if (txnChannelId) {
          await postTransactionAlert(txnChannelId, tx);
        }
      }
    } catch {}
  }, POLL_INTERVAL);
}

async function postTransactionAlert(channelId, tx) {
  try {
    const guildId = process.env.DISCORD_GUILD_ID;
    const guild = await client.guilds.fetch(guildId).catch(() => null);
    const channel = guild ? await guild.channels.fetch(channelId).catch(() => null) : null;
    if (!channel) return;

    const coinColors = {
      BTC: 0xF7931A, ETH: 0x627EEA, LTC: 0x345D9D,
      USDT: 0x26A17B, USDC: 0x2775CA, SOL: 0x9945FF,
    };

    const embed = new EmbedBuilder()
      .setColor(coinColors[tx.cryptoType] || 0x22C55E)
      .setAuthor({ name: "New Transaction Received" })
      .setDescription(`\`\`\`\n${tx.id}\n\`\`\``)
      .addFields(
        { name: "Crypto", value: `> **${tx.cryptoAmount} ${tx.cryptoType}**`, inline: true },
        { name: "PayPal Payout", value: `> **$${tx.usdAmount} USD**`, inline: true },
        { name: "Status", value: "> Awaiting Payment", inline: true },
        { name: " ", value: " ", inline: false },
        { name: "Customer", value: tx.discordUserId ? `> <@${tx.discordUserId}>` : "> Not linked", inline: true },
        { name: "PayPal Email", value: `> \`${maskEmail(tx.paypalEmail)}\``, inline: true },
        { name: "Deposit Wallet", value: `> \`${tx.walletAddress.slice(0, 20)}...\``, inline: false },
      )
      .setTimestamp(new Date(tx.createdAt))
      .setFooter({ text: "Crypto2Cash" });

    await channel.send({ embeds: [embed] });
  } catch (err) {
    console.error("[Alert]", err.message);
  }
}

function maskEmail(email) {
  if (!email) return "unknown";
  const [user, domain] = email.split("@");
  if (!domain) return "***";
  return `${user.slice(0, 2)}***@${domain}`;
}

// ─── Login ─────────────────────────────────────────────────
const token = process.env.DISCORD_BOT_TOKEN;
if (!token) {
  console.error("DISCORD_BOT_TOKEN is missing from .env");
  process.exit(1);
}

client.login(token);
