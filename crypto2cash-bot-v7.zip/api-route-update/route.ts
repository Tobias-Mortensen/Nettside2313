// ─── UPDATED /api/transactions route ───────────────────────────
// Drop this file into: app/api/transactions/route.ts
// 
// Changes from original:
// 1. GET endpoint now requires x-api-secret header (bot auth)
// 2. Transaction stores discordUserId + discordUsername (for auto-tickets)
// ────────────────────────────────────────────────────────────────

import { NextRequest, NextResponse } from "next/server"
import { promises as fs } from "fs"
import path from "path"

interface Transaction {
  id: string
  cryptoType: string
  cryptoAmount: string
  usdAmount: string
  paypalEmail: string
  walletAddress: string
  status: string
  createdAt: string
  discordUserId: string | null
  discordUsername: string | null
}

const DATA_FILE = path.join(process.cwd(), "data", "transactions.json")

async function ensureDataFile() {
  const dataDir = path.join(process.cwd(), "data")
  try {
    await fs.access(dataDir)
  } catch {
    await fs.mkdir(dataDir, { recursive: true })
  }
  
  try {
    await fs.access(DATA_FILE)
  } catch {
    await fs.writeFile(DATA_FILE, JSON.stringify({ transactions: [] }, null, 2))
  }
}

async function readTransactions(): Promise<{ transactions: Transaction[] }> {
  await ensureDataFile()
  const data = await fs.readFile(DATA_FILE, "utf-8")
  return JSON.parse(data)
}

async function writeTransactions(data: { transactions: Transaction[] }) {
  await ensureDataFile()
  await fs.writeFile(DATA_FILE, JSON.stringify(data, null, 2))
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const {
      cryptoType,
      cryptoAmount,
      usdAmount,
      paypalEmail,
      walletAddress,
      discordUserId,
      discordUsername,
    } = body

    const transaction: Transaction = {
      id: `TXN-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      cryptoType,
      cryptoAmount,
      usdAmount,
      paypalEmail,
      walletAddress,
      status: "pending",
      createdAt: new Date().toISOString(),
      discordUserId: discordUserId || null,
      discordUsername: discordUsername || null,
    }

    const data = await readTransactions()
    data.transactions.push(transaction)
    await writeTransactions(data)

    return NextResponse.json({ success: true, transaction })
  } catch (error) {
    console.error("Error saving transaction:", error)
    return NextResponse.json(
      { success: false, error: "Failed to save transaction" },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  // ── Auth check: require API_SECRET header ──
  const secret = process.env.API_SECRET
  if (secret) {
    const provided = request.headers.get("x-api-secret")
    if (provided !== secret) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 }
      )
    }
  }

  try {
    const data = await readTransactions()
    return NextResponse.json(data)
  } catch (error) {
    console.error("Error reading transactions:", error)
    return NextResponse.json(
      { success: false, error: "Failed to read transactions" },
      { status: 500 }
    )
  }
}
