# SteamBoost Discord Bot

A fully-featured Discord bot that automates server setup, role/channel management,
ticket-based support, and placeholder website integration for SteamBoost.

---

## Prerequisites

1. **Python 3.10+** — https://www.python.org/downloads/
2. **A Discord Bot Application** — created at https://discord.com/developers/applications
3. **Bot Token** — from your Discord application's "Bot" tab
4. **Privileged Intents** — enable ALL three under your bot's settings:
   - Presence Intent
   - Server Members Intent
   - Message Content Intent

## Installation

```bash
# Clone or copy the bot folder, then:
cd steamboost-bot
pip install -r requirements.txt
```

## Configuration

1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
2. Open `.env` and paste your bot token and (optionally) your API base URL.

## Inviting the Bot

Generate an invite URL from the Developer Portal → OAuth2 → URL Generator.
Select these scopes and permissions:

- **Scopes:** `bot`, `applications.commands`
- **Permissions:** Administrator (or at minimum: Manage Roles, Manage Channels,
  Send Messages, Manage Messages, Embed Links, Manage Threads, Read Message History)

Paste the generated URL into your browser and select your server.

## Running

```bash
python bot.py
```

## Commands

| Command             | Who Can Use      | Description                                      |
|---------------------|------------------|--------------------------------------------------|
| `!setup`            | Server Owner     | Creates all roles, channels, and permissions      |
| `!verify <code>`    | Anyone           | Links Discord account to SteamBoost website       |
| `!status`           | Verified users   | Checks order/account status on SteamBoost         |
| `!ticket <reason>`  | Anyone           | Opens a private support ticket thread             |
| `!close`            | Staff (in ticket)| Closes and archives a support ticket              |
| `!panel`            | Admin            | Posts an embed with a ticket-creation button       |

## Project Structure

```
steamboost-bot/
├── bot.py              # Entry point — loads cogs and starts the bot
├── config.py           # Centralised configuration (roles, channels, colours)
├── cogs/
│   ├── setup.py        # !setup — server scaffolding
│   ├── tickets.py      # Ticket system (commands + button UI)
│   ├── verification.py # !verify / !status — website integration stubs
│   └── events.py       # Welcome messages, member join/leave logging
├── utils/
│   └── api.py          # Placeholder HTTP client for SteamBoost API
├── requirements.txt
├── .env.example
└── README.md
```
