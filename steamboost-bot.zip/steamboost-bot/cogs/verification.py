"""
cogs/verification.py — Website ↔ Discord account linking.

!verify <code>  — Validates the code against the SteamBoost API, then gives
                  the user the "Verified" (and optionally "Customer") role.
!status         — Queries the API for the user's open orders.

Both commands delegate to utils.api, which currently returns mock data.
"""

from __future__ import annotations

import discord
from discord.ext import commands

from config import EMBED_COLOUR
from utils.api import verify_user, get_order_status


class Verification(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @commands.command(name="verify")
    async def verify(self, ctx: commands.Context, code: str | None = None) -> None:
        """Link your Discord account to your SteamBoost website account."""
        if code is None:
            embed = discord.Embed(
                title="How to Verify",
                description=(
                    "1. Log in to [steamboost.xyz](https://steamboost.xyz)\n"
                    "2. Go to **Account → Discord Link**\n"
                    "3. Copy your unique verification code\n"
                    "4. Run `!verify YOUR_CODE` here"
                ),
                colour=EMBED_COLOUR,
            )
            await ctx.send(embed=embed)
            return

        result = await verify_user(ctx.author.id, code)

        if result.success:
            # Grant the Verified role
            verified_role = discord.utils.get(ctx.guild.roles, name="Verified")
            if verified_role:
                await ctx.author.add_roles(verified_role, reason="Verified via SteamBoost")

            embed = discord.Embed(
                title="✅ Verification Successful",
                description=(
                    f"Your Discord is now linked to **{result.username}** on SteamBoost.\n"
                    "You've been granted the **Verified** role and can access all community channels."
                ),
                colour=discord.Colour.green(),
            )
        else:
            embed = discord.Embed(
                title="❌ Verification Failed",
                description=f"{result.error}\n\nDouble-check your code and try again.",
                colour=discord.Colour.red(),
            )

        await ctx.send(embed=embed)

    @commands.command(name="status")
    async def status(self, ctx: commands.Context) -> None:
        """Check the status of your active SteamBoost orders."""
        # Require Verified role
        if not discord.utils.get(ctx.author.roles, name="Verified"):
            await ctx.send("⚠️ You must `!verify` your account first.")
            return

        orders = await get_order_status(ctx.author.id)

        if not orders:
            embed = discord.Embed(
                title="📦 No Active Orders",
                description="You don't have any open orders right now.",
                colour=EMBED_COLOUR,
            )
        else:
            lines = []
            for o in orders:
                status_emoji = {
                    "pending": "🟡",
                    "in_progress": "🔵",
                    "completed": "🟢",
                }.get(o.status, "⚪")
                lines.append(f"{status_emoji} **{o.order_id}** — {o.status.replace('_', ' ').title()}\n> {o.details}")

            embed = discord.Embed(
                title="📦 Your Orders",
                description="\n\n".join(lines),
                colour=EMBED_COLOUR,
            )

        await ctx.send(embed=embed)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Verification(bot))
