"""
cogs/tickets.py — Support ticket system.

How it works:
  • A "panel" embed with a 🎫 button lives in #support.
  • Clicking the button (or running !ticket <reason>) creates a **private
    thread** visible only to the user and staff roles.
  • Staff can close a ticket with !close, which locks and archives the thread.
"""

from __future__ import annotations

import discord
from discord.ext import commands
from discord import ui

from config import EMBED_COLOUR, STAFF_ROLES


# ── Persistent View (button that survives bot restarts) ────────────────────

class TicketButton(ui.Button["TicketPanelView"]):
    def __init__(self) -> None:
        super().__init__(
            label="Open a Ticket",
            style=discord.ButtonStyle.green,
            emoji="🎫",
            custom_id="steamboost:open_ticket",
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        guild = interaction.guild
        member = interaction.user

        # Prevent duplicate open tickets
        thread_name = f"ticket-{member.name}"
        for thread in guild.threads:
            if thread.name == thread_name and not thread.archived:
                await interaction.response.send_message(
                    f"You already have an open ticket: {thread.mention}",
                    ephemeral=True,
                )
                return

        # Create a private thread in the current channel
        channel: discord.TextChannel = interaction.channel  # type: ignore[assignment]
        thread = await channel.create_thread(
            name=thread_name,
            type=discord.ChannelType.private_thread,
            reason=f"Support ticket for {member}",
        )

        # Add the user and every staff member
        await thread.add_user(member)
        for role_name in STAFF_ROLES:
            role = discord.utils.get(guild.roles, name=role_name)
            if role:
                for m in role.members:
                    try:
                        await thread.add_user(m)
                    except discord.HTTPException:
                        pass

        # Opening message
        embed = discord.Embed(
            title="SteamBoost Support Ticket",
            description=(
                f"Hey {member.mention}, a staff member will be with you shortly.\n\n"
                "Please describe your issue in detail. "
                "A staff member can close this ticket with `!close`."
            ),
            colour=EMBED_COLOUR,
        )
        await thread.send(embed=embed)

        await interaction.response.send_message(
            f"✅ Ticket created: {thread.mention}", ephemeral=True
        )


class TicketPanelView(ui.View):
    """A persistent View that contains the ticket button."""

    def __init__(self) -> None:
        super().__init__(timeout=None)
        self.add_item(TicketButton())


# ── Cog ────────────────────────────────────────────────────────────────────

class Tickets(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        # Register the persistent view so the button works after restarts
        self.bot.add_view(TicketPanelView())

    # ── Panel embed (called from setup.py or !panel) ──────────────────────

    async def post_panel(self, channel: discord.TextChannel) -> None:
        embed = discord.Embed(
            title="🎫  SteamBoost Support",
            description=(
                "Need help with an order, account issue, or have a question?\n"
                "Click the button below to open a **private ticket** with our staff."
            ),
            colour=EMBED_COLOUR,
        )
        embed.set_footer(text="Our team typically responds within a few hours.")
        await channel.send(embed=embed, view=TicketPanelView())

    @commands.command(name="panel")
    @commands.has_permissions(administrator=True)
    async def panel_command(self, ctx: commands.Context) -> None:
        """Post the ticket-creation panel embed in the current channel."""
        await self.post_panel(ctx.channel)  # type: ignore[arg-type]
        await ctx.message.delete()

    # ── Manual ticket creation ────────────────────────────────────────────

    @commands.command(name="ticket")
    async def open_ticket(self, ctx: commands.Context, *, reason: str = "No reason provided") -> None:
        """Open a support ticket with an optional reason."""
        guild = ctx.guild
        member = ctx.author

        thread_name = f"ticket-{member.name}"
        for thread in guild.threads:
            if thread.name == thread_name and not thread.archived:
                await ctx.send(f"You already have an open ticket: {thread.mention}")
                return

        support_ch = discord.utils.get(guild.text_channels, name="support")
        target = support_ch or ctx.channel

        thread = await target.create_thread(
            name=thread_name,
            type=discord.ChannelType.private_thread,
            reason=f"Support ticket for {member}: {reason}",
        )

        await thread.add_user(member)
        for role_name in STAFF_ROLES:
            role = discord.utils.get(guild.roles, name=role_name)
            if role:
                for m in role.members:
                    try:
                        await thread.add_user(m)
                    except discord.HTTPException:
                        pass

        embed = discord.Embed(
            title="SteamBoost Support Ticket",
            description=(
                f"**Opened by:** {member.mention}\n"
                f"**Reason:** {reason}\n\n"
                "A staff member will be with you shortly. "
                "Use `!close` to close this ticket."
            ),
            colour=EMBED_COLOUR,
        )
        await thread.send(embed=embed)
        await ctx.send(f"✅ Ticket created: {thread.mention}")

    # ── Close a ticket ────────────────────────────────────────────────────

    @commands.command(name="close")
    async def close_ticket(self, ctx: commands.Context) -> None:
        """Close and archive the current support ticket thread."""
        thread = ctx.channel
        if not isinstance(thread, discord.Thread) or not thread.name.startswith("ticket-"):
            await ctx.send("This command can only be used inside a ticket thread.")
            return

        # Only staff or the ticket creator can close
        is_staff = any(r.name in STAFF_ROLES for r in ctx.author.roles)
        is_owner = thread.name == f"ticket-{ctx.author.name}"
        if not (is_staff or is_owner):
            await ctx.send("⛔ Only staff or the ticket creator can close this ticket.")
            return

        embed = discord.Embed(
            title="Ticket Closed 🔒",
            description=f"Closed by {ctx.author.mention}. This thread is now archived.",
            colour=discord.Colour.red(),
        )
        await ctx.send(embed=embed)
        await thread.edit(archived=True, locked=True, reason=f"Closed by {ctx.author}")


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Tickets(bot))
