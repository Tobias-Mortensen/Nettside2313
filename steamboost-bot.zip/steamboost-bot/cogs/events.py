"""
cogs/events.py — Automated event handlers.

• on_member_join  → sends a welcome DM and assigns the Guest role.
• on_member_remove → logs departures to #announcements (optional).
"""

from __future__ import annotations

import discord
from discord.ext import commands

from config import EMBED_COLOUR


class Events(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member) -> None:
        guild = member.guild

        # Assign the Guest role automatically
        guest = discord.utils.get(guild.roles, name="Guest")
        if guest:
            try:
                await member.add_roles(guest, reason="Auto-assigned on join")
            except discord.Forbidden:
                pass

        # Send a welcome DM
        try:
            embed = discord.Embed(
                title=f"Welcome to {guild.name}! 🚀",
                description=(
                    "Thanks for joining the official **SteamBoost** community.\n\n"
                    "🔹 Read the rules in **#rules**\n"
                    "🔹 Link your account with `!verify <code>`\n"
                    "🔹 Need help? Open a ticket in **#support**\n\n"
                    "[Visit SteamBoost](https://steamboost.xyz)"
                ),
                colour=EMBED_COLOUR,
            )
            embed.set_thumbnail(url=guild.icon.url if guild.icon else discord.Embed.Empty)
            await member.send(embed=embed)
        except discord.Forbidden:
            pass  # DMs disabled — no big deal

        # Log the join in #welcome (system channel fallback)
        welcome_ch = discord.utils.get(guild.text_channels, name="welcome")
        if welcome_ch:
            await welcome_ch.send(
                f"👋 {member.mention} just joined the server — welcome aboard!"
            )

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member) -> None:
        """Optional departure logging.  Delete this method if you don't want it."""
        guild = member.guild
        log_ch = discord.utils.get(guild.text_channels, name="announcements")
        if log_ch:
            try:
                await log_ch.send(f"📤 **{member}** has left the server.")
            except discord.Forbidden:
                pass


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Events(bot))
