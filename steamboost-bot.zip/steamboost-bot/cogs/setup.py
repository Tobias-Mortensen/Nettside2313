"""
cogs/setup.py — The !setup command.

Running !setup in a server will:
  1. Create every role defined in config.ROLES (skipping duplicates).
  2. Create every category / channel defined in config.CATEGORIES.
  3. Apply granular permission overwrites so that:
       • @everyone can only *see* #welcome, #announcements, #rules, and #faq
         but cannot send messages there.
       • Community channels require the "Verified" role.
       • #vip-lounge requires the "VIP" role.
       • #order-status requires "Customer" or higher.
       • Voice channels are open to Verified+.
       • The #support channel gets a ticket-panel embed (see tickets.py).

Only the server **owner** can run this command as a safety measure.
"""

from __future__ import annotations

import asyncio
import discord
from discord.ext import commands

from config import ROLES, CATEGORIES, STAFF_ROLES, EMBED_COLOUR


class Setup(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    # ── helpers ────────────────────────────────────────────────────────────

    @staticmethod
    def _get_role(guild: discord.Guild, name: str) -> discord.Role | None:
        return discord.utils.get(guild.roles, name=name)

    async def _ensure_roles(self, guild: discord.Guild) -> dict[str, discord.Role]:
        """Create roles that don't already exist and return a name→Role map."""
        role_map: dict[str, discord.Role] = {}
        for idx, rdef in enumerate(ROLES):
            existing = self._get_role(guild, rdef["name"])
            if existing:
                role_map[rdef["name"]] = existing
            else:
                role_map[rdef["name"]] = await guild.create_role(
                    name=rdef["name"],
                    colour=rdef["color"],
                    hoist=rdef["hoist"],
                    mentionable=rdef["mentionable"],
                    reason="SteamBoost auto-setup",
                )
            await asyncio.sleep(0.3)  # respect rate limits
        return role_map

    def _base_overwrites(
        self, guild: discord.Guild, role_map: dict[str, discord.Role]
    ) -> dict[discord.Role | discord.Member, discord.PermissionOverwrite]:
        """Default overwrites: hide everything from @everyone, let staff see all."""
        overwrites: dict[discord.Role | discord.Member, discord.PermissionOverwrite] = {
            guild.default_role: discord.PermissionOverwrite(
                view_channel=False,
                send_messages=False,
            ),
        }
        for name in STAFF_ROLES:
            if name in role_map:
                overwrites[role_map[name]] = discord.PermissionOverwrite(
                    view_channel=True,
                    send_messages=True,
                    manage_messages=True,
                    manage_channels=True,
                )
        return overwrites

    # ── per-channel permission logic ───────────────────────────────────────

    def _channel_overwrites(
        self,
        channel_name: str,
        guild: discord.Guild,
        role_map: dict[str, discord.Role],
    ) -> dict[discord.Role | discord.Member, discord.PermissionOverwrite]:
        """Return the permission overwrites for a specific channel."""
        ow = self._base_overwrites(guild, role_map)

        # Information channels — visible to everyone, read-only
        if channel_name in ("welcome", "announcements", "rules", "faq"):
            ow[guild.default_role] = discord.PermissionOverwrite(
                view_channel=True,
                send_messages=False,
                add_reactions=channel_name == "rules",  # let people react to rules
            )

        # Community channels — Verified+ can chat
        elif channel_name in ("general-chat", "media", "reviews"):
            if "Verified" in role_map:
                ow[role_map["Verified"]] = discord.PermissionOverwrite(
                    view_channel=True,
                    send_messages=True,
                    attach_files=True,
                    embed_links=True,
                )

        # VIP lounge — VIP only
        elif channel_name == "vip-lounge":
            if "VIP" in role_map:
                ow[role_map["VIP"]] = discord.PermissionOverwrite(
                    view_channel=True,
                    send_messages=True,
                    attach_files=True,
                )

        # Order status — Customer+
        elif channel_name == "order-status":
            for r in ("Customer", "VIP"):
                if r in role_map:
                    ow[role_map[r]] = discord.PermissionOverwrite(
                        view_channel=True,
                        send_messages=True,
                    )

        # Support — everyone can see, Verified+ can send (ticket panel lives here)
        elif channel_name == "support":
            ow[guild.default_role] = discord.PermissionOverwrite(
                view_channel=True,
                send_messages=False,
            )
            if "Verified" in role_map:
                ow[role_map["Verified"]] = discord.PermissionOverwrite(
                    view_channel=True,
                    send_messages=True,
                )

        # Voice — Verified+ can connect
        elif channel_name in ("Lounge", "Support Waiting Room"):
            if "Verified" in role_map:
                ow[role_map["Verified"]] = discord.PermissionOverwrite(
                    view_channel=True,
                    connect=True,
                    speak=True,
                )

        return ow

    # ── the main command ───────────────────────────────────────────────────

    @commands.command(name="setup")
    @commands.has_permissions(administrator=True)
    async def setup_server(self, ctx: commands.Context) -> None:
        """Scaffold the entire SteamBoost Discord server."""
        if ctx.author.id != ctx.guild.owner_id:
            await ctx.send("⛔ Only the server owner can run `!setup`.")
            return

        status = await ctx.send("⏳ Starting SteamBoost server setup…")
        guild = ctx.guild

        # 1 — Roles
        await status.edit(content="⏳ Creating roles…")
        role_map = await self._ensure_roles(guild)

        # 2 — Categories & channels
        await status.edit(content="⏳ Creating channels…")
        for cat_def in CATEGORIES:
            # Create (or find) the category
            existing_cat = discord.utils.get(guild.categories, name=cat_def["name"])
            category = existing_cat or await guild.create_category(
                cat_def["name"],
                overwrites=self._base_overwrites(guild, role_map),
                reason="SteamBoost auto-setup",
            )
            await asyncio.sleep(0.3)

            for ch_def in cat_def["channels"]:
                ch_name = ch_def["name"]
                ch_type = ch_def.get("type", "text")
                topic = ch_def.get("topic", "")

                # Skip if already exists under this category
                if ch_type == "text":
                    exists = discord.utils.get(category.text_channels, name=ch_name)
                    if not exists:
                        await guild.create_text_channel(
                            ch_name,
                            category=category,
                            topic=topic,
                            overwrites=self._channel_overwrites(ch_name, guild, role_map),
                            reason="SteamBoost auto-setup",
                        )
                else:
                    exists = discord.utils.get(category.voice_channels, name=ch_name)
                    if not exists:
                        await guild.create_voice_channel(
                            ch_name,
                            category=category,
                            overwrites=self._channel_overwrites(ch_name, guild, role_map),
                            reason="SteamBoost auto-setup",
                        )
                await asyncio.sleep(0.3)

        # 3 — Post a ticket panel in #support (the Tickets cog handles the view)
        support_ch = discord.utils.get(guild.text_channels, name="support")
        if support_ch:
            tickets_cog = self.bot.get_cog("Tickets")
            if tickets_cog:
                await tickets_cog.post_panel(support_ch)

        # 4 — Post a welcome embed in #welcome
        welcome_ch = discord.utils.get(guild.text_channels, name="welcome")
        if welcome_ch:
            embed = discord.Embed(
                title="Welcome to SteamBoost! 🚀",
                description=(
                    "Thanks for joining the official **SteamBoost** Discord.\n\n"
                    "**Getting Started**\n"
                    "1️⃣ Read the rules in <#rules>\n"
                    "2️⃣ Verify your account with `!verify <code>` "
                    "(grab your code from [steamboost.xyz](https://steamboost.xyz))\n"
                    "3️⃣ Once verified you'll unlock all community channels\n\n"
                    "Need help? Open a ticket in <#support>!"
                ),
                colour=EMBED_COLOUR,
            )
            embed.set_footer(text="steamboost.xyz")
            await welcome_ch.send(embed=embed)

        await status.edit(content="✅ SteamBoost server setup complete!")

    @setup_server.error
    async def setup_error(self, ctx: commands.Context, error: commands.CommandError) -> None:
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("⛔ You need Administrator permissions to run this.")
        else:
            raise error


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Setup(bot))
