"""
bot.py — Entry point for the SteamBoost Discord bot.

Run with:  python bot.py
"""

from __future__ import annotations

import asyncio
import os
import logging

import discord
from discord.ext import commands
from dotenv import load_dotenv

# ── Load environment variables ─────────────────────────────────────────────
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")

if not TOKEN:
    raise SystemExit(
        "ERROR: DISCORD_TOKEN is not set.\n"
        "Copy .env.example to .env and paste your bot token there."
    )

# ── Logging ────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("steamboost")

# ── Intents (all three privileged intents must be enabled in the Portal) ───
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.presences = True

# ── Bot instance ───────────────────────────────────────────────────────────
bot = commands.Bot(
    command_prefix="!",
    intents=intents,
    help_command=commands.DefaultHelpCommand(no_category="General"),
    activity=discord.Activity(
        type=discord.ActivityType.watching,
        name="steamboost.xyz",
    ),
)

# ── Cog loader ─────────────────────────────────────────────────────────────
COGS = [
    "cogs.setup",
    "cogs.tickets",
    "cogs.verification",
    "cogs.events",
]


async def load_cogs() -> None:
    for cog in COGS:
        try:
            await bot.load_extension(cog)
            log.info("Loaded cog: %s", cog)
        except Exception:
            log.exception("Failed to load cog: %s", cog)


@bot.event
async def on_ready() -> None:
    log.info("Logged in as %s (ID: %s)", bot.user, bot.user.id)
    log.info("Connected to %d guild(s)", len(bot.guilds))
    log.info("──────────────────────────────────────")


# ── Run ────────────────────────────────────────────────────────────────────

async def main() -> None:
    async with bot:
        await load_cogs()
        await bot.start(TOKEN)


if __name__ == "__main__":
    asyncio.run(main())
