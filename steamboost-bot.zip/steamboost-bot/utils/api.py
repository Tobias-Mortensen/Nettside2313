"""
utils/api.py — Async HTTP helpers for communicating with the SteamBoost
website API.  Every function here is a *placeholder* that returns mock
data so the bot runs out-of-the-box.  Replace the bodies with real
aiohttp calls once your API is ready.

Expected base URL (from .env):  https://steamboost.xyz/api
"""

from __future__ import annotations

import os
from dataclasses import dataclass

import aiohttp

BASE_URL = os.getenv("STEAMBOOST_API_URL", "https://steamboost.xyz/api")


# ── Data classes for typed returns ─────────────────────────────────────────

@dataclass
class VerifyResult:
    success: bool
    username: str | None = None
    error: str | None = None


@dataclass
class OrderStatus:
    order_id: str
    status: str          # e.g. "in_progress", "completed", "pending"
    details: str


# ── Public helpers ─────────────────────────────────────────────────────────

async def verify_user(discord_id: int, code: str) -> VerifyResult:
    """
    POST /verify — Links a Discord account to a SteamBoost website account.

    Replace the mock block below with something like:

        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{BASE_URL}/verify",
                json={"discord_id": str(discord_id), "code": code},
            ) as resp:
                data = await resp.json()
                if resp.status == 200:
                    return VerifyResult(success=True, username=data["username"])
                return VerifyResult(success=False, error=data.get("error", "Unknown error"))
    """
    # ── MOCK — remove once real API is wired up ──
    if code == "TESTCODE":
        return VerifyResult(success=True, username="DemoUser#1234")
    return VerifyResult(success=False, error="Invalid verification code.")


async def get_order_status(discord_id: int) -> list[OrderStatus]:
    """
    GET /orders?discord_id=<id> — Fetches open orders for a verified user.

    Replace with:

        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{BASE_URL}/orders",
                params={"discord_id": str(discord_id)},
            ) as resp:
                data = await resp.json()
                return [OrderStatus(**o) for o in data["orders"]]
    """
    # ── MOCK ──
    return [
        OrderStatus(
            order_id="SB-10492",
            status="in_progress",
            details="CS2 Rank Boost — currently Gold Nova 3 → target: DMG",
        ),
    ]
