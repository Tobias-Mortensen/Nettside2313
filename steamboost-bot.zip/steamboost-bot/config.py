"""
config.py — Single source of truth for every role, channel, and category
the bot creates during !setup.  Edit colours, names, or permissions here
and the rest of the codebase picks them up automatically.
"""

import discord

# ── Roles (created top-to-bottom; first = highest in the hierarchy) ────────
ROLES = [
    {
        "name": "Owner",
        "color": discord.Colour(0xE74C3C),   # red
        "hoist": True,
        "mentionable": False,
    },
    {
        "name": "Admin",
        "color": discord.Colour(0xE91E63),   # pink-red
        "hoist": True,
        "mentionable": False,
    },
    {
        "name": "Moderator",
        "color": discord.Colour(0x9B59B6),   # purple
        "hoist": True,
        "mentionable": True,
    },
    {
        "name": "VIP",
        "color": discord.Colour(0xF1C40F),   # gold
        "hoist": True,
        "mentionable": True,
    },
    {
        "name": "Customer",
        "color": discord.Colour(0x2ECC71),   # green
        "hoist": True,
        "mentionable": False,
    },
    {
        "name": "Verified",
        "color": discord.Colour(0x3498DB),   # blue
        "hoist": False,
        "mentionable": False,
    },
    {
        "name": "Guest",
        "color": discord.Colour(0x95A5A6),   # grey
        "hoist": False,
        "mentionable": False,
    },
]

# ── Staff role names (used for permission checks) ─────────────────────────
STAFF_ROLES = {"Owner", "Admin", "Moderator"}

# ── Channel Categories & Channels ─────────────────────────────────────────
# Each category is a dict with a name, an optional topic, and a list of
# text / voice channels.  Per-channel overrides are applied in setup.py.
CATEGORIES = [
    {
        "name": "📢 Information",
        "channels": [
            {"name": "welcome",       "type": "text", "topic": "Welcome to SteamBoost! Read the rules and verify your account."},
            {"name": "announcements", "type": "text", "topic": "Official SteamBoost news and updates."},
            {"name": "rules",         "type": "text", "topic": "Server rules — read before participating."},
        ],
    },
    {
        "name": "💬 Community",
        "channels": [
            {"name": "general-chat",  "type": "text", "topic": "Hang out and chat with the community."},
            {"name": "media",         "type": "text", "topic": "Share screenshots, clips, and memes."},
            {"name": "reviews",       "type": "text", "topic": "Leave a review of your SteamBoost experience."},
        ],
    },
    {
        "name": "🛒 Services",
        "channels": [
            {"name": "order-status",  "type": "text", "topic": "Check on your active orders."},
            {"name": "vip-lounge",    "type": "text", "topic": "Exclusive channel for VIP members."},
        ],
    },
    {
        "name": "🎧 Support",
        "channels": [
            {"name": "support",       "type": "text", "topic": "Open a ticket to get help from staff."},
            {"name": "faq",           "type": "text", "topic": "Frequently asked questions."},
        ],
    },
    {
        "name": "🔊 Voice",
        "channels": [
            {"name": "Lounge",               "type": "voice"},
            {"name": "Support Waiting Room",  "type": "voice"},
        ],
    },
]

# ── Embed colour used throughout the bot ───────────────────────────────────
EMBED_COLOUR = discord.Colour(0x1ABC9C)  # teal / SteamBoost brand-ish
