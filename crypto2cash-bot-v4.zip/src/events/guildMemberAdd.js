const { EmbedBuilder } = require("discord.js");

const SITE_URL = process.env.SITE_URL || "https://crypto2cash.wtf";

module.exports = {
  name: "guildMemberAdd",
  once: false,

  async execute(member) {
    const channelId = process.env.CHANNEL_WELCOME;
    if (!channelId) return;

    const channel = await member.client.channels.fetch(channelId).catch(() => null);
    if (!channel) return;

    const embed = new EmbedBuilder()
      .setColor(0x4A6CF7)
      .setTitle(`Welcome, ${member.user.username}`)
      .setDescription(
        `Thanks for joining **Crypto2Cash**.\n\n` +
        `We convert BTC, ETH, LTC, USDT, USDC, and SOL directly to your PayPal balance — no KYC, no paperwork.\n\n` +
        `**[Start an exchange →](${SITE_URL})**`
      )
      .addFields(
        {
          name: "Quick Start",
          value: [
            "→ Use `/calc` to estimate your payout",
            "→ Use `/rates` to check live prices",
            "→ Use `/ticket` if you need help",
          ].join("\n"),
          inline: false,
        }
      )
      .setThumbnail(member.user.displayAvatarURL({ size: 64 }))
      .setFooter({ text: "Crypto2Cash · Crypto to PayPal in minutes" });

    await channel.send({ embeds: [embed] }).catch(console.error);
  },
};
