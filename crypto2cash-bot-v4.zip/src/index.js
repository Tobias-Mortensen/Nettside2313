require("dotenv").config();

const { Client, GatewayIntentBits, Collection, EmbedBuilder, ActivityType, ChannelType } = require("discord.js");
const fs = require("fs");
const path = require("path");
const { fetchTransactions } = require("./lib/api");
const { fetchPrices } = require("./lib/prices");

// ─── Create client ──────────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
  ],
});

// ─── Load slash commands ────────────────────────────────────
client.commands = new Collection();
const commandsPath = path.join(__dirname, "commands");
const commandFiles = fs.readdirSync(commandsPath).filter((f) => f.endsWith(".js"));

for (const file of commandFiles) {
  const command = require(path.join(commandsPath, file));
  if (command.data && command.execute) {
    client.commands.set(command.data.name, command);
  }
}

// ─── Load event handlers ───────────────────────────────────
const eventsPath = path.join(__dirname, "events");
if (fs.existsSync(eventsPath)) {
  const eventFiles = fs.readdirSync(eventsPath).filter((f) => f.endsWith(".js"));
  for (const file of eventFiles) {
    const event = require(path.join(eventsPath, file));
    if (event.once) {
      client.once(event.name, (...args) => event.execute(...args));
    } else {
      client.on(event.name, (...args) => event.execute(...args));
    }
  }
}

// ─── Handle slash command interactions ─────────────────────
client.on("interactionCreate", async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction);
  } catch (err) {
    console.error(`[Command /${interaction.commandName}]`, err);
    const reply = {
      content: "Something went wrong running that command.",
      ephemeral: true,
    };
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(reply).catch(() => {});
    } else {
      await interaction.reply(reply).catch(() => {});
    }
  }
});

// ─── Bot ready ─────────────────────────────────────────────
client.once("ready", async () => {
  console.log(`\n┌──────────────────────────────────────┐`);
  console.log(`│  Crypto2Cash Bot                     │`);
  console.log(`│  Logged in as ${client.user.tag.padEnd(22)}│`);
  console.log(`│  ${client.commands.size} commands loaded${" ".repeat(20 - String(client.commands.size).length)}│`);
  console.log(`└──────────────────────────────────────┘\n`);

  // Set bot status
  updateStatus();
  setInterval(updateStatus, 60_000);

  // Start transaction polling
  startTransactionPoller();
});

// ─── Bot status — shows live BTC price ─────────────────────
async function updateStatus() {
  try {
    const prices = await fetchPrices();
    const btcPrice = prices.btc?.price;
    if (btcPrice) {
      client.user.setActivity(
        `BTC $${btcPrice.toLocaleString("en-US", { maximumFractionDigits: 0 })}`,
        { type: ActivityType.Watching }
      );
    }
  } catch {
    client.user.setActivity("crypto2cash.wtf", { type: ActivityType.Watching });
  }
}

// ─── Transaction poller + auto-ticket creation ──────────────
const POLL_INTERVAL = 30_000; // 30 seconds
let knownTxnIds = new Set();

async function startTransactionPoller() {
  const txnChannelId = process.env.CHANNEL_TRANSACTIONS;
  const supportChannelId = process.env.CHANNEL_SUPPORT;

  if (!txnChannelId) {
    console.log("[Poller] CHANNEL_TRANSACTIONS not set — skipping transaction alerts.");
  }
  if (!supportChannelId) {
    console.log("[Poller] CHANNEL_SUPPORT not set — skipping auto-tickets.");
  }
  if (!txnChannelId && !supportChannelId) return;

  console.log("[Poller] Watching for new transactions...");

  // Initial load — mark all existing transactions as known (no alerts on boot)
  try {
    const existing = await fetchTransactions();
    for (const tx of existing) {
      knownTxnIds.add(tx.id);
    }
    console.log(`[Poller] Loaded ${knownTxnIds.size} existing transactions.`);
  } catch (err) {
    console.error("[Poller] Initial load failed:", err.message);
  }

  // Poll loop
  setInterval(async () => {
    try {
      const transactions = await fetchTransactions();

      for (const tx of transactions) {
        if (knownTxnIds.has(tx.id)) continue;
        knownTxnIds.add(tx.id);

        console.log(`[Poller] New transaction: ${tx.id}`);

        // 1. Post alert in admin channel
        if (txnChannelId) {
          await postTransactionAlert(txnChannelId, tx);
        }
        // Tickets are created instantly by the website — no need to do it here
      }
    } catch {
      // Silently retry on next poll
    }
  }, POLL_INTERVAL);
}

/**
 * Posts a transaction notification in the admin alerts channel.
 */
async function postTransactionAlert(channelId, tx) {
  try {
    const guildId = process.env.DISCORD_GUILD_ID;
    const guild = await client.guilds.fetch(guildId).catch(() => null);
    const channel = guild ? await guild.channels.fetch(channelId).catch(() => null) : null;
    if (!channel) return;

    const embed = new EmbedBuilder()
      .setColor(0x22C55E)
      .setTitle("New Transaction")
      .addFields(
        { name: "Order ID", value: `\`${tx.id}\``, inline: false },
        { name: "Amount", value: `${tx.cryptoAmount} ${tx.cryptoType}`, inline: true },
        { name: "Payout", value: `$${tx.usdAmount} USD`, inline: true },
        { name: "Status", value: "🟡 Pending", inline: true },
        { name: "PayPal", value: `\`${maskEmail(tx.paypalEmail)}\``, inline: true },
        {
          name: "User",
          value: tx.discordUserId ? `<@${tx.discordUserId}>` : "Not linked",
          inline: true,
        },
        { name: "Wallet", value: `\`${tx.walletAddress.slice(0, 16)}...\``, inline: false },
      )
      .setTimestamp(new Date(tx.createdAt))
      .setFooter({ text: "Crypto2Cash · New order received" });

    await channel.send({ embeds: [embed] });
  } catch (err) {
    console.error("[Alert]", err.message);
  }
}

/**
 * Automatically creates a private support thread for a new transaction.
 * Adds both the user and all admins so support can begin immediately.
 */
async function createAutoTicket(supportChannelId, tx) {
  try {
    const guildId = process.env.DISCORD_GUILD_ID;
    const guild = await client.guilds.fetch(guildId).catch(() => null);
    if (!guild) {
      console.error("[AutoTicket] Guild not found.");
      return;
    }

    const supportChannel = await guild.channels.fetch(supportChannelId).catch(() => null);
    if (!supportChannel || !supportChannel.threads) {
      console.error("[AutoTicket] Support channel not found or doesn't support threads.");
      return;
    }

    // Create a private thread named after the order
    const threadName = `order-${tx.id.replace("TXN-", "").slice(0, 16)}`;
    const thread = await supportChannel.threads.create({
      name: threadName,
      type: ChannelType.PrivateThread,
      reason: `Auto-ticket for transaction ${tx.id}`,
    });

    // Add the user who made the purchase
    await thread.members.add(tx.discordUserId).catch((err) => {
      console.error(`[AutoTicket] Couldn't add user ${tx.discordUserId}:`, err.message);
    });

    // Add admin role members
    const adminRoleId = process.env.ROLE_ADMIN;
    if (adminRoleId) {
      const guild = supportChannel.guild;
      const adminRole = guild.roles.cache.get(adminRoleId);
      if (adminRole) {
        for (const [, member] of adminRole.members) {
          await thread.members.add(member.id).catch(() => {});
        }
      }
    }

    // Post order details as the first message
    const orderEmbed = new EmbedBuilder()
      .setColor(0x4A6CF7)
      .setTitle("Order Received")
      .setDescription(
        `Your exchange has been submitted. We'll process it as soon as we detect your crypto payment on the blockchain.\n\n` +
        `**Typical payout time: under 30 minutes** after confirmation.`
      )
      .addFields(
        { name: "Order ID", value: `\`${tx.id}\``, inline: false },
        { name: "You Send", value: `**${tx.cryptoAmount} ${tx.cryptoType}**`, inline: true },
        { name: "You Receive", value: `**$${tx.usdAmount} USD** → PayPal`, inline: true },
        { name: "PayPal", value: `\`${maskEmail(tx.paypalEmail)}\``, inline: false },
        { name: "Deposit Address", value: `\`${tx.walletAddress}\``, inline: false },
      )
      .setTimestamp(new Date(tx.createdAt))
      .setFooter({ text: "Crypto2Cash" });

    await thread.send({ embeds: [orderEmbed] });

    // Follow up with a helpful message mentioning the user
    await thread.send(
      `<@${tx.discordUserId}> — This is your order thread.\n\n` +
      `**What happens next:**\n` +
      `1. Send exactly **${tx.cryptoAmount} ${tx.cryptoType}** to the deposit address above\n` +
      `2. Once confirmed on the blockchain, we process your PayPal payout\n` +
      `3. You'll receive **$${tx.usdAmount} USD** in your PayPal — typically within 30 minutes\n\n` +
      `If anything takes longer than expected, reply here and a team member will help you.`
    );

    console.log(`[AutoTicket] Created thread ${threadName} for ${tx.discordUserId}`);
  } catch (err) {
    console.error("[AutoTicket] Failed to create ticket:", err.message);
  }
}

// ─── Helpers ────────────────────────────────────────────────

function maskEmail(email) {
  if (!email) return "unknown";
  const [user, domain] = email.split("@");
  if (!domain) return "***";
  return `${user.slice(0, 2)}***@${domain}`;
}

// ─── Login ─────────────────────────────────────────────────
const token = process.env.DISCORD_BOT_TOKEN;
if (!token) {
  console.error("DISCORD_BOT_TOKEN is missing from .env");
  process.exit(1);
}

client.login(token);
