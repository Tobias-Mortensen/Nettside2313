const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("faq")
    .setDescription("Frequently asked questions about Crypto2Cash"),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x4A6CF7)
      .setTitle("Frequently Asked Questions")
      .addFields(
        {
          name: "Is this safe? Will I actually receive my money?",
          value: "Yes. We've processed 15,000+ transactions totaling over $2.5M with a 99.9% completion rate. Funds are sent as a standard PayPal payment — your credentials are never requested.",
        },
        {
          name: "How long does it take?",
          value: "Most orders complete within 30 minutes after blockchain confirmation. During high volume it can occasionally take up to a few hours.",
        },
        {
          name: "What are the fees?",
          value: "$4 flat fee on orders up to $25. 9% on orders above $25. No hidden charges — the calculator shows exactly what you'll receive.",
        },
        {
          name: "Is KYC required?",
          value: "No. We don't require ID uploads, selfies, or documents. We only need your PayPal email.",
        },
        {
          name: "What if my payment doesn't arrive?",
          value: "Open a `/ticket` with your order ID and we'll resolve it. Most issues are fixed within a few hours.",
        },
        {
          name: "What's the min/max?",
          value: "Minimum: $10 per transaction. Maximum: $5,000 per transaction. For larger amounts, open a ticket.",
        },
        {
          name: "Why Discord login?",
          value: "Discord gives us fast identity verification without requiring personal documents, plus a direct support channel where you can reach our team in minutes.",
        }
      )
      .setFooter({ text: "Use /help for a full list of commands" });

    await interaction.reply({ embeds: [embed] });
  },
};
