const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("close")
    .setDescription("Close this ticket channel"),

  async execute(interaction) {
    const categoryId = process.env.CHANNEL_TICKET_CATEGORY;

    // Only works inside ticket channels (channels in the ticket category)
    if (!categoryId || interaction.channel.parentId !== categoryId) {
      return interaction.reply({
        content: "This command can only be used inside a ticket channel.",
        ephemeral: true,
      });
    }

    // Check if user is admin or the ticket owner
    const adminRoleId = process.env.ROLE_ADMIN;
    const isAdmin = adminRoleId && interaction.member.roles.cache.has(adminRoleId);
    const isOwner = interaction.channel.name.includes(interaction.user.username.toLowerCase());
    const hasManage = interaction.member.permissions.has(PermissionFlagsBits.ManageChannels);

    if (!isAdmin && !isOwner && !hasManage) {
      return interaction.reply({
        content: "Only admins or the ticket owner can close this ticket.",
        ephemeral: true,
      });
    }

    // Send closing message
    const embed = new EmbedBuilder()
      .setColor(0xEF4444)
      .setTitle("Ticket Closed")
      .addFields(
        { name: "Closed by", value: `<@${interaction.user.id}>`, inline: true },
        { name: "Time", value: `<t:${Math.floor(Date.now() / 1000)}:f>`, inline: true }
      )
      .setFooter({ text: "This channel will be deleted in 5 seconds" });

    await interaction.reply({ embeds: [embed] });

    // Delete the channel after 5 seconds
    setTimeout(async () => {
      await interaction.channel.delete("Ticket closed").catch(console.error);
    }, 5000);
  },
};
