const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

const SITE_URL = process.env.SITE_URL || "https://crypto2cash.wtf";

module.exports = {
  data: new SlashCommandBuilder()
    .setName("howitworks")
    .setDescription("Step-by-step guide on how to use Crypto2Cash"),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x4A6CF7)
      .setTitle("How Crypto2Cash Works")
      .setDescription(`Three steps. That's it.\n\n**[Start an exchange →](${SITE_URL})**`)
      .addFields(
        {
          name: "Step 1 — Enter Amount & PayPal Email",
          value: "Go to the site, pick your crypto (BTC, ETH, LTC, USDT, USDC, SOL), enter the amount, and provide your PayPal email. You'll see the exact payout before confirming.",
        },
        {
          name: "Step 2 — Send Crypto to Deposit Address",
          value: "We generate a unique deposit address for you. Send the exact amount — our system detects your payment automatically once the blockchain confirms it.",
        },
        {
          name: "Step 3 — Receive USD in Your PayPal",
          value: "Funds land in your PayPal balance, typically within 30 minutes. No follow-up required — the payment appears automatically.",
        },
        {
          name: "Fees",
          value: "$4 flat fee up to $25, then 9% above that. Use `/calc` to estimate your payout for any amount.",
        }
      )
      .setFooter({ text: "Questions? Use /ticket to reach our team" });

    await interaction.reply({ embeds: [embed] });
  },
};
