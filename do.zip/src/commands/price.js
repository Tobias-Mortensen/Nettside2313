const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { fetchPrices, COINS } = require("../lib/prices");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("price")
    .setDescription("Check the live price of a cryptocurrency")
    .addStringOption((opt) =>
      opt
        .setName("coin")
        .setDescription("Which cryptocurrency")
        .setRequired(true)
        .addChoices(
          { name: "Bitcoin (BTC)", value: "btc" },
          { name: "Ethereum (ETH)", value: "eth" },
          { name: "Litecoin (LTC)", value: "ltc" },
          { name: "Tether (USDT)", value: "usdt" },
          { name: "USD Coin (USDC)", value: "usdc" },
          { name: "Solana (SOL)", value: "sol" }
        )
    ),

  async execute(interaction) {
    await interaction.deferReply();

    try {
      const coinId = interaction.options.getString("coin");
      const prices = await fetchPrices();
      const coin = prices[coinId];

      if (!coin || !coin.price) {
        return interaction.editReply("Couldn't fetch the price right now. Try again in a moment.");
      }

      const changeEmoji = coin.change24h >= 0 ? "📈" : "📉";
      const changeSign = coin.change24h >= 0 ? "+" : "";
      const priceFormatted = coin.price.toLocaleString("en-US", {
        style: "currency",
        currency: "USD",
        minimumFractionDigits: coin.price < 1 ? 4 : 2,
      });

      const embed = new EmbedBuilder()
        .setColor(coin.color)
        .setTitle(`${coin.icon} ${coin.name} (${coin.symbol})`)
        .addFields(
          { name: "Price", value: `**${priceFormatted}**`, inline: true },
          {
            name: "24h Change",
            value: `${changeEmoji} ${changeSign}${coin.change24h.toFixed(2)}%`,
            inline: true,
          }
        )
        .setFooter({ text: "Prices via CoinGecko · Updates every 30s" })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (err) {
      console.error("[/price]", err);
      await interaction.editReply("Failed to fetch prices. CoinGecko may be temporarily unavailable.");
    }
  },
};
