const { SlashCommandBuilder, EmbedBuilder, ChannelType, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ticket")
    .setDescription("Open a support ticket")
    .addStringOption((opt) =>
      opt
        .setName("issue")
        .setDescription("Briefly describe your issue (e.g. 'payment not received for order TXN-...')")
        .setRequired(true)
        .setMaxLength(200)
    ),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    try {
      const issue = interaction.options.getString("issue");
      const supportChannelId = process.env.CHANNEL_SUPPORT;

      if (!supportChannelId) {
        return interaction.editReply(
          "Support tickets aren't configured yet. Please message a staff member directly."
        );
      }

      const supportChannel = await interaction.client.channels.fetch(supportChannelId).catch(() => null);
      if (!supportChannel) {
        return interaction.editReply(
          "Couldn't find the support channel. Please message a staff member directly."
        );
      }

      // Create a private thread
      const threadName = `ticket-${interaction.user.username}-${Date.now().toString(36).slice(-4)}`;
      const thread = await supportChannel.threads.create({
        name: threadName,
        type: ChannelType.PrivateThread,
        reason: `Support ticket from ${interaction.user.tag}`,
      });

      // Add the user to the thread
      await thread.members.add(interaction.user.id);

      // Add admin role members if configured
      const adminRoleId = process.env.ROLE_ADMIN;
      if (adminRoleId) {
        const guild = interaction.guild;
        const adminRole = guild.roles.cache.get(adminRoleId);
        if (adminRole) {
          for (const [, member] of adminRole.members) {
            await thread.members.add(member.id).catch(() => {});
          }
        }
      }

      // Post the ticket details in the thread
      const ticketEmbed = new EmbedBuilder()
        .setColor(0x4A6CF7)
        .setTitle("Support Ticket")
        .setDescription(issue)
        .addFields(
          { name: "Opened by", value: `<@${interaction.user.id}>`, inline: true },
          { name: "Status", value: "🟡 Open", inline: true }
        )
        .setTimestamp()
        .setFooter({ text: "A team member will respond shortly" });

      await thread.send({ embeds: [ticketEmbed] });
      await thread.send(
        `<@${interaction.user.id}> — Your ticket is open. A team member will be with you shortly.\n\n` +
        `**Tip:** If this is about a pending transaction, please include your order ID (starts with \`TXN-\`) and the PayPal email you used.`
      );

      await interaction.editReply(
        `Your ticket has been created: <#${thread.id}>\nWe'll get back to you as soon as possible.`
      );
    } catch (err) {
      console.error("[/ticket]", err);
      await interaction.editReply("Something went wrong creating the ticket. Please try again or message staff directly.");
    }
  },
};
