const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const { fetchTransactions } = require("../lib/api");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("txns")
    .setDescription("[Admin] View recent transactions from the site")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addIntegerOption((opt) =>
      opt
        .setName("count")
        .setDescription("How many recent transactions to show (default: 5)")
        .setMinValue(1)
        .setMaxValue(25)
    ),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    try {
      const count = interaction.options.getInteger("count") || 5;
      const transactions = await fetchTransactions();

      if (!transactions.length) {
        return interaction.editReply("No transactions found.");
      }

      // Show the most recent ones
      const recent = transactions.slice(-count).reverse();

      const lines = recent.map((tx, i) => {
        const date = new Date(tx.createdAt);
        const timeAgo = getTimeAgo(date);
        const statusEmoji = {
          pending: "🟡",
          completed: "🟢",
          failed: "🔴",
        }[tx.status] || "⚪";

        return [
          `**${i + 1}.** ${statusEmoji} \`${tx.id}\``,
          `   ${tx.cryptoAmount} ${tx.cryptoType} → **$${tx.usdAmount}** PayPal`,
          `   📧 \`${maskEmail(tx.paypalEmail)}\` · ${timeAgo}`,
        ].join("\n");
      });

      const embed = new EmbedBuilder()
        .setColor(0x4A6CF7)
        .setTitle(`Recent Transactions (${recent.length})`)
        .setDescription(lines.join("\n\n"))
        .setFooter({ text: `Total transactions: ${transactions.length} · Fetched from Vercel backend` })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (err) {
      console.error("[/txns]", err);
      await interaction.editReply("Failed to fetch transactions. Check your SITE_URL and API_SECRET in .env.");
    }
  },
};

function maskEmail(email) {
  if (!email) return "unknown";
  const [user, domain] = email.split("@");
  if (!domain) return "***";
  return `${user.slice(0, 2)}***@${domain}`;
}

function getTimeAgo(date) {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  if (seconds < 60) return "just now";
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}
