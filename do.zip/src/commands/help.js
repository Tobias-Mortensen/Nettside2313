const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

const SITE_URL = process.env.SITE_URL || "https://crypto2cash.wtf";

module.exports = {
  data: new SlashCommandBuilder()
    .setName("help")
    .setDescription("How Crypto2Cash works + list of bot commands"),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x4A6CF7)
      .setTitle("Crypto2Cash — Help")
      .setDescription(
        `Sell crypto and get paid to PayPal in under 30 minutes. No KYC, no paperwork.\n\n**[Start an exchange →](${SITE_URL})**`
      )
      .addFields(
        {
          name: "How it works",
          value: [
            "**1.** Go to the site, pick your crypto, enter the amount",
            "**2.** Provide your PayPal email",
            "**3.** Send crypto to the deposit address",
            "**4.** Receive USD in your PayPal (typically < 30 min)",
          ].join("\n"),
          inline: false,
        },
        {
          name: "Bot Commands",
          value: [
            "`/price <coin>` — Live price for a specific coin",
            "`/rates` — All supported coin prices at once",
            "`/calc <amount> <coin>` — Estimate your PayPal payout",
            "`/fees` — Full fee breakdown",
            "`/ticket <issue>` — Open a support thread",
            "`/help` — This message",
          ].join("\n"),
          inline: false,
        },
        {
          name: "Supported Coins",
          value: "BTC · ETH · LTC · USDT · USDC · SOL",
          inline: true,
        },
        {
          name: "Payout Method",
          value: "PayPal (180+ countries)",
          inline: true,
        }
      )
      .setFooter({ text: "Need help? Use /ticket to reach our team" });

    await interaction.reply({ embeds: [embed] });
  },
};
