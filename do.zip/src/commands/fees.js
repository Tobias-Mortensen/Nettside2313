const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("fees")
    .setDescription("See the full fee structure for Crypto2Cash"),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x4A6CF7)
      .setTitle("Fee Structure")
      .setDescription(
        "Our fees are straightforward — no hidden charges, no surprises."
      )
      .addFields(
        {
          name: "Orders up to $25",
          value: "**$4.00 flat fee**\nExample: Sell $20 worth of BTC → receive **$16.00** in PayPal",
          inline: false,
        },
        {
          name: "Orders above $25",
          value: "**9% of the total**\nExample: Sell $100 worth of ETH → fee is $9.00 → receive **$91.00** in PayPal",
          inline: false,
        },
        {
          name: "Limits",
          value: "Minimum: **$10** per transaction\nMaximum: **$5,000** per transaction\nFor larger amounts, open a ticket.",
          inline: false,
        },
        {
          name: "What's included",
          value: "The fee covers blockchain network costs, PayPal processing, and instant settlement. The calculator on our site shows the exact payout before you confirm.",
          inline: false,
        }
      )
      .setFooter({ text: "Use /calc to estimate your payout for a specific amount" });

    await interaction.reply({ embeds: [embed] });
  },
};
