const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { fetchPrices } = require("../lib/prices");
const { amountAfterFee, calculateFee, feeDescription } = require("../lib/fees");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("calc")
    .setDescription("Calculate how much PayPal you'd receive for a given amount of crypto")
    .addNumberOption((opt) =>
      opt.setName("amount").setDescription("Amount of crypto to sell").setRequired(true).setMinValue(0.000001)
    )
    .addStringOption((opt) =>
      opt
        .setName("coin")
        .setDescription("Which cryptocurrency")
        .setRequired(true)
        .addChoices(
          { name: "Bitcoin (BTC)", value: "btc" },
          { name: "Ethereum (ETH)", value: "eth" },
          { name: "Litecoin (LTC)", value: "ltc" },
          { name: "Tether (USDT)", value: "usdt" },
          { name: "USD Coin (USDC)", value: "usdc" },
          { name: "Solana (SOL)", value: "sol" }
        )
    ),

  async execute(interaction) {
    await interaction.deferReply();

    try {
      const amount = interaction.options.getNumber("amount");
      const coinId = interaction.options.getString("coin");
      const prices = await fetchPrices();
      const coin = prices[coinId];

      if (!coin || !coin.price) {
        return interaction.editReply("Couldn't fetch the price right now. Try again in a moment.");
      }

      const usdValue = amount * coin.price;
      const fee = calculateFee(usdValue);
      const payout = amountAfterFee(usdValue);

      if (usdValue < 10) {
        return interaction.editReply(
          `⚠️ That's only **$${usdValue.toFixed(2)}** — the minimum exchange is **$10.00**. Try a larger amount.`
        );
      }

      const embed = new EmbedBuilder()
        .setColor(0x4A6CF7)
        .setTitle("Payout Estimate")
        .addFields(
          {
            name: "You Send",
            value: `**${amount} ${coin.symbol}**\n≈ $${usdValue.toFixed(2)} USD`,
            inline: true,
          },
          {
            name: "You Receive",
            value: `**$${payout.toFixed(2)} USD**\nvia PayPal`,
            inline: true,
          },
          {
            name: "Fee",
            value: `$${fee.toFixed(2)} (${feeDescription(usdValue)})`,
            inline: false,
          }
        )
        .setFooter({
          text: `Rate: 1 ${coin.symbol} = $${coin.price.toLocaleString("en-US")} · Estimate only, final rate at time of trade`,
        })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (err) {
      console.error("[/calc]", err);
      await interaction.editReply("Something went wrong calculating the estimate. Try again.");
    }
  },
};
