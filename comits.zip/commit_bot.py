#!/usr/bin/env python3
"""
commit_bot.py — keep a GitHub contribution graph green by making a
randomized number of small commits spread across each day.

Runs as a single long-lived process (see commit-bot.service for systemd).
It is restart-safe: it persists the day's plan to a state file, so a
crash/reboot mid-day won't blow up your commit count.

All settings are read from environment variables (see the systemd unit)
with sensible defaults below.
"""

import json
import os
import random
import subprocess
import time
from datetime import datetime, timedelta, date, time as dtime

# ----------------------------- CONFIG -----------------------------
REPO_DIR      = os.environ.get("REPO_DIR", os.path.expanduser("~/streak-repo"))
BRANCH        = os.environ.get("BRANCH", "main")
# MUST match an email verified on your GitHub account, or commits won't count!
GIT_EMAIL     = os.environ.get("GIT_EMAIL", "you@example.com")
GIT_NAME      = os.environ.get("GIT_NAME", "Your Name")
MIN_COMMITS   = int(os.environ.get("MIN_COMMITS", "5"))
MAX_COMMITS   = int(os.environ.get("MAX_COMMITS", "25"))
ACTIVE_START  = int(os.environ.get("ACTIVE_START", "9"))    # hour (24h, server local time)
ACTIVE_END    = int(os.environ.get("ACTIVE_END", "23"))     # hour
WORK_FILE     = os.environ.get("WORK_FILE", "activity.log")
STATE_FILE    = os.environ.get("STATE_FILE", os.path.expanduser("~/.commit_bot_state.json"))
# Chance (0.0-1.0) to take a whole day off, so the graph isn't suspiciously perfect.
SKIP_DAY_CHANCE = float(os.environ.get("SKIP_DAY_CHANCE", "0.0"))
# ------------------------------------------------------------------

MESSAGES = [
    "chore: tidy up", "refactor: small cleanup", "docs: update notes",
    "fix: minor tweak", "chore: bump activity log", "wip: progress",
    "style: formatting", "chore: housekeeping", "update tracking",
    "chore: routine update", "misc: adjustments", "log daily activity",
]

SNIPPETS = [
    "reviewed notes", "refactored a helper", "read some docs",
    "tweaked config", "cleaned up imports", "checked in",
    "updated todo", "poked at the build", "small experiment",
]


def log(msg):
    print(f"[{datetime.now().isoformat(timespec='seconds')}] {msg}", flush=True)


def git(*args, check=True):
    return subprocess.run(
        ["git", "-C", REPO_DIR, *args],
        check=check, capture_output=True, text=True,
    )


def ensure_repo_ready():
    git("config", "user.name", GIT_NAME)
    git("config", "user.email", GIT_EMAIL)
    # make sure we're on the target branch
    git("checkout", BRANCH, check=False)


def make_change():
    path = os.path.join(REPO_DIR, WORK_FILE)
    stamp = datetime.now().isoformat(timespec="seconds")
    with open(path, "a") as f:
        f.write(f"{stamp}  {random.choice(SNIPPETS)}\n")


def push():
    r = git("push", "origin", BRANCH, check=False)
    if r.returncode != 0:
        log(f"push failed, rebasing: {r.stderr.strip()[:200]}")
        git("pull", "--rebase", "origin", BRANCH, check=False)
        r = git("push", "origin", BRANCH, check=False)
        if r.returncode != 0:
            log(f"push still failing: {r.stderr.strip()[:200]}")


def do_commit():
    make_change()
    git("add", "-A")
    r = git("commit", "-m", random.choice(MESSAGES), check=False)
    if r.returncode != 0:
        # nothing to commit or other issue — skip silently
        log(f"commit skipped: {r.stdout.strip()[:120]}")
        return
    push()


def build_schedule(day):
    n = random.randint(MIN_COMMITS, MAX_COMMITS)
    start = datetime.combine(day, dtime(ACTIVE_START, 0))
    end = datetime.combine(day, dtime(ACTIVE_END, 0))
    span = (end - start).total_seconds()
    times = sorted(
        (start + timedelta(seconds=random.uniform(0, span))).replace(microsecond=0)
        for _ in range(n)
    )
    return [t.isoformat() for t in times]


def new_day_state(day):
    if SKIP_DAY_CHANCE > 0 and random.random() < SKIP_DAY_CHANCE:
        pending = []
        log(f"Taking {day} off (skip roll hit)")
    else:
        pending = build_schedule(day)
    return {"day": day.isoformat(), "pending": pending, "done": 0}


def load_state():
    try:
        with open(STATE_FILE) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def save_state(state):
    tmp = STATE_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(state, f)
    os.replace(tmp, STATE_FILE)


def sleep_until_next_midnight(today):
    wake = datetime.combine(today + timedelta(days=1), dtime(0, 1))
    secs = max(60, (wake - datetime.now()).total_seconds())
    time.sleep(min(secs, 3600))  # cap so we re-check at least hourly


def main():
    ensure_repo_ready()
    log(f"commit bot started. repo={REPO_DIR} window={ACTIVE_START}:00-{ACTIVE_END}:00 "
        f"commits/day={MIN_COMMITS}-{MAX_COMMITS}")
    while True:
        today = date.today()
        state = load_state()
        if state.get("day") != today.isoformat():
            state = new_day_state(today)
            save_state(state)
            log(f"new day {today}: {len(state['pending'])} commits planned")

        pending = sorted(state["pending"])
        if not pending:
            sleep_until_next_midnight(today)
            continue

        next_time = datetime.fromisoformat(pending[0])
        now = datetime.now()
        if next_time <= now:
            do_commit()
            state["pending"].remove(pending[0])
            state["done"] = state.get("done", 0) + 1
            save_state(state)
            log(f"commit #{state['done']} done, {len(state['pending'])} left today")
            time.sleep(random.uniform(2, 8))  # tiny jitter between overdue commits
        else:
            wait = (next_time - now).total_seconds()
            time.sleep(min(wait, 900))  # wake at least every 15 min


if __name__ == "__main__":
    main()
