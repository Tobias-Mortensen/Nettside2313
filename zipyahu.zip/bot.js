require("dotenv").config();
const { Client, GatewayIntentBits, Partials, EmbedBuilder } = require("discord.js");
const Anthropic = require("@anthropic-ai/sdk");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [Partials.Channel],
});

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const OWNER_ID = process.env.OWNER_ID || "500768012333482015";

// Per-channel conversation history (last N messages for context)
const MAX_HISTORY = 10;
const history = new Map();

function getHistory(channelId) {
  if (!history.has(channelId)) history.set(channelId, []);
  return history.get(channelId);
}

function pushHistory(channelId, role, content) {
  const h = getHistory(channelId);
  h.push({ role, content });
  if (h.length > MAX_HISTORY * 2) h.splice(0, 2); // trim oldest pair
}

// ---------- Claude API call ----------
async function askClaude(channelId, userMessage) {
  pushHistory(channelId, "user", userMessage);

  const response = await anthropic.messages.create({
    model: process.env.CLAUDE_MODEL || "claude-sonnet-4-20250514",
    max_tokens: 1024,
    system:
      process.env.SYSTEM_PROMPT ||
      "You are a helpful assistant in a Discord server. You speak with a Jewish flavor — sprinkle in Yiddish words and expressions naturally (oy vey, mensch, chutzpah, nu, schlep, kvetch, mazel tov, etc). Keep it warm, witty, and conversational. Keep responses concise and under 1900 characters. Use markdown that Discord supports.",
    messages: getHistory(channelId),
  });

  const text = response.content
    .filter((b) => b.type === "text")
    .map((b) => b.text)
    .join("\n");

  pushHistory(channelId, "assistant", text);
  return text;
}

// ---------- Send long responses in chunks ----------
async function sendResponse(target, text) {
  // Discord max is 2000 chars
  const chunks = [];
  let remaining = text;
  while (remaining.length > 0) {
    if (remaining.length <= 1990) {
      chunks.push(remaining);
      break;
    }
    // Try to split at newline
    let split = remaining.lastIndexOf("\n", 1990);
    if (split < 200) split = 1990;
    chunks.push(remaining.slice(0, split));
    remaining = remaining.slice(split);
  }
  for (const chunk of chunks) {
    await target.reply?.({ content: chunk, allowedMentions: { repliedUser: false } })
      ?? target.followUp({ content: chunk });
  }
}

// ---------- Events ----------
client.once("ready", () => {
  console.log(`Logged in as ${client.user.tag}`);
});

// Slash command: /ask
client.on("interactionCreate", async (interaction) => {
  if (!interaction.isChatInputCommand() || interaction.commandName !== "ask") return;

  if (interaction.user.id !== OWNER_ID) return;

  const prompt = interaction.options.getString("prompt");
  await interaction.deferReply();

  try {
    const reply = await askClaude(interaction.channelId, prompt);
    // Edit deferred reply
    if (reply.length <= 1990) {
      await interaction.editReply({ content: reply });
    } else {
      await interaction.editReply({ content: reply.slice(0, 1990) });
      const rest = reply.slice(1990);
      if (rest.length) await interaction.followUp({ content: rest });
    }
  } catch (err) {
    console.error(err);
    await interaction.editReply({ content: "Something went wrong talking to Claude." });
  }
});

// Mention trigger: @Bot <message>
client.on("messageCreate", async (message) => {
  if (message.author.bot) return;

  // Respond to DMs or @mentions
  const mentioned = message.mentions.has(client.user);
  const isDM = !message.guild;

  if (!mentioned && !isDM) return;
  if (message.author.id !== OWNER_ID) return;

  // Strip the mention from the message
  const content = message.content.replace(/<@!?\d+>/g, "").trim();
  if (!content) return;

  await message.channel.sendTyping();

  try {
    const reply = await askClaude(message.channelId, content);
    await sendResponse(message, reply);
  } catch (err) {
    console.error(err);
    await message.reply("Something went wrong talking to Claude.");
  }
});

client.login(process.env.DISCORD_TOKEN);
