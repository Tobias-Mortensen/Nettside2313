const { Client, GatewayIntentBits, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// ── Config ──────────────────────────────────────────────
const BOT_TOKEN = process.env.BOT_TOKEN;
const GUILD_ID = process.env.GUILD_ID;
const CUSTOMER_ROLE_ID = process.env.CUSTOMER_ROLE_ID;
const ADMIN_ROLE_ID = process.env.ADMIN_ROLE_ID;
const API_PORT = parseInt(process.env.API_PORT || '3001');
const API_SECRET = process.env.API_SECRET; // shared secret with website
const LICENSES_FILE = path.join(__dirname, 'licenses.json');

// ── License Store ───────────────────────────────────────
function loadLicenses() {
  try {
    return JSON.parse(fs.readFileSync(LICENSES_FILE, 'utf8'));
  } catch {
    return {};
  }
}

function saveLicenses(data) {
  fs.writeFileSync(LICENSES_FILE, JSON.stringify(data, null, 2));
}

function generateKey() {
  // Format: LARP-XXXX-XXXX-XXXX-XXXX
  const seg = () => crypto.randomBytes(2).toString('hex').toUpperCase();
  return `LARP-${seg()}-${seg()}-${seg()}-${seg()}`;
}

// ── Discord Bot ─────────────────────────────────────────
const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers],
});

client.once('ready', () => {
  console.log(`Bot online as ${client.user.tag}`);
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  const { commandName } = interaction;

  // ── /grant ──
  if (commandName === 'grant') {
    // Admin only
    if (!interaction.member.roles.cache.has(ADMIN_ROLE_ID) &&
        !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ content: '❌ You don\'t have permission to do this.', flags: 64 });
    }

    const target = interaction.options.getUser('user');
    const licenses = loadLicenses();

    if (licenses[target.id]) {
      return interaction.reply({ content: `⚠️ **${target.username}** already has a license: \`${licenses[target.id].key}\``, flags: 64 });
    }

    const key = generateKey();
    licenses[target.id] = {
      key,
      username: target.username,
      grantedBy: interaction.user.id,
      grantedAt: new Date().toISOString(),
    };
    saveLicenses(licenses);

    // Give customer role
    try {
      const guild = interaction.guild;
      const member = await guild.members.fetch(target.id);
      await member.roles.add(CUSTOMER_ROLE_ID);
    } catch (err) {
      console.error('Failed to add role:', err.message);
    }

    // DM the user their license key
    try {
      const embed = new EmbedBuilder()
        .setColor(0x00d4ff)
        .setTitle('🔑 Larp Client — License Key')
        .setDescription('Thank you for your purchase! Here is your license key.')
        .addFields(
          { name: 'License Key', value: `\`\`\`${key}\`\`\`` },
          { name: 'How to Use', value: 'Enter this key in the Larp Client to activate. You can also view it on your profile at the website.' }
        )
        .setFooter({ text: 'Keep this key private — do not share it.' })
        .setTimestamp();

      await target.send({ embeds: [embed] });
    } catch (err) {
      console.error('Failed to DM user:', err.message);
    }

    const confirmEmbed = new EmbedBuilder()
      .setColor(0x00ff88)
      .setTitle('✅ License Granted')
      .addFields(
        { name: 'User', value: `<@${target.id}>`, inline: true },
        { name: 'Key', value: `\`${key}\``, inline: true }
      )
      .setTimestamp();

    return interaction.reply({ embeds: [confirmEmbed], flags: 64 });
  }

  // ── /revoke ──
  if (commandName === 'revoke') {
    if (!interaction.member.roles.cache.has(ADMIN_ROLE_ID) &&
        !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ content: '❌ You don\'t have permission to do this.', flags: 64 });
    }

    const target = interaction.options.getUser('user');
    const licenses = loadLicenses();

    if (!licenses[target.id]) {
      return interaction.reply({ content: `⚠️ **${target.username}** doesn't have a license.`, flags: 64 });
    }

    delete licenses[target.id];
    saveLicenses(licenses);

    // Remove customer role
    try {
      const guild = interaction.guild;
      const member = await guild.members.fetch(target.id);
      await member.roles.remove(CUSTOMER_ROLE_ID);
    } catch (err) {
      console.error('Failed to remove role:', err.message);
    }

    return interaction.reply({ content: `✅ License revoked for **${target.username}**.`, flags: 64 });
  }

  // ── /license ──
  if (commandName === 'license') {
    const licenses = loadLicenses();
    const entry = licenses[interaction.user.id];

    if (!entry) {
      return interaction.reply({ content: '❌ You don\'t have a license. Purchase one to get started!', flags: 64 });
    }

    const embed = new EmbedBuilder()
      .setColor(0x00d4ff)
      .setTitle('🔑 Your License Key')
      .addFields({ name: 'Key', value: `\`\`\`${entry.key}\`\`\`` })
      .setFooter({ text: 'Keep this key private.' })
      .setTimestamp();

    return interaction.reply({ embeds: [embed], flags: 64 });
  }
});

client.login(BOT_TOKEN);

// ── HTTP API (for website to query licenses) ────────────
const app = express();

// Auth middleware — website must send the shared secret
app.use('/api', (req, res, next) => {
  const auth = req.headers['authorization'];
  if (!API_SECRET || auth !== `Bearer ${API_SECRET}`) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
});

// GET /api/license/:discordId
app.get('/api/license/:discordId', (req, res) => {
  const licenses = loadLicenses();
  const entry = licenses[req.params.discordId];

  if (!entry) {
    return res.json({ licensed: false });
  }

  res.json({
    licensed: true,
    key: entry.key,
    grantedAt: entry.grantedAt,
  });
});

app.listen(API_PORT, () => {
  console.log(`License API running on port ${API_PORT}`);
});
