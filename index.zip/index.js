require('dotenv').config();
const { Client, GatewayIntentBits, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { createClient } = require('@supabase/supabase-js');
const crypto = require('crypto');

// ── Config ──────────────────────────────────────
const BOT_TOKEN = process.env.BOT_TOKEN;
const GUILD_ID = process.env.GUILD_ID;
const CUSTOMER_ROLE_ID = process.env.CUSTOMER_ROLE_ID;
const ADMIN_ROLE_ID = process.env.ADMIN_ROLE_ID;

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

function generateKey() {
  const seg = () => crypto.randomBytes(2).toString('hex').toUpperCase();
  return `LARP-${seg()}-${seg()}-${seg()}-${seg()}`;
}

// ── Discord Bot ─────────────────────────────────
const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers],
});

client.once('ready', () => {
  console.log(`Bot online as ${client.user.tag}`);
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand()) return;
  const { commandName } = interaction;

  // ── /grant @user ──
  if (commandName === 'grant') {
    if (!interaction.member.roles.cache.has(ADMIN_ROLE_ID) &&
        !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ content: '❌ No permission.', flags: 64 });
    }

    const target = interaction.options.getUser('user');

    // Check if already licensed
    const { data: existing } = await supabase
      .from('licenses')
      .select('license_key')
      .eq('discord_id', target.id)
      .single();

    if (existing) {
      return interaction.reply({ content: `⚠️ **${target.username}** already has a license: \`${existing.license_key}\``, flags: 64 });
    }

    const key = generateKey();

    const { error } = await supabase.from('licenses').insert({
      discord_id: target.id,
      username: target.username,
      license_key: key,
      granted_by: interaction.user.id,
    });

    if (error) {
      console.error('DB insert failed:', error);
      return interaction.reply({ content: '❌ Failed to create license.', flags: 64 });
    }

    // Give customer role
    try {
      const member = await interaction.guild.members.fetch(target.id);
      await member.roles.add(CUSTOMER_ROLE_ID);
    } catch (e) { console.error('Role add failed:', e.message); }

    // DM the license key
    try {
      const embed = new EmbedBuilder()
        .setColor(0x00d4ff)
        .setTitle('🔑 Larp Client — License Key')
        .setDescription('Thank you for your purchase!')
        .addFields(
          { name: 'License Key', value: `\`\`\`${key}\`\`\`` },
          { name: 'How to Use', value: 'Enter this key in the Larp Client. You can also view it on your website profile at /profile.' }
        )
        .setFooter({ text: 'Keep this key private — do not share it.' })
        .setTimestamp();
      await target.send({ embeds: [embed] });
    } catch (e) { console.error('DM failed:', e.message); }

    const confirmEmbed = new EmbedBuilder()
      .setColor(0x00ff88)
      .setTitle('✅ License Granted')
      .addFields(
        { name: 'User', value: `<@${target.id}>`, inline: true },
        { name: 'Key', value: `\`${key}\``, inline: true }
      )
      .setTimestamp();

    return interaction.reply({ embeds: [confirmEmbed], flags: 64 });
  }

  // ── /revoke @user ──
  if (commandName === 'revoke') {
    if (!interaction.member.roles.cache.has(ADMIN_ROLE_ID) &&
        !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ content: '❌ No permission.', flags: 64 });
    }

    const target = interaction.options.getUser('user');

    const { data: existing } = await supabase
      .from('licenses')
      .select('discord_id')
      .eq('discord_id', target.id)
      .single();

    if (!existing) {
      return interaction.reply({ content: `⚠️ **${target.username}** has no license.`, flags: 64 });
    }

    // Whitelist rows cascade-delete thanks to FK
    const { error } = await supabase
      .from('licenses')
      .delete()
      .eq('discord_id', target.id);

    if (error) {
      console.error('DB delete failed:', error);
      return interaction.reply({ content: '❌ Failed to revoke.', flags: 64 });
    }

    try {
      const member = await interaction.guild.members.fetch(target.id);
      await member.roles.remove(CUSTOMER_ROLE_ID);
    } catch (e) { console.error('Role remove failed:', e.message); }

    return interaction.reply({ content: `✅ License revoked for **${target.username}**.`, flags: 64 });
  }

  // ── /license ──
  if (commandName === 'license') {
    const { data: license } = await supabase
      .from('licenses')
      .select('license_key, hwid')
      .eq('discord_id', interaction.user.id)
      .single();

    if (!license) {
      return interaction.reply({ content: '❌ You don\'t have a license.', flags: 64 });
    }

    const { data: wl } = await supabase
      .from('whitelist')
      .select('mc_username')
      .eq('discord_id', interaction.user.id);

    const embed = new EmbedBuilder()
      .setColor(0x00d4ff)
      .setTitle('🔑 Your License')
      .addFields(
        { name: 'Key', value: `\`\`\`${license.license_key}\`\`\`` },
        { name: 'HWID Bound', value: license.hwid ? '✅ Yes' : '❌ Not yet', inline: true },
        { name: 'Whitelist', value: wl?.length ? wl.map(w => w.mc_username).join(', ') : 'None', inline: true }
      )
      .setFooter({ text: 'Keep this key private.' })
      .setTimestamp();

    return interaction.reply({ embeds: [embed], flags: 64 });
  }
});

client.login(BOT_TOKEN);
