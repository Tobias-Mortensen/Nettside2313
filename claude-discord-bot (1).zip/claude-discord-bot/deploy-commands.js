require("dotenv").config();
const { REST, Routes, SlashCommandBuilder } = require("discord.js");

const commands = [
  {
    ...new SlashCommandBuilder()
      .setName("ask")
      .setDescription("Ask Claude anything")
      .addStringOption((opt) =>
        opt.setName("prompt").setDescription("Your question or prompt").setRequired(true)
      )
      .toJSON(),
    integration_types: [0, 1], // 0 = guild install, 1 = user install
    contexts: [0, 1, 2],       // 0 = guild, 1 = bot DM, 2 = private channels/DMs
  },
];

const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    // Always register globally for user-install to work everywhere
    await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), {
      body: commands,
    });
    console.log("Registered global commands (may take ~1hr to appear everywhere)");

    // Also register in guild for instant access there
    if (process.env.GUILD_ID) {
      await rest.put(
        Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
        { body: commands }
      );
      console.log(`Also registered instantly in guild ${process.env.GUILD_ID}`);
    }
  } catch (err) {
    console.error(err);
  }
})();
