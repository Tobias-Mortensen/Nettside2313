# Claude Discord Bot

Discord bot that uses Claude as the AI backend. Responds to **@mentions**, **DMs**, and the **/ask** slash command. Keeps per-channel conversation history (last 10 exchanges).

## Setup

### 1. Discord Application
1. Go to [discord.com/developers/applications](https://discord.com/developers/applications)
2. **New Application** → name it whatever
3. Go to **Bot** tab → **Reset Token** → copy it → that's your `DISCORD_TOKEN`
4. Enable **Message Content Intent** under Privileged Gateway Intents
5. Copy the **Application ID** from General Information → that's your `CLIENT_ID`
6. Go to **OAuth2 → URL Generator** → check `bot` + `applications.commands` → permissions: Send Messages, Read Message History, Use Slash Commands → copy the invite URL and add the bot to your server

### 2. Anthropic API Key
Get one at [console.anthropic.com](https://console.anthropic.com/)

### 3. Install & Run
```bash
cp .env.example .env
# Fill in your tokens in .env

npm install

# Register slash commands (use GUILD_ID in .env for instant registration)
npm run deploy

# Start the bot
npm start
```

### 4. PM2 (for your VPS)
```bash
pm2 start bot.js --name claude-bot
pm2 save
```

## Usage
- **@BotName** your question — responds in channel with conversation context
- **/ask prompt:** your question — slash command, also keeps context
- **DM the bot** — works in DMs too

## Config
- `CLAUDE_MODEL` — defaults to `claude-sonnet-4-20250514`, swap to `claude-haiku-4-5-20251001` for cheaper/faster responses
- `SYSTEM_PROMPT` — customize the bot's personality
- History is in-memory and resets on restart
