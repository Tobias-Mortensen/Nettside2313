require("dotenv").config();
const { Client, GatewayIntentBits, Partials } = require("discord.js");
const Anthropic = require("@anthropic-ai/sdk");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [Partials.Channel],
});

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const OWNER_ID = process.env.OWNER_ID || "500768012333482015";

// Per-channel conversation history
const MAX_HISTORY = 10;
const history = new Map();

function getHistory(channelId) {
  if (!history.has(channelId)) history.set(channelId, []);
  return history.get(channelId);
}

function pushHistory(channelId, role, content) {
  const h = getHistory(channelId);
  h.push({ role, content });
  if (h.length > MAX_HISTORY * 2) h.splice(0, 2);
}

// ---------- Claude API call ----------
async function askClaude(channelId, userMessage) {
  pushHistory(channelId, "user", userMessage);

  const response = await anthropic.messages.create({
    model: process.env.CLAUDE_MODEL || "claude-sonnet-4-20250514",
    max_tokens: 1024,
    system:
      process.env.SYSTEM_PROMPT ||
      "You are a helpful assistant in a Discord server. You speak with a Jewish flavor — sprinkle in Yiddish words and expressions naturally (oy vey, mensch, chutzpah, nu, schlep, kvetch, mazel tov, etc). Keep it warm, witty, and conversational. Keep responses concise and under 1900 characters. Use markdown that Discord supports.",
    messages: getHistory(channelId),
  });

  const text = response.content
    .filter((b) => b.type === "text")
    .map((b) => b.text)
    .join("\n");

  pushHistory(channelId, "assistant", text);
  return text;
}

// ---------- Send long responses ----------
async function sendLong(interaction, text) {
  if (text.length <= 1990) {
    await interaction.editReply({ content: text });
  } else {
    await interaction.editReply({ content: text.slice(0, 1990) });
    let remaining = text.slice(1990);
    while (remaining.length > 0) {
      const chunk = remaining.slice(0, 1990);
      remaining = remaining.slice(1990);
      await interaction.followUp({ content: chunk });
    }
  }
}

async function sendReply(message, text) {
  const chunks = [];
  let remaining = text;
  while (remaining.length > 0) {
    if (remaining.length <= 1990) {
      chunks.push(remaining);
      break;
    }
    let split = remaining.lastIndexOf("\n", 1990);
    if (split < 200) split = 1990;
    chunks.push(remaining.slice(0, split));
    remaining = remaining.slice(split);
  }
  for (let i = 0; i < chunks.length; i++) {
    if (i === 0) await message.reply({ content: chunks[i], allowedMentions: { repliedUser: false } });
    else await message.channel.send(chunks[i]);
  }
}

// ---------- Events ----------
client.once("ready", () => {
  console.log(`Logged in as ${client.user.tag}`);
});

// /ask slash command
client.on("interactionCreate", async (interaction) => {
  if (!interaction.isChatInputCommand() || interaction.commandName !== "ask") return;
  if (interaction.user.id !== OWNER_ID) return;

  const prompt = interaction.options.getString("prompt");
  await interaction.deferReply();

  try {
    const reply = await askClaude(interaction.channelId, prompt);
    await sendLong(interaction, reply);
  } catch (err) {
    console.error(err);
    await interaction.editReply({ content: "Something went wrong talking to Claude." });
  }
});

// @mention or DM
client.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  if (message.author.id !== OWNER_ID) return;

  const mentioned = message.mentions.has(client.user);
  const isDM = !message.guild;

  if (!mentioned && !isDM) return;

  const content = message.content.replace(/<@!?\d+>/g, "").trim();
  if (!content) return;

  await message.channel.sendTyping();

  try {
    const reply = await askClaude(message.channelId, content);
    await sendReply(message, reply);
  } catch (err) {
    console.error(err);
    await message.reply("Something went wrong talking to Claude.");
  }
});

client.login(process.env.DISCORD_TOKEN);
