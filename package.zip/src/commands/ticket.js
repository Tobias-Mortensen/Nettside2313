const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ticket")
    .setDescription("Open a support ticket")
    .addStringOption((opt) =>
      opt
        .setName("issue")
        .setDescription("Briefly describe your issue (e.g. 'payment not received for order TXN-...')")
        .setRequired(true)
        .setMaxLength(200)
    ),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    try {
      const issue = interaction.options.getString("issue");
      const categoryId = process.env.CHANNEL_TICKET_CATEGORY;

      if (!categoryId) {
        return interaction.editReply(
          "Support tickets aren't configured yet. Please message a staff member directly."
        );
      }

      const guild = interaction.guild;
      const channelName = `ticket-${interaction.user.username}-${Date.now().toString(36).slice(-4)}`;

      // Build permission overwrites
      const permissionOverwrites = [
        // Deny @everyone
        {
          id: guild.id,
          deny: [PermissionFlagsBits.ViewChannel],
        },
        // Allow the user
        {
          id: interaction.user.id,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
        },
        // Allow the bot
        {
          id: interaction.client.user.id,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
        },
      ];

      // Allow admin role
      const adminRoleId = process.env.ROLE_ADMIN;
      if (adminRoleId) {
        permissionOverwrites.push({
          id: adminRoleId,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
        });
      }

      // Create private channel inside the category
      const ticketChannel = await guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: categoryId,
        permissionOverwrites,
        reason: `Support ticket from ${interaction.user.tag}`,
      });

      // Post the ticket details
      const ticketEmbed = new EmbedBuilder()
        .setColor(0x4A6CF7)
        .setTitle("Support Ticket")
        .setDescription(issue)
        .addFields(
          { name: "Opened by", value: `<@${interaction.user.id}>`, inline: true },
          { name: "Status", value: "🟡 Open", inline: true }
        )
        .setTimestamp()
        .setFooter({ text: "A team member will respond shortly" });

      await ticketChannel.send({ embeds: [ticketEmbed] });
      await ticketChannel.send(
        `<@${interaction.user.id}> — Your ticket is open. A team member will be with you shortly.\n\n` +
        `**Tip:** If this is about a pending transaction, please include your order ID (starts with \`TXN-\`) and the PayPal email you used.`
      );

      // Ping admins
      if (adminRoleId) {
        await ticketChannel.send(`<@&${adminRoleId}>`);
      }

      await interaction.editReply(
        `Your ticket has been created: <#${ticketChannel.id}>`
      );
    } catch (err) {
      console.error("[/ticket]", err);
      await interaction.editReply("Something went wrong creating the ticket. Please try again or message staff directly.");
    }
  },
};
