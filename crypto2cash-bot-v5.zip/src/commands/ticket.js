const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ticket")
    .setDescription("Open a support ticket")
    .addStringOption((opt) =>
      opt
        .setName("issue")
        .setDescription("Briefly describe your issue (e.g. 'payment not received for order TXN-...')")
        .setRequired(true)
        .setMaxLength(200)
    ),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    try {
      const issue = interaction.options.getString("issue");
      const categoryId = process.env.CHANNEL_TICKET_CATEGORY;

      if (!categoryId) {
        return interaction.editReply(
          "Support tickets aren't configured yet. Please message a staff member directly."
        );
      }

      const guild = interaction.guild;

      // Limit: 1 open ticket per user
      const existingChannels = guild.channels.cache.filter(
        (ch) =>
          ch.parentId === categoryId &&
          ch.permissionOverwrites.cache.has(interaction.user.id)
      );

      if (existingChannels.size > 0) {
        const existing = existingChannels.first();
        return interaction.editReply(
          `You already have an open ticket: <#${existing.id}>\nUse \`/close\` in that channel before opening a new one.`
        );
      }

      const channelName = `ticket-${interaction.user.username}-${Date.now().toString(36).slice(-4)}`;

      const permissionOverwrites = [
        {
          id: guild.id,
          deny: [PermissionFlagsBits.ViewChannel],
        },
        {
          id: interaction.user.id,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
        },
        {
          id: interaction.client.user.id,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels],
        },
      ];

      const adminRoleId = process.env.ROLE_ADMIN;
      if (adminRoleId) {
        permissionOverwrites.push({
          id: adminRoleId,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
        });
      }

      const ticketChannel = await guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: categoryId,
        permissionOverwrites,
        reason: `Support ticket from ${interaction.user.tag}`,
      });

      const ticketEmbed = new EmbedBuilder()
        .setColor(0x4A6CF7)
        .setAuthor({ name: "🎫 Support Ticket Opened" })
        .setDescription(
          `**Issue:**\n> ${issue}\n\n` +
          `━━━━━━━━━━━━━━━━━━━━━━`
        )
        .addFields(
          { name: "┊ Opened by", value: `> <@${interaction.user.id}>`, inline: true },
          { name: "┊ Status", value: "> 🟡 Open", inline: true },
          { name: "┊ Close", value: "> Use `/close`", inline: true },
        )
        .setTimestamp()
        .setFooter({ text: "A team member will respond shortly" });

      await ticketChannel.send({ embeds: [ticketEmbed] });

      const infoEmbed = new EmbedBuilder()
        .setColor(0x2B2D31)
        .setDescription(
          `<@${interaction.user.id}> — Welcome to your ticket.\n\n` +
          `**💡 Tips for faster support:**\n` +
          `> • Include your order ID (starts with \`TXN-\`)\n` +
          `> • Include the PayPal email you used\n` +
          `> • Describe what happened and when\n\n` +
          `A team member will be with you shortly.`
        );

      await ticketChannel.send({ embeds: [infoEmbed] });

      if (adminRoleId) {
        await ticketChannel.send(`<@&${adminRoleId}>`);
      }

      await interaction.editReply(
        `✅ Your ticket has been created: <#${ticketChannel.id}>`
      );
    } catch (err) {
      console.error("[/ticket]", err);
      await interaction.editReply("Something went wrong creating the ticket. Please try again or message staff directly.");
    }
  },
};
