const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

const SITE_URL = process.env.SITE_URL || "https://crypto2cash.wtf";

module.exports = {
  data: new SlashCommandBuilder()
    .setName("howitworks")
    .setDescription("Step-by-step guide on how to use Crypto2Cash"),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x4A6CF7)
      .setAuthor({ name: "📖 How Crypto2Cash Works" })
      .setDescription(
        `Three steps. No accounts, no documents, no waiting.\n\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
        `**Step 1** 📝 — **Enter Amount & PayPal Email**\n` +
        `> Go to the site, pick your crypto, enter the amount.\n` +
        `> Provide your PayPal email. You see the exact payout before confirming.\n\n` +
        `**Step 2** 📤 — **Send Crypto to Deposit Address**\n` +
        `> We generate a unique deposit address for your order.\n` +
        `> Send the exact amount — our system detects it automatically.\n\n` +
        `**Step 3** 💰 — **Receive USD in Your PayPal**\n` +
        `> Funds land in your PayPal, typically within 30 minutes.\n` +
        `> No follow-up needed — the payment appears automatically.\n\n` +
        `━━━━━━━━━━━━━━━━━━━━━━`
      )
      .addFields(
        {
          name: "┊ Supported Coins",
          value: "> ₿ BTC  ┊  Ξ ETH  ┊  Ł LTC  ┊  ₮ USDT  ┊  ◈ USDC  ┊  ◎ SOL",
          inline: false,
        },
        {
          name: "🚀 Ready?",
          value: `> **[Start an exchange →](${SITE_URL})**`,
          inline: false,
        },
      )
      .setFooter({ text: "Use /calc to estimate your payout • /fees for fee info" });

    await interaction.reply({ embeds: [embed] });
  },
};
