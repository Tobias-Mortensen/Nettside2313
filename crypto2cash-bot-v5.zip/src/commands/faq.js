const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("faq")
    .setDescription("Frequently asked questions about Crypto2Cash"),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x4A6CF7)
      .setAuthor({ name: "❓ Frequently Asked Questions" })
      .setDescription("━━━━━━━━━━━━━━━━━━━━━━")
      .addFields(
        {
          name: "┊ Is this safe?",
          value: "> Yes — 15,000+ transactions, $2.5M+ processed, 99.9% completion rate.\n> Funds are sent as a standard PayPal payment. Your credentials are never requested.",
        },
        {
          name: "┊ How long does it take?",
          value: "> Most orders complete **within 30 minutes** after blockchain confirmation.\n> During high volume it can occasionally take a few hours.",
        },
        {
          name: "┊ What are the fees?",
          value: "> **$4 flat** on orders up to $25\n> **9%** on orders above $25\n> No hidden charges — use `/calc` to check.",
        },
        {
          name: "┊ Do I need to verify my identity?",
          value: "> No KYC. No ID uploads, selfies, or documents.\n> We only need your PayPal email address.",
        },
        {
          name: "┊ What if my payment doesn't arrive?",
          value: "> Open a `/ticket` with your order ID.\n> Most issues are resolved within a few hours.",
        },
        {
          name: "┊ What are the limits?",
          value: "> Min: **$10** per transaction\n> Max: **$5,000** per transaction\n> Need more? Open a `/ticket`.",
        },
        {
          name: "┊ Why Discord login?",
          value: "> Fast sign-in without personal documents + direct support access.\n> We only read your username and avatar — nothing else.",
        },
      )
      .setFooter({ text: "Still have questions? Use /ticket to reach our team" });

    await interaction.reply({ embeds: [embed] });
  },
};
