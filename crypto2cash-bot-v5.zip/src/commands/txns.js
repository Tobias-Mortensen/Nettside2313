const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const { fetchTransactions } = require("../lib/api");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("txns")
    .setDescription("[Admin] View recent transactions from the site")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addIntegerOption((opt) =>
      opt
        .setName("count")
        .setDescription("How many recent transactions to show (default: 5)")
        .setMinValue(1)
        .setMaxValue(25)
    ),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    try {
      const count = interaction.options.getInteger("count") || 5;
      const transactions = await fetchTransactions();

      if (!transactions.length) {
        const embed = new EmbedBuilder()
          .setColor(0x2B2D31)
          .setDescription("No transactions found.");
        return interaction.editReply({ embeds: [embed] });
      }

      const recent = transactions.slice(-count).reverse();

      const coinColors = {
        BTC: "🟠", ETH: "🔵", LTC: "⚪", USDT: "🟢", USDC: "🔵", SOL: "🟣",
      };

      const lines = recent.map((tx, i) => {
        const timeAgo = getTimeAgo(new Date(tx.createdAt));
        const statusEmoji = {
          pending: "🟡",
          completed: "🟢",
          failed: "🔴",
        }[tx.status] || "⚪";
        const coinEmoji = coinColors[tx.cryptoType] || "⚪";

        return (
          `${statusEmoji} \`${tx.id}\`\n` +
          `> ${coinEmoji} **${tx.cryptoAmount} ${tx.cryptoType}** → **$${tx.usdAmount}** PayPal\n` +
          `> 📧 \`${maskEmail(tx.paypalEmail)}\`  ┊  🕐 ${timeAgo}` +
          (tx.discordUserId ? `  ┊  👤 <@${tx.discordUserId}>` : "")
        );
      });

      const embed = new EmbedBuilder()
        .setColor(0x4A6CF7)
        .setAuthor({ name: `📋 Recent Transactions (${recent.length})` })
        .setDescription(
          lines.join("\n\n") +
          `\n\n━━━━━━━━━━━━━━━━━━━━━━`
        )
        .setFooter({ text: `Total: ${transactions.length} transactions • Fetched from Vercel` })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (err) {
      console.error("[/txns]", err);
      await interaction.editReply("Failed to fetch transactions. Check SITE_URL and API_SECRET in .env.");
    }
  },
};

function maskEmail(email) {
  if (!email) return "unknown";
  const [user, domain] = email.split("@");
  if (!domain) return "***";
  return `${user.slice(0, 2)}***@${domain}`;
}

function getTimeAgo(date) {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  if (seconds < 60) return "just now";
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}
