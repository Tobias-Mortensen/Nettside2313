const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { fetchPrices } = require("../lib/prices");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("price")
    .setDescription("Check the live price of a cryptocurrency")
    .addStringOption((opt) =>
      opt
        .setName("coin")
        .setDescription("Which cryptocurrency")
        .setRequired(true)
        .addChoices(
          { name: "Bitcoin (BTC)", value: "btc" },
          { name: "Ethereum (ETH)", value: "eth" },
          { name: "Litecoin (LTC)", value: "ltc" },
          { name: "Tether (USDT)", value: "usdt" },
          { name: "USD Coin (USDC)", value: "usdc" },
          { name: "Solana (SOL)", value: "sol" }
        )
    ),

  async execute(interaction) {
    await interaction.deferReply();

    try {
      const coinId = interaction.options.getString("coin");
      const prices = await fetchPrices();
      const coin = prices[coinId];

      if (!coin || !coin.price) {
        return interaction.editReply("Couldn't fetch the price right now. Try again in a moment.");
      }

      const isUp = coin.change24h >= 0;
      const changeEmoji = isUp ? "<:greenarrow:🟢>" : "<:redarrow:🔴>";
      const changeSign = isUp ? "+" : "";
      const trendBar = isUp
        ? "▰▰▰▰▰▰▰▱▱▱"
        : "▰▰▰▱▱▱▱▱▱▱";

      const priceFormatted = coin.price.toLocaleString("en-US", {
        style: "currency",
        currency: "USD",
        minimumFractionDigits: coin.price < 1 ? 4 : 2,
      });

      const embed = new EmbedBuilder()
        .setColor(coin.color)
        .setAuthor({ name: `${coin.icon} ${coin.name} (${coin.symbol})` })
        .setDescription(
          `## ${priceFormatted}\n` +
          `${isUp ? "🟢" : "🔴"} **${changeSign}${coin.change24h.toFixed(2)}%** in the last 24h\n\n` +
          `\`${trendBar}\`\n` +
          `━━━━━━━━━━━━━━━━━━━━━━`
        )
        .addFields(
          { name: "┊ Sell on Crypto2Cash", value: `> Use \`/calc <amount> ${coinId}\` to see your PayPal payout`, inline: false },
        )
        .setFooter({ text: "Live data via CoinGecko • Updates every 30s" })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (err) {
      console.error("[/price]", err);
      await interaction.editReply("Failed to fetch prices. CoinGecko may be temporarily unavailable.");
    }
  },
};
