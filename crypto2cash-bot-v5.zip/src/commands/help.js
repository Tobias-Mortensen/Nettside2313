const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

const SITE_URL = process.env.SITE_URL || "https://crypto2cash.wtf";

module.exports = {
  data: new SlashCommandBuilder()
    .setName("help")
    .setDescription("How Crypto2Cash works + list of bot commands"),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x4A6CF7)
      .setAuthor({ name: "⚡ Crypto2Cash" })
      .setDescription(
        `Sell crypto → get paid to PayPal in under 30 minutes.\nNo KYC. No paperwork. **[Start here →](${SITE_URL})**\n\n` +
        `━━━━━━━━━━━━━━━━━━━━━━`
      )
      .addFields(
        {
          name: "📊 Prices & Calculator",
          value: 
            "> `/price <coin>` — Live price + 24h change\n" +
            "> `/rates` — All coin prices at once\n" +
            "> `/calc <amount> <coin>` — Estimate PayPal payout",
          inline: false,
        },
        {
          name: "📖 Information",
          value: 
            "> `/fees` — Fee breakdown\n" +
            "> `/faq` — Frequently asked questions\n" +
            "> `/howitworks` — Step-by-step guide",
          inline: false,
        },
        {
          name: "🎫 Support",
          value: 
            "> `/ticket <issue>` — Open a support ticket *(1 at a time)*\n" +
            "> `/close` — Close your current ticket",
          inline: false,
        },
        {
          name: " ",
          value: 
            "━━━━━━━━━━━━━━━━━━━━━━\n" +
            "> ₿ BTC  ┊  Ξ ETH  ┊  Ł LTC  ┊  ₮ USDT  ┊  ◈ USDC  ┊  ◎ SOL",
          inline: false,
        },
      )
      .setFooter({ text: "Crypto2Cash • Crypto to PayPal in minutes" });

    await interaction.reply({ embeds: [embed] });
  },
};
