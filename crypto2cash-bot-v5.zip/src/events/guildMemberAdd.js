const { EmbedBuilder } = require("discord.js");

const SITE_URL = process.env.SITE_URL || "https://crypto2cash.wtf";

module.exports = {
  name: "guildMemberAdd",
  once: false,

  async execute(member) {
    const channelId = process.env.CHANNEL_WELCOME;
    if (!channelId) return;

    const channel = await member.client.channels.fetch(channelId).catch(() => null);
    if (!channel) return;

    const embed = new EmbedBuilder()
      .setColor(0x4A6CF7)
      .setAuthor({ name: `Welcome to Crypto2Cash!`, iconURL: member.user.displayAvatarURL({ size: 64 }) })
      .setDescription(
        `Hey <@${member.user.id}> — glad you're here! 👋\n\n` +
        `We convert **BTC, ETH, LTC, USDT, USDC, and SOL** directly to your PayPal balance.\n` +
        `No KYC. No paperwork. Payouts in under 30 minutes.\n\n` +
        `━━━━━━━━━━━━━━━━━━━━━━`
      )
      .addFields(
        {
          name: "⚡ Quick Start",
          value:
            "> `/calc` — Estimate your payout\n" +
            "> `/rates` — Check live prices\n" +
            "> `/howitworks` — Step-by-step guide\n" +
            "> `/ticket` — Need help? Open a ticket",
          inline: false,
        },
        {
          name: "🚀 Ready to sell?",
          value: `> **[Start an exchange →](${SITE_URL})**`,
          inline: false,
        },
      )
      .setThumbnail(member.user.displayAvatarURL({ size: 128 }))
      .setFooter({ text: `Member #${member.guild.memberCount}` })
      .setTimestamp();

    await channel.send({ embeds: [embed] }).catch(console.error);
  },
};
