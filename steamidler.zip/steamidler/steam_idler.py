import asyncio
import json
import sys
import time
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path

try:
    from steam.client import SteamClient
    from steam.enums import EResult
except ImportError:
    print("Install steam package: py -m pip install steam[client]")
    sys.exit(1)

GAME_ID = 730
CONFIG_FILE = Path("accounts.json")
HISTORY_FILE = Path("hours.json")
RECONNECT_DELAY = 30
WEB_PORT = 5000
SAVE_INTERVAL = 60  # save to disk every 60 seconds

# Shared state for the dashboard
account_status: list[dict] = []


def load_accounts() -> list:
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    with open(CONFIG_FILE, "w") as f:
        json.dump([{"username": "", "password": ""}], f, indent=2)
    print(f"Created {CONFIG_FILE} — add your accounts and run again.")
    print('Format: [{"username": "acc1", "password": "pass1"}, ...]')
    sys.exit(0)


def load_history() -> dict:
    """Load total accumulated seconds per account from disk."""
    if HISTORY_FILE.exists():
        with open(HISTORY_FILE) as f:
            return json.load(f)
    return {}


def save_history():
    """Save current total seconds per account to disk."""
    now = time.time()
    history = load_history()
    for s in account_status:
        session = s.get("banked", 0.0)
        if s["state"] == "Idling" and s.get("idle_since"):
            session += now - s["idle_since"]
        history[s["username"]] = s.get("history_base", 0.0) + session
    with open(HISTORY_FILE, "w") as f:
        json.dump(history, f, indent=2)


def get_session_seconds(s: dict) -> float:
    """Get seconds idled this session for an account status dict."""
    total = s.get("banked", 0.0)
    if s["state"] == "Idling" and s.get("idle_since"):
        total += time.time() - s["idle_since"]
    return total


def get_total_seconds(s: dict) -> float:
    """Get all-time total seconds for an account status dict."""
    return s.get("history_base", 0.0) + get_session_seconds(s)


class AccountIdler:
    def __init__(self, username: str, password: str, status: dict):
        self.username = username
        self.password = password
        self.client = SteamClient()
        self.running = True
        self.status = status

        self.client.on("logged_on", self._on_logged_on)
        self.client.on("disconnected", self._on_disconnected)
        self.client.on("error", self._on_error)

    def log(self, msg: str):
        print(f"[{self.username}] {msg}")

    def _on_logged_on(self):
        self.log("Logged on — idling CS2")
        self.client.games_played([GAME_ID])
        self.status["state"] = "Idling"
        self.status["idle_since"] = time.time()

    def _on_disconnected(self):
        self.log("Disconnected")
        if self.status["state"] == "Idling" and self.status.get("idle_since"):
            self.status["banked"] += time.time() - self.status["idle_since"]
            self.status["idle_since"] = None
        self.status["state"] = "Disconnected"

    def _on_error(self, result):
        self.log(f"Error: {result}")
        self.status["state"] = f"Error: {result}"

    async def run(self):
        if not self.username or not self.password:
            self.log("Missing credentials — skipping.")
            self.status["state"] = "Skipped"
            return

        while self.running:
            self.log("Logging in...")
            self.status["state"] = "Logging in..."
            result = self.client.cli_login(self.username, self.password)

            if result == EResult.OK:
                self.log("Idling...")
                while self.running and self.client.connected:
                    await asyncio.sleep(1)
                    self.client.sleep(0)
            else:
                self.log(f"Login failed: {result}")
                self.status["state"] = f"Login failed: {result}"

            if not self.running:
                break

            self.status["state"] = "Reconnecting..."
            self.log(f"Reconnecting in {RECONNECT_DELAY}s...")
            try:
                await asyncio.sleep(RECONNECT_DELAY)
            except asyncio.CancelledError:
                break

        self.status["state"] = "Stopped"
        self.log("Shutting down...")
        try:
            self.client.games_played([])
            self.client.logout()
        except Exception:
            pass

    def stop(self):
        self.running = False


# ── Periodic saver ─────────────────────────────────────────────

async def periodic_save():
    """Save history to disk every SAVE_INTERVAL seconds."""
    while True:
        await asyncio.sleep(SAVE_INTERVAL)
        try:
            save_history()
        except Exception as e:
            print(f"[save] Error saving history: {e}")


# ── Web Dashboard ──────────────────────────────────────────────

DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Steam Idler</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: #1b2838;
    color: #c7d5e0;
    min-height: 100vh;
    padding: 40px 20px;
  }
  .container { max-width: 700px; margin: 0 auto; }
  h1 {
    text-align: center;
    font-size: 28px;
    color: #66c0f4;
    margin-bottom: 8px;
  }
  .subtitle {
    text-align: center;
    font-size: 14px;
    color: #8f98a0;
    margin-bottom: 32px;
  }
  .card {
    background: #171a21;
    border: 1px solid #2a475e;
    border-radius: 8px;
    padding: 16px 20px;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    transition: border-color 0.2s;
  }
  .card:hover { border-color: #66c0f4; }
  .left { display: flex; align-items: center; gap: 14px; }
  .avatar {
    width: 42px; height: 42px;
    border-radius: 50%;
    background: #2a475e;
    display: flex; align-items: center; justify-content: center;
    font-weight: 700; font-size: 18px; color: #66c0f4;
  }
  .username { font-size: 17px; font-weight: 600; color: #e5e5e5; }
  .times { display: flex; gap: 24px; }
  .time-block { text-align: right; }
  .hours { font-size: 22px; font-weight: 700; color: #66c0f4; }
  .hours-total { font-size: 22px; font-weight: 700; color: #a8db8f; }
  .hours-label { font-size: 11px; color: #8f98a0; text-transform: uppercase; letter-spacing: 0.5px; }
  .badge {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    margin-top: 4px;
  }
  .badge.idling   { background: #264d33; color: #5cb85c; }
  .badge.offline  { background: #4d2626; color: #d9534f; }
  .badge.pending  { background: #4d4326; color: #f0ad4e; }
  .status-bar {
    text-align: center;
    margin-top: 24px;
    color: #8f98a0;
    font-size: 14px;
  }
  .status-bar span { color: #66c0f4; font-weight: 700; }
  .status-bar .green { color: #a8db8f; }
  .divider {
    border: none;
    border-top: 1px solid #2a475e;
    margin: 16px 0;
  }
</style>
</head>
<body>
<div class="container">
  <h1>Steam Idler</h1>
  <p class="subtitle">CS2 &mdash; Game ID 730</p>
  <div id="accounts"></div>
  <div class="status-bar" id="session-bar"></div>
  <hr class="divider">
  <div class="status-bar" id="total-bar"></div>
</div>
<script>
function badgeClass(state) {
  if (state === 'Idling') return 'idling';
  if (state === 'Logging in...' || state === 'Reconnecting...') return 'pending';
  return 'offline';
}
function fmt(h) {
  const hrs = Math.floor(h);
  const mins = Math.floor((h - hrs) * 60);
  if (hrs > 0) return hrs + 'h ' + mins + 'm';
  return mins + 'm';
}
async function refresh() {
  try {
    const r = await fetch('/api/status');
    const data = await r.json();
    const el = document.getElementById('accounts');
    let html = '';
    let sessionTotal = 0, allTimeTotal = 0, idling = 0;
    for (const a of data) {
      sessionTotal += a.session_hours;
      allTimeTotal += a.total_hours;
      if (a.state === 'Idling') idling++;
      html += `
        <div class="card">
          <div class="left">
            <div class="avatar">${a.username[0].toUpperCase()}</div>
            <div>
              <div class="username">${a.username}</div>
              <span class="badge ${badgeClass(a.state)}">${a.state}</span>
            </div>
          </div>
          <div class="times">
            <div class="time-block">
              <div class="hours">${fmt(a.session_hours)}</div>
              <div class="hours-label">Session</div>
            </div>
            <div class="time-block">
              <div class="hours-total">${fmt(a.total_hours)}</div>
              <div class="hours-label">All Time</div>
            </div>
          </div>
        </div>`;
    }
    el.innerHTML = html;
    document.getElementById('session-bar').innerHTML =
      `<span>${idling}</span> of <span>${data.length}</span> accounts idling &mdash; ` +
      `<span>${fmt(sessionTotal)}</span> session time`;
    document.getElementById('total-bar').innerHTML =
      `All-time total: <span class="green">${fmt(allTimeTotal)}</span>`;
  } catch {}
}
refresh();
setInterval(refresh, 3000);
</script>
</body>
</html>"""


class DashboardHandler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        if self.path == "/api/status":
            data = []
            for s in account_status:
                data.append({
                    "username": s["username"],
                    "state": s["state"],
                    "session_hours": round(get_session_seconds(s) / 3600, 4),
                    "total_hours": round(get_total_seconds(s) / 3600, 4),
                })
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(data).encode())
        else:
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(DASHBOARD_HTML.encode())


def start_web_server():
    server = HTTPServer(("0.0.0.0", WEB_PORT), DashboardHandler)
    server.daemon_threads = True
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    print(f"[web] Dashboard running at http://localhost:{WEB_PORT}\n")


# ── Main ───────────────────────────────────────────────────────

async def main():
    accounts = load_accounts()
    accounts = [a for a in accounts if a.get("username") and a.get("password")]

    if not accounts:
        print("No valid accounts in accounts.json")
        return

    # Load previous hours from disk
    history = load_history()

    # Build shared status list
    for a in accounts:
        account_status.append({
            "username": a["username"],
            "state": "Starting...",
            "idle_since": None,
            "banked": 0.0,
            "history_base": history.get(a["username"], 0.0),
        })

    start_web_server()

    print(f"Starting {len(accounts)} account(s) on game {GAME_ID}...\n")

    idlers = [
        AccountIdler(a["username"], a["password"], account_status[i])
        for i, a in enumerate(accounts)
    ]

    try:
        await asyncio.gather(
            *(idler.run() for idler in idlers),
            periodic_save(),
        )
    except KeyboardInterrupt:
        pass
    finally:
        for idler in idlers:
            idler.stop()
        save_history()
        print("\nAll accounts stopped. Hours saved.")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        save_history()
        print("\nStopped. Hours saved.")
