"""High-level orchestrator: scrape one or more groups and write PNGs to disk."""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional

from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)

from .constants import DEFAULT_OUTPUT_DIR, DETAILS_BATCH_SIZE
from .logger import get_logger
from .models import ClothingItem, GroupInfo
from .roblox_api import RobloxAPI, RobloxAPIError
from .utils import sanitize_filename

log = get_logger()


@dataclass
class GroupResult:
    group: GroupInfo
    total_found: int = 0
    downloaded: int = 0
    skipped: int = 0
    failed: int = 0
    files: list[Path] = field(default_factory=list)


async def _collect_group_items(
    api: RobloxAPI,
    group_id: int,
    asset_type_filter: Optional[set[int]],
) -> list[ClothingItem]:
    """List every clothing asset ID in a group, then resolve details in batches."""
    ids: list[int] = [aid async for aid in api.iter_group_clothing_ids(group_id)]
    items: list[ClothingItem] = []
    for start in range(0, len(ids), DETAILS_BATCH_SIZE):
        chunk = ids[start : start + DETAILS_BATCH_SIZE]
        items.extend(await api.get_item_details(chunk))
    if asset_type_filter:
        items = [i for i in items if i.asset_type_id in asset_type_filter]
    return items


async def _download_one(
    api: RobloxAPI,
    item: ClothingItem,
    group_dir: Path,
    overwrite: bool,
) -> tuple[ClothingItem, Optional[Path], str]:
    """Download a single item. Returns (item, path_or_None, 'downloaded'|'skipped'|'failed')."""
    # Sort by type so the user gets shirts/pants/tshirts/ subfolders.
    subfolder = group_dir / item.asset_type_name.lower().replace("-", "")
    subfolder.mkdir(parents=True, exist_ok=True)

    filename = f"{item.asset_id}_{sanitize_filename(item.name)}.png"
    path = subfolder / filename

    if path.exists() and not overwrite:
        return item, path, "skipped"

    data = await api.download_template_png(item)
    if not data:
        return item, None, "failed"

    path.write_bytes(data)
    return item, path, "downloaded"


async def scrape_groups(
    group_ids: Iterable[int],
    output_dir: str | Path = DEFAULT_OUTPUT_DIR,
    asset_type_filter: Optional[set[int]] = None,
    concurrency: int = 8,
    overwrite: bool = False,
) -> list[GroupResult]:
    """Scrape clothing from each group ID into `output_dir/<group_id>_<name>/<type>/`."""
    results: list[GroupResult] = []
    output_root = Path(output_dir)
    output_root.mkdir(parents=True, exist_ok=True)

    async with RobloxAPI(concurrency=concurrency) as api:
        for gid in group_ids:
            try:
                group = await api.get_group_info(gid)
            except RobloxAPIError as exc:
                log.error(f"[red]Skipping group {gid}: {exc}[/]")
                continue

            log.info(
                f"[cyan]== {group.name} "
                f"(ID {group.id}, {group.member_count:,} members) ==[/]"
            )

            items = await _collect_group_items(api, group.id, asset_type_filter)
            result = GroupResult(group=group, total_found=len(items))

            if not items:
                log.warning(f"No matching clothing in {group.name!r}.")
                results.append(result)
                continue

            group_dir = output_root / sanitize_filename(f"{group.id}_{group.name}")

            with Progress(
                SpinnerColumn(),
                TextColumn("[bold blue]{task.description}"),
                BarColumn(),
                MofNCompleteColumn(),
                TextColumn("•"),
                TextColumn(
                    "[green]{task.fields[ok]}[/] ok / "
                    "[red]{task.fields[fail]}[/] fail"
                ),
                TimeElapsedColumn(),
            ) as progress:
                task_id = progress.add_task(
                    f"Downloading {group.name}",
                    total=len(items),
                    ok=0,
                    fail=0,
                )
                coros = [
                    _download_one(api, item, group_dir, overwrite) for item in items
                ]
                for completed in asyncio.as_completed(coros):
                    _, path, status = await completed
                    if status == "downloaded":
                        result.downloaded += 1
                        if path:
                            result.files.append(path)
                    elif status == "skipped":
                        result.skipped += 1
                    else:
                        result.failed += 1
                    progress.update(
                        task_id,
                        advance=1,
                        ok=result.downloaded + result.skipped,
                        fail=result.failed,
                    )

            log.info(
                f"[green]Finished {group.name}:[/] "
                f"{result.downloaded} downloaded, "
                f"{result.skipped} skipped, "
                f"{result.failed} failed "
                f"→ {group_dir}"
            )
            results.append(result)

    return results
