"""Entry point for the Roblox Clothing Scraper."""
from __future__ import annotations

import asyncio
import sys

from .cli import (
    print_summary,
    prompt_asset_types,
    prompt_concurrency,
    prompt_group_ids,
    prompt_output_dir,
    prompt_overwrite,
    show_banner,
)
from .downloader import scrape_groups
from .logger import get_logger

log = get_logger()


async def _run() -> int:
    show_banner()
    group_ids = prompt_group_ids()
    asset_types = prompt_asset_types()
    output_dir = prompt_output_dir()
    concurrency = prompt_concurrency()
    overwrite = prompt_overwrite()

    log.info(
        f"Scraping {len(group_ids)} group(s) → {output_dir} "
        f"(concurrency={concurrency}, overwrite={overwrite})"
    )

    results = await scrape_groups(
        group_ids=group_ids,
        output_dir=output_dir,
        asset_type_filter=asset_types,
        concurrency=concurrency,
        overwrite=overwrite,
    )
    print_summary(results)
    return 0


def main() -> None:
    try:
        sys.exit(asyncio.run(_run()))
    except KeyboardInterrupt:
        log.warning("Interrupted by user.")
        sys.exit(130)


if __name__ == "__main__":
    main()
